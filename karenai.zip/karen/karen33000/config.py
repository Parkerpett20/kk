# config.py
import os
import logging
from dotenv import load_dotenv

# تنظیم logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# ساکت کردن هشدارهای Telethon درباره SSL (فقط INFO هست، مشکلی ایجاد نمیکنه)
logging.getLogger('telethon.crypto.libssl').setLevel(logging.WARNING)

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
PROXY = os.getenv("PROXY")

# Optional: external search provider API keys
SERPAPI_API_KEY = os.getenv("SERPAPI_API_KEY")
# Search provider: 'exa', 'serpapi', or 'none'. Exa is preferred (Agent-Reach integration).
SEARCH_PROVIDER = os.getenv("SEARCH_PROVIDER", "exa")
# Exa AI API key (free tier available at https://exa.ai)
EXA_API_KEY = os.getenv("EXA_API_KEY", "")

if not TELEGRAM_BOT_TOKEN or not GEMINI_API_KEY:
    raise ValueError("❌ خطا: متغیر TELEGRAM_BOT_TOKEN یا GEMINI_API_KEY در فایل .env یافت نشد.")

# تعریف مدل‌ها بر اساس الگوهای سفارشی شما
MODELS = {
    "fast_or_search": "gemini-3.6-flash",  # پاسخ‌های سریع و سرچ گوگل
    "deep_task": "gemini-3.6-flash"           # کارهای عمیق، مقاله‌نویسی، منطق و کدنویسی
}
