# main.py
import telebot
import time
import logging
from config import TELEGRAM_BOT_TOKEN, PROXY
from functools import partial

logger = logging.getLogger(__name__)

# وارد کردن تمامی هندلرهای ماژولار ثبت‌شده
from handlers.commands import register_commands
from handlers.secretary import register_secretary_handlers
from handlers.text import register_text_handler
from handlers.photo import register_photo_handler
from handlers.voice import register_voice_handler
from handlers.document import register_document_handler
from handlers.video import register_video_handler
from handlers.reminder import register_reminder_handler, send_reminder_callback
from handlers.group import register_group_handler
from handlers.memory_export import register_memory_export_handler

# وارد کردن scheduler
from core.scheduler import reminder_scheduler

# وارد کردن ابزار مدیریت گروه و تنظیم نمونه ربات
from tools.group_management import set_bot_instance as set_group_bot_instance
from tools.telethon_client import is_available as telethon_available, ensure_connected as telethon_connect

# پیکربندی پروکسی محلی (در صورت تعریف شدن در فایل .env)
if PROXY:
    from telebot import apihelper
    apihelper.proxy = {
        'http': PROXY,
        'https': PROXY
    }
    logger.info(f"⚙️ پروکسی به صورت هوشمند روی آدرس تنظیم شد: {PROXY}")

# نمونه‌سازی از کلاینت ربات تلگرام
bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)

# تنظیم نمونه ربات برای ابزار مدیریت گروه
set_group_bot_instance(bot)

# ثبت تمامی هندلرهای چندرسانه‌ای بر روی نمونه ربات
register_commands(bot)
register_secretary_handlers(bot)
register_reminder_handler(bot)  # ثبت هندلر یادآوری قبل از هندلر متن
register_memory_export_handler(bot)  # ثبت هندلر خروجی/بازیابی قبل از هندلر متن
register_text_handler(bot)
register_photo_handler(bot)
register_voice_handler(bot)
register_document_handler(bot)
register_video_handler(bot)
register_group_handler(bot)

# تنظیم callback برای فعال کردن ارسال یادآوری‌ها
reminder_scheduler.set_callback(partial(send_reminder_callback, bot=bot))

if __name__ == "__main__":
    logger.info("در حال آماده‌سازی و بررسی اتصالات ربات کارن...")
    
    # راه‌اندازی Telethon userbot (اختیاری - برای اضافه کردن با شماره تلفن)
    if telethon_available():
        logger.info("🔄 در حال اتصال Telethon userbot...")
        if telethon_connect():
            logger.info("✅ Telethon userbot متصل شد")
        else:
            logger.warning("⚠️ اتصال Telethon ناموفق بود. اضافه کردن با شماره تلفن کار نخواهد کرد.")
    else:
        logger.info("ℹ️ Telethon پیکربندی نشده. فقط اضافه کردن با یوزرنیم و آیدی عددی پشتیبانی می‌شود.")

    # بارگذاری سشن‌های منشی شخصی برای کاربرانی که قبلاً فعال کرده‌اند
    # این کار باعث می‌شود کلاینت‌های تلگرام در حافظه بارگذاری شوند تا
    # ابزار ارسال پیام (send_message_to_contact) بتواند از آن‌ها استفاده کند
    try:
        from tools.secretary_service import start_all_active_secretaries
        logger.info("🔄 در حال بارگذاری سشن‌های منشی شخصی...")
        secretary_results = start_all_active_secretaries(bot)
        for uid, success in secretary_results.items():
            if success:
                logger.info(f"✅ منشی شخصی کاربر {uid} فعال شد")
            else:
                logger.warning(f"⚠️ فعال‌سازی منشی شخصی کاربر {uid} ناموفق بود")
    except Exception as e:
        logger.error(f"⚠️ خطا در بارگذاری سشن‌های منشی شخصی: {e}", exc_info=True)
    
    # لغو وب‌هوک‌های احتمالی قبلی برای جلوگیری از بلاک شدن پورت دریافت پیام
    try:
        bot.remove_webhook()
    except Exception as e:
        logger.warning(f"⚠️ پاکسازی وب‌هوک: {e}")

    # توقف پولیینگ‌های قبلی جهت جلوگیری از تداخل سشن‌ها روی سرورهای تلگرام
    try:
        bot.stop_polling()
        time.sleep(1)
        if hasattr(bot, '_TeleBot__stop_polling'):
            bot._TeleBot__stop_polling.clear()
    except Exception as e:
        logger.debug(f"⚠️ توقف پولینگ قبلی: {e}")

    # شروع scheduler برای یادآوری‌ها
    reminder_scheduler.start()
    logger.info("✅ Scheduler یادآوری‌ها فعال شد")

    logger.info("🚀 ربات کارن (نسخه ایجنت هوشمند ماژولار) آماده خدمت‌رسانی است...")
    
    # راه‌اندازی ربات با حلقه پولیینگ بی‌نهایت (Infinity Polling) جهت پایداری در قطعی‌های شبکه
    try:
        bot.infinity_polling(timeout=90, long_polling_timeout=90)
    except KeyboardInterrupt:
        logger.info("⛔ ربات توسط کاربر متوقف شد")
        reminder_scheduler.stop()
    except Exception as e:
        logger.error(f"❌ خطای غیرمنتظره در polling: {e}", exc_info=True)
        reminder_scheduler.stop()
