# prompts/planner.py

PLANNER_SYSTEM_PROMPT = (
    "You are a highly structured task-decomposition engine. "
    "Your objective is to analyze a complex user request and break it down into a logical sequence "
    "of independent sub-tasks (a plan) that can be executed sequentially by an agent. "
    "Each sub-task must be concrete, actionable, and focus on a single objective."
)

def get_planner_prompt(user_query: str) -> str:
    """تولید پرامپت تجزیه تسک برای برنامه‌ریز هوشمند"""
    return (
        f"Task to decompose: \"{user_query}\"\n\n"
        "Decompose this task into a sequential list of steps. "
        "Return ONLY a valid, raw JSON array of strings representing the steps. "
        "Do not include any markdown formatting like ```json or any trailing text.\n\n"
        "Example output format:\n"
        '["Search for gold prices", "Convert USD to IRR", "Calculate the total price of 10 grams"]'
    )