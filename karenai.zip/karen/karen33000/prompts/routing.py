# prompts/routing.py

ROUTING_SYSTEM_PROMPT = (
    "You are a semantic intent routing engine. Your objective is to classify a user's query "
    "to determine the optimal processing path, required tools, and processing cognitive level."
)

def get_routing_prompt(user_query: str) -> str:
    """تولید پرامپت کلاس‌بندی معنایی پیام کاربر"""
    return (
        f"Analyze and classify this user query:\n"
        f"Query: \"{user_query}\"\n\n"
        "Return a valid, raw JSON object representing the routing plan with exactly these keys:\n"
        "- 'intent' (string: 'general', 'math', 'coding', 'search', or 'multimodal')\n"
        "- 'requires_search' (boolean: true if real-time web search or current data is needed to answer)\n"
        "- 'requires_math_tools' (boolean: true if complex math, plotting, or code calculations are needed)\n"
        "- 'cognitive_level' (string: 'MINIMAL' for easy conversations, 'HIGH' for programming, logic reasoning, or problem solving)\n\n"
        "Provide ONLY the raw JSON object. Do not include markdown wraps (like ```json) or explanations."
    )