# prompts/reflection.py

REFLECTION_SYSTEM_PROMPT = (
    "You are a critical quality assurance and audit AI. "
    "Your objective is to evaluate whether a proposed response completely, accurately, "
    "and safely answers a user's original query. Look for errors, gaps, or hallucinations."
)

def get_reflection_prompt(user_query: str, proposed_answer: str) -> str:
    """تولید پرامپت ارزیابی صحت پاسخ تولید شده"""
    return (
        f"Evaluate the proposed response for the given user query:\n\n"
        f"--- User Query ---\n{user_query}\n\n"
        f"--- Proposed Response ---\n{proposed_answer}\n\n"
        "Analyze the proposed response. Return your evaluation strictly in a valid, raw JSON format with exactly two keys:\n"
        "- 'approved' (boolean: true if the answer is accurate and completely answers the prompt, false if it has errors or needs modification)\n"
        "- 'feedback' (string: if not approved, describe exactly what is wrong or missing. If approved, keep this empty)\n\n"
        "Provide ONLY the raw JSON object. Do not wrap it in markdown code fences (like ```json) or write any extra text."
    )