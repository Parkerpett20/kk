# tools/group_management.py
import telebot
import logging
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_bot_instance = None
_data_dir = "data/group_management"
_users_dir = os.path.join(_data_dir, "users")
_groups_dir = os.path.join(_data_dir, "groups")

def _ensure_dirs():
    os.makedirs(_users_dir, exist_ok=True)
    os.makedirs(_groups_dir, exist_ok=True)

_ensure_dirs()

def set_bot_instance(bot):
    global _bot_instance
    _bot_instance = bot

def _load_group_config(chat_id: int) -> dict:
    filepath = os.path.join(_groups_dir, f"{chat_id}_config.json")
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading group config: {e}")
    return {
        "chat_id": chat_id,
        "rules": "",
        "welcome_enabled": True,
        "welcome_message": "",
        "goodbye_message": "",
        "antispam_enabled": True,
        "antispam_action": "ban",
        "flood_limit": 5,
        "flood_timeout": 10,
        "blacklist": [],
        "filters": {},
        "notes": {},
        "captcha_enabled": False,
        "mute_new_members": False
    }

def _save_group_config(chat_id: int, config: dict):
    filepath = os.path.join(_groups_dir, f"{chat_id}_config.json")
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Error saving group config: {e}")

def _load_user_data(chat_id: int, user_id: int) -> dict:
    filepath = os.path.join(_users_dir, f"{chat_id}_{user_id}.json")
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading user data: {e}")
    return {
        "user_id": user_id,
        "chat_id": chat_id,
        "warnings": [],
        "warn_count": 0,
        "is_banned": False,
        "is_muted": False,
        "mute_until": None,
        "message_count": 0,
        "last_messages": []
    }

def _save_user_data(chat_id: int, user_id: int, data: dict):
    filepath = os.path.join(_users_dir, f"{chat_id}_{user_id}.json")
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Error saving user data: {e}")

# =====================================================
# Warning System
# =====================================================
def warn_user(chat_id: int, user_id: int, reason: str, max_warnings: int = 3) -> str:
    """Warn a user. If max warnings reached, ban the user."""
    if _bot_instance is None:
        return "❌ Bot instance not initialized."
    
    try:
        user_data = _load_user_data(chat_id, user_id)
        warning = {
            "reason": reason,
            "timestamp": datetime.now().isoformat()
        }
        user_data["warnings"].append(warning)
        user_data["warn_count"] = len(user_data["warnings"])
        _save_user_data(chat_id, user_id, user_data)
        
        remaining = max_warnings - user_data["warn_count"]
        
        if user_data["warn_count"] >= max_warnings:
            try:
                _bot_instance.ban_chat_member(chat_id, user_id)
                user_data["is_banned"] = True
                _save_user_data(chat_id, user_id, user_data)
                return f"⚠️ هشدار {user_data['warn_count']}/{max_warnings}: {reason}\n\n🚫 کاربر به دلیل رسیدن به حداکثر هشدارها بن شد!"
            except Exception as e:
                return f"⚠️ هشدار {user_data['warn_count']}/{max_warnings}: {reason}\n\n❌ خطا در بن کردن: {str(e)}"
        
        return f"⚠️ هشدار {user_data['warn_count']}/{max_warnings}: {reason}\n\n💡 {remaining} هشدار دیگر باقی مانده تا بن."
    except Exception as e:
        return f"❌ خطا در ارسال هشدار: {str(e)}"

def get_warnings(chat_id: int, user_id: int) -> str:
    """Get warning history for a user."""
    user_data = _load_user_data(chat_id, user_id)
    if not user_data["warnings"]:
        return "ℹ️ این کاربر هشداری دریافت نکرده است."
    
    response = f"⚠️ تاریخچه هشدارهای کاربر {user_id}:\n\n"
    for i, w in enumerate(user_data["warnings"], 1):
        response += f"{i}. {w['reason']} ({w['timestamp']})\n"
    return response

def reset_warnings(chat_id: int, user_id: int) -> str:
    """Reset warnings for a user."""
    user_data = _load_user_data(chat_id, user_id)
    user_data["warnings"] = []
    user_data["warn_count"] = 0
    _save_user_data(chat_id, user_id, user_data)
    return "✅ هشدارهای کاربر با موفقیت ریست شد."

# =====================================================
# Ban/Unban System
# =====================================================
def ban_user(chat_id: int, user_id: int, reason: str = "") -> str:
    """Ban a user from the group."""
    if _bot_instance is None:
        return "❌ Bot instance not initialized."
    
    try:
        _bot_instance.ban_chat_member(chat_id, user_id)
        user_data = _load_user_data(chat_id, user_id)
        user_data["is_banned"] = True
        _save_user_data(chat_id, user_id, user_data)
        return f"🚫 کاربر {user_id} بن شد." + (f"\n📋 دلیل: {reason}" if reason else "")
    except telebot.apihelper.ApiTelegramException as e:
        return f"❌ خطا در بن کردن: {str(e)}"

def unban_user(chat_id: int, user_id: int) -> str:
    """Unban a user from the group."""
    if _bot_instance is None:
        return "❌ Bot instance not initialized."
    
    try:
        _bot_instance.unban_chat_member(chat_id, user_id)
        user_data = _load_user_data(chat_id, user_id)
        user_data["is_banned"] = False
        user_data["warnings"] = []
        user_data["warn_count"] = 0
        _save_user_data(chat_id, user_id, user_data)
        return f"✅ کاربر {user_id} از بن خارج شد."
    except telebot.apihelper.ApiTelegramException as e:
        return f"❌ خطا در خارج کردن از بن: {str(e)}"

# =====================================================
# Full Member List System (via Telethon or Bot API)
# =====================================================
def get_full_members_list(chat_id: int, bot_instance=None) -> tuple:
    """
    دریافت لیست کامل اعضای گروه
    
    Returns:
        (response_text, file_path, members_list) - متن پاسخ، مسیر فایل، و لیست اعضا
    """
    members = []
    
    # تلاش اول: Telethon
    from tools.telethon_client import is_available as telethon_available
    if telethon_available():
        from tools.telethon_client import get_chat_members
        members = get_chat_members(chat_id)
    
    # تلاش دوم: Bot API (اگه Telethon کار نکرد)
    if not members and bot_instance:
        try:
            member_count = bot_instance.get_chat_member_count(chat_id)
            # تلاش برای دریافت اطلاعات اعضا از گروه‌های ذخیره‌شده
            from handlers.group import group_manager
            saved_members = group_manager.get_members(chat_id)
            if saved_members:
                members = saved_members
            else:
                members = [{"user_id": 0, "first_name": f"تعداد کل اعضا: {member_count}", "username": "", "is_bot": False}]
        except Exception as e:
            logger.error(f"Error getting member count via Bot API: {e}")
    
    if not members:
        return (
            "❌ نتونستم لیست اعضا رو دریافت کنم.\n\n"
            "💡 دلایل احتمالی:\n"
            "1. Telethon پیکربندی نشده\n"
            "2. ربات ادمین نیست\n"
            "3. دسترسی کافی وجود ندارد\n\n"
            "🔧 راه‌حل: متغیرهای زیر را در فایل .env تنظیم کنید:\n"
            "TELETHON_API_ID=...\n"
            "TELETHON_API_HASH=...\n\n"
            "📎 یا از /members استفاده کنید (محدود به اطلاعات Bot API)"
        ), None, []
    
    # ساخت لیست متنی
    response = f"👥 لیست کامل اعضای گروه ({len(members)} نفر):\n\n"
    
    for i, member in enumerate(members, 1):
        name = member.get('first_name', '') or member.get('username', '') or 'نامشخص'
        username = member.get('username', '')
        is_bot = "🤖" if member.get('is_bot') else ""
        is_premium = "⭐" if member.get('is_premium') else ""
        
        if username:
            response += f"{i}. [{name}](https://t.me/{username}) {is_bot}{is_premium}\n"
        else:
            response += f"{i}. {name} (فاقد یوزرنیم) {is_bot}{is_premium}\n"
    
    # اگر لیست طولانی‌تر از 4000 کاراکتر بود، فایل بساز
    file_path = None
    if len(response) > 4000:
        file_path = os.path.join(_data_dir, f"members_{chat_id}.txt")
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(response)
            # متن کوتاه برگردون
            response = f"✅ لیست {len(members)} عضو دریافت شد!\n\n📎 فایل لیست رو برات می‌فرستم..."
        except Exception as e:
            logger.error(f"Error creating members file: {e}")
            file_path = None
    
    return response, file_path, members

def get_full_admins_list(chat_id: int, bot_instance=None) -> tuple:
    """
    دریافت لیست کامل ادمین‌های گروه
    
    Returns:
        (response_text, file_path, admins_list)
    """
    admins = []
    
    # تلاش اول: Telethon
    from tools.telethon_client import is_available as telethon_available
    if telethon_available():
        from tools.telethon_client import get_chat_admins
        admins = get_chat_admins(chat_id)
    
    # تلاش دوم: Bot API
    if not admins and bot_instance:
        try:
            bot_admins = bot_instance.get_chat_administrators(chat_id)
            for admin in bot_admins:
                admins.append({
                    "user_id": admin.user.id,
                    "username": admin.user.username or "",
                    "first_name": admin.user.first_name or "",
                    "is_bot": admin.user.is_bot,
                    "status": admin.status
                })
        except Exception as e:
            logger.error(f"Error getting admins via Bot API: {e}")
    
    if not admins:
        return "❌ نتونستم لیست ادمین‌ها رو دریافت کنم.", None, []
    
    response = f"👑 لیست ادمین‌های گروه ({len(admins)} نفر):\n\n"
    
    for i, admin in enumerate(admins, 1):
        name = admin.get('first_name', '') or admin.get('username', '') or 'نامشخص'
        username = admin.get('username', '')
        is_bot = "🤖" if admin.get('is_bot') else ""
        status = admin.get('status', '')
        
        status_text = ""
        if status == 'creator':
            status_text = " 👑مالک"
        elif status == 'administrator':
            status_text = " ⚡ادمین"
        
        if username:
            response += f"{i}. [{name}](https://t.me/{username}) {is_bot}{status_text}\n"
        else:
            response += f"{i}. {name} (فاقد یوزرنیم) {is_bot}{status_text}\n"
    
    file_path = None
    if len(response) > 4000:
        file_path = os.path.join(_data_dir, f"admins_{chat_id}.txt")
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(response)
            response = f"✅ لیست {len(admins)} ادمین دریافت شد!\n\n📎 فایل لیست رو برات می‌فرستم..."
        except Exception as e:
            logger.error(f"Error creating admins file: {e}")
            file_path = None
    
    return response, file_path, admins

def get_group_info_full(chat_id: int) -> str:
    """
    دریافت اطلاعات کامل گروه
    """
    from tools.telethon_client import is_available as telethon_available, get_chat_info
    
    if not telethon_available():
        return "❌ برای دریافت اطلاعات کامل، باید Telethon پیکربندی شده باشد."
    
    try:
        info = get_chat_info(chat_id)
        
        if not info:
            return "❌ نتونستم اطلاعات گروه رو دریافت کنم."
        
        response = f"ℹ️ اطلاعات کامل گروه:\n\n"
        response += f"📝 نام: {info.get('title', 'نامشخص')}\n"
        if info.get('username'):
            response += f"🔗 یوزرنیم: t.me/{info['username']}\n"
        else:
            response += f"🔗 یوزرنیم: ندارد\n"
        response += f"👥 تعداد اعضا: {info.get('member_count', 'نامشخص')}\n"
        response += f"📄 توضیحات: {info.get('description', 'ندارد')}\n"
        response += f"✅ تایید شده: {'بله' if info.get('is_verified') else 'خیر'}\n"
        response += f"🚫 اسکم: {'بله' if info.get('is_scam') else 'خیر'}\n"
        response += f"🎭 فیک: {'بله' if info.get('is_fake') else 'خیر'}\n"
        
        return response
        
    except Exception as e:
        return f"❌ خطا در دریافت اطلاعات گروه: {str(e)}"

# =====================================================
# Mute/Unmute System
# =====================================================
def mute_user(chat_id: int, user_id: int, duration_minutes: int = 0, reason: str = "") -> str:
    """Mute a user. duration_minutes=0 means permanent mute."""
    if _bot_instance is None:
        return "❌ Bot instance not initialized."
    
    try:
        permissions = telebot.types.ChatPermissions(
            can_send_messages=False,
            can_send_audios=False,
            can_send_documents=False,
            can_send_photos=False,
            can_send_videos=False,
            can_send_video_notes=False,
            can_send_voice_notes=False,
            can_send_polls=False,
            can_send_other_messages=False,
            can_add_web_page_previews=False,
            can_invite_users=False,
            can_change_info=False,
            can_pin_messages=False,
            can_manage_topics=False
        )
        
        until_date = None
        if duration_minutes > 0:
            until_date = datetime.now() + timedelta(minutes=duration_minutes)
        
        _bot_instance.restrict_chat_member(chat_id, user_id, permissions, until_date=until_date)
        
        user_data = _load_user_data(chat_id, user_id)
        user_data["is_muted"] = True
        user_data["mute_until"] = until_date.isoformat() if until_date else None
        _save_user_data(chat_id, user_id, user_data)
        
        duration_text = f" به مدت {duration_minutes} دقیقه" if duration_minutes > 0 else " دائمی"
        return f"🔇 کاربر {user_id} موت شد{duration_text}." + (f"\n📋 دلیل: {reason}" if reason else "")
    except telebot.apihelper.ApiTelegramException as e:
        return f"❌ خطا در موت کردن: {str(e)}"

def unmute_user(chat_id: int, user_id: int) -> str:
    """Unmute a user."""
    if _bot_instance is None:
        return "❌ Bot instance not initialized."
    
    try:
        permissions = telebot.types.ChatPermissions(
            can_send_messages=True,
            can_send_audios=True,
            can_send_documents=True,
            can_send_photos=True,
            can_send_videos=True,
            can_send_video_notes=True,
            can_send_voice_notes=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True,
            can_invite_users=True,
            can_change_info=False,
            can_pin_messages=False,
            can_manage_topics=False
        )
        
        _bot_instance.restrict_chat_member(chat_id, user_id, permissions)
        
        user_data = _load_user_data(chat_id, user_id)
        user_data["is_muted"] = False
        user_data["mute_until"] = None
        _save_user_data(chat_id, user_id, user_data)
        
        return f"🔊 کاربر {user_id} از موت خارج شد."
    except telebot.apihelper.ApiTelegramException as e:
        return f"❌ خطا در خارج کردن از موت: {str(e)}"

# =====================================================
# Kick System
# =====================================================
def kick_user(chat_id: int, user_id: int) -> str:
    """Kick a user from the group (they can rejoin)."""
    if _bot_instance is None:
        return "❌ Bot instance not initialized."
    
    try:
        _bot_instance.kick_chat_member(chat_id, user_id)
        return f"👢 کاربر {user_id} از گروه اخراج شد."
    except telebot.apihelper.ApiTelegramException as e:
        return f"❌ خطا در اخراج کاربر: {str(e)}"

# =====================================================
# Rules System
# =====================================================
def set_rules(chat_id: int, rules_text: str) -> str:
    """Set group rules."""
    config = _load_group_config(chat_id)
    config["rules"] = rules_text
    _save_group_config(chat_id, config)
    return "✅ قوانین گروه با موفقیت تنظیم شد."

def get_rules(chat_id: int) -> str:
    """Get group rules."""
    config = _load_group_config(chat_id)
    if not config["rules"]:
        return "ℹ️ هنوز قوانینی برای این گروه تنظیم نشده است."
    return f"📜 قوانین گروه:\n\n{config['rules']}"

def clear_rules(chat_id: int) -> str:
    """Clear group rules."""
    config = _load_group_config(chat_id)
    config["rules"] = ""
    _save_group_config(chat_id, config)
    return "✅ قوانین گروه پاک شد."

# =====================================================
# Notes System
# =====================================================
def set_note(chat_id: int, name: str, content: str) -> str:
    """Set a note."""
    config = _load_group_config(chat_id)
    config["notes"][name.lower()] = {
        "content": content,
        "created_at": datetime.now().isoformat()
    }
    _save_group_config(chat_id, config)
    return f"✅ نوت '{name}' با موفقیت ذخیره شد."

def get_note(chat_id: int, name: str) -> Optional[str]:
    """Get a note by name."""
    config = _load_group_config(chat_id)
    note = config["notes"].get(name.lower())
    if note:
        return note["content"]
    return None

def list_notes(chat_id: int) -> str:
    """List all notes."""
    config = _load_group_config(chat_id)
    if not config["notes"]:
        return "ℹ️ هیچ نوتی ذخیره نشده است."
    
    response = "📝 لیست نوت‌ها:\n\n"
    for name in config["notes"]:
        response += f"• /note_{name}\n"
    return response

def delete_note(chat_id: int, name: str) -> str:
    """Delete a note."""
    config = _load_group_config(chat_id)
    if name.lower() in config["notes"]:
        del config["notes"][name.lower()]
        _save_group_config(chat_id, config)
        return f"✅ نوت '{name}' حذف شد."
    return f"❌ نوت '{name}' یافت نشد."

# =====================================================
# Filters System
# =====================================================
def set_filter(chat_id: int, trigger: str, response_text: str) -> str:
    """Set an auto-reply filter."""
    config = _load_group_config(chat_id)
    config["filters"][trigger.lower()] = {
        "response": response_text,
        "created_at": datetime.now().isoformat()
    }
    _save_group_config(chat_id, config)
    return f"✅ فیلتر '{trigger}' با موفقیت ذخیره شد."

def get_filter_response(chat_id: int, text: str) -> Optional[str]:
    """Check if text matches any filter and return response."""
    config = _load_group_config(chat_id)
    text_lower = text.lower()
    for trigger, data in config["filters"].items():
        if trigger in text_lower:
            return data["response"]
    return None

def list_filters(chat_id: int) -> str:
    """List all filters."""
    config = _load_group_config(chat_id)
    if not config["filters"]:
        return "ℹ️ هیچ فیلتری تنظیم نشده است."
    
    response = "🔍 لیست فیلترها:\n\n"
    for trigger in config["filters"]:
        response += f"• {trigger}\n"
    return response

def delete_filter(chat_id: int, trigger: str) -> str:
    """Delete a filter."""
    config = _load_group_config(chat_id)
    if trigger.lower() in config["filters"]:
        del config["filters"][trigger.lower()]
        _save_group_config(chat_id, config)
        return f"✅ فیلتر '{trigger}' حذف شد."
    return f"❌ فیلتر '{trigger}' یافت نشد."

# =====================================================
# Blacklist System
# =====================================================
def add_to_blacklist(chat_id: int, word: str) -> str:
    """Add a word to the blacklist."""
    config = _load_group_config(chat_id)
    if word.lower() not in config["blacklist"]:
        config["blacklist"].append(word.lower())
        _save_group_config(chat_id, config)
        return f"✅ کلمه '{word}' به لیست سیاه اضافه شد."
    return f"ℹ️ کلمه '{word}' قبلاً در لیست سیاه وجود دارد."

def remove_from_blacklist(chat_id: int, word: str) -> str:
    """Remove a word from the blacklist."""
    config = _load_group_config(chat_id)
    if word.lower() in config["blacklist"]:
        config["blacklist"].remove(word.lower())
        _save_group_config(chat_id, config)
        return f"✅ کلمه '{word}' از لیست سیاه حذف شد."
    return f"❌ کلمه '{word}' در لیست سیاه یافت نشد."

def get_blacklist(chat_id: int) -> str:
    """Get the blacklist."""
    config = _load_group_config(chat_id)
    if not config["blacklist"]:
        return "ℹ️ لیست سیاه خالی است."
    
    response = "🚫 لیست سیاه:\n\n"
    for word in config["blacklist"]:
        response += f"• {word}\n"
    return response

def is_blacklisted(chat_id: int, text: str) -> bool:
    """Check if text contains any blacklisted word."""
    config = _load_group_config(chat_id)
    text_lower = text.lower()
    for word in config["blacklist"]:
        if word in text_lower:
            return True
    return False

# =====================================================
# Welcome/Goodbye Messages
# =====================================================
def set_welcome_message(chat_id: int, message: str) -> str:
    """Set custom welcome message."""
    config = _load_group_config(chat_id)
    config["welcome_message"] = message
    _save_group_config(chat_id, config)
    return "✅ پیام خوش‌آمدگویی با موفقیت تنظیم شد."

def set_goodbye_message(chat_id: int, message: str) -> str:
    """Set custom goodbye message."""
    config = _load_group_config(chat_id)
    config["goodbye_message"] = message
    _save_group_config(chat_id, config)
    return "✅ پیام خداحافظی با موفقیت تنظیم شد."

def toggle_welcome(chat_id: int, enabled: bool) -> str:
    """Toggle welcome messages on/off."""
    config = _load_group_config(chat_id)
    config["welcome_enabled"] = enabled
    _save_group_config(chat_id, config)
    status = "فعال" if enabled else "غیرفعال"
    return f"✅ پیام خوش‌آمدگویی {status} شد."

def get_welcome_message(chat_id: int) -> str:
    """Get the welcome message."""
    config = _load_group_config(chat_id)
    return config.get("welcome_message", "")

def get_goodbye_message(chat_id: int) -> str:
    """Get the goodbye message."""
    config = _load_group_config(chat_id)
    return config.get("goodbye_message", "")

# =====================================================
# Anti-Spam System
# =====================================================
def check_flood(chat_id: int, user_id: int) -> bool:
    """Check if user is flooding (sending too many messages)."""
    config = _load_group_config(chat_id)
    user_data = _load_user_data(chat_id, user_id)
    
    now = datetime.now()
    flood_limit = config.get("flood_limit", 5)
    flood_timeout = config.get("flood_timeout", 10)
    
    # Add current message timestamp
    user_data["last_messages"].append(now.isoformat())
    
    # Remove old messages outside the timeout window
    cutoff = now - timedelta(seconds=flood_timeout)
    user_data["last_messages"] = [
        ts for ts in user_data["last_messages"]
        if datetime.fromisoformat(ts) > cutoff
    ]
    
    _save_user_data(chat_id, user_id, user_data)
    
    # Check if flood limit exceeded
    if len(user_data["last_messages"]) > flood_limit:
        return True
    return False

def check_blacklist_violation(chat_id: int, text: str) -> bool:
    """Check if message contains blacklisted words."""
    return is_blacklisted(chat_id, text)

# =====================================================
# Captcha System
# =====================================================
def generate_captcha() -> tuple:
    """Generate a simple math captcha. Returns (question, answer)."""
    import random
    num1 = random.randint(1, 20)
    num2 = random.randint(1, 20)
    operation = random.choice(['+', '-'])
    
    if operation == '+':
        answer = num1 + num2
    else:
        answer = num1 - num2
    
    question = f"🔐 سوال امنیتی: {num1} {operation} {num2} = ?\nلطفاً پاسخ عددی رو ارسال کنید."
    return question, str(answer)

# =====================================================
# Utility Functions
# =====================================================
def get_user_status(chat_id: int, user_id: int) -> str:
    """Get user status (warnings, ban, mute)."""
    user_data = _load_user_data(chat_id, user_id)
    
    status_parts = []
    if user_data["is_banned"]:
        status_parts.append("🚫 بن شده")
    if user_data["is_muted"]:
        status_parts.append("🔇 موت شده")
    if user_data["warn_count"] > 0:
        status_parts.append(f"⚠️ {user_data['warn_count']} هشدار")
    
    if not status_parts:
        return "ℹ️ وضعیت: عادی"
    
    return "📊 وضعیت کاربر:\n" + "\n".join(status_parts)

def get_group_stats(chat_id: int) -> str:
    """Get group statistics."""
    config = _load_group_config(chat_id)
    
    stats = [
        f"📊 آمار گروه:",
        f"",
        f"📝 قوانین: {'✅ تنظیم شده' if config.get('rules') else '❌ تنظیم نشده'}",
        f"👋 خوش‌آمدگویی: {'✅ فعال' if config.get('welcome_enabled') else '❌ غیرفعال'}",
        f"🚫 ضد اسپم: {'✅ فعال' if config.get('antispam_enabled') else '❌ غیرفعال'}",
        f"📋 لیست سیاه: {len(config.get('blacklist', []))} کلمه",
        f"🔍 فیلترها: {len(config.get('filters', {}))} عدد",
        f"📝 نوت‌ها: {len(config.get('notes', {}))} عدد",
        f"💬 محدودیت پیام: {config.get('flood_limit', 5)} پیام در {config.get('flood_timeout', 10)} ثانیه"
    ]
    
    return "\n".join(stats)

def invite_chat_member(chat_id: int, user_id: int = None, username: str = None, phone_number: str = None) -> str:
    """
    Invite a user to a Telegram group chat.

    Args:
        chat_id: The chat ID of the group
        user_id: The user ID to invite
        username: The username to invite (without @)
        phone_number: Phone number to invite (e.g. +989121234567 or 09121234567)

    Returns:
        Result message indicating success or failure
    """
    if _bot_instance is None:
        return "❌ Bot instance not initialized. Please restart the bot."

    try:
        # اگر شماره تلفن داده شده، user_id رو رفع بده
        if phone_number and not user_id:
            from tools.telethon_client import is_available, resolve_phone_to_user_id

            if not is_available():
                return (
                    "❌ برای اضافه کردن با شماره تلفن، ابتدا باید یوزرنیم یا آیدی عددی کاربر رو بدید.\n"
                    "یا از مدیر سیستم بخواهید Telethon رو پیکربندی کنه.\n\n"
                    "💡 لینک دعوت هم میتونه کمک کنه:"
                )

            user_id = resolve_phone_to_user_id(phone_number)
            if not user_id:
                return (
                    f"❌ کاربری با شماره {phone_number} یافت نشد.\n"
                    "دلایل احتمالی:\n"
                    "- شماره اشتباه است\n"
                    "- کاربر اکانت تلگرام ندارد\n"
                    "- کاربر تنظیمات حریم خصوصی دارد که جستجو رو غیرفعال کرده\n\n"
                    "💡 راه‌حل: از کاربر بخواهید یوزرنیم یا آیدی عددی خودش رو بده."
                )

        # اگر یوزرنیم داده شده ولی user_id نه، اول سعی کن با Bot API دعوت کنی
        if username and not user_id:
            username = username.lstrip("@")

            # تلاش اول: مستقیم با Bot API (user_id به صورت string)
            try:
                result = _bot_instance.invite_chat_member(chat_id, username)
                if result:
                    return f"✅ کاربر @{username} به گروه دعوت شد!"
            except telebot.apihelper.ApiTelegramException as api_err:
                error_msg = str(api_err)
                # اگه خطای USER_NOT_PARTICIPANT بود، یعنی یوزرنیم معتبر نیست
                if "USER_NOT_PARTICIPANT" not in error_msg and "PEER_ID_INVALID" not in error_msg:
                    # خطای دیگه‌ای هست، شاید کاربر قبلا عضو بوده
                    if "USER_IS_PARTICIPANT" in error_msg:
                        return f"ℹ️ کاربر @{username} قبلاً در گروه عضو است."

            # تلاش دوم: اگه Telethon در دسترس بود، user_id رو رفع بده
            from tools.telethon_client import is_available, resolve_username_to_user_id

            if is_available():
                user_id = resolve_username_to_user_id(username)
                if user_id:
                    result = _bot_instance.invite_chat_member(chat_id, user_id)
                    if result:
                        return f"✅ کاربر @{username} به گروه دعوت شد!"

            # اگه هیچکدوم جواب نداد
            return (
                f"❌ نتونستم کاربر @{username} رو به گروه اضافه کنم.\n"
                "دلایل احتمالی:\n"
                "- یوزرنیم اشتباه است\n"
                "- کاربر تنظیمات حریم خصوصی دارد\n"
                "- کاربر اکانت ندارد\n\n"
                "💡 راه‌حل: از کاربر بخواهید آیدی عددی یا شماره تلفن خودش رو بده."
            )

        if user_id:
            result = _bot_instance.invite_chat_member(chat_id, user_id)
            if result:
                return f"✅ کاربر {user_id} به گروه دعوت شد!"
            else:
                return f"❌ دعوت کاربر {user_id} ناموفق بود. ممکنه تنظیمات حریم خصوصی مانع اضافه شدن بشه."

        return (
            "❌ لطفاً یکی از موارد زیر رو بدید:\n"
            "- شماره تلفن (مثلاً 09121234567)\n"
            "- یوزرنیم (مثلاً ali123)\n"
            "- آیدی عددی (مثلاً 123456789)"
        )

    except telebot.apihelper.ApiTelegramException as e:
        error_msg = str(e)
        if "USER_IS_PARTICIPANT" in error_msg:
            return "ℹ️ این کاربر قبلاً در گروه عضو است."
        elif "USER_NOT_PARTICIPANT" in error_msg:
            return "❌ کاربر یافت نشد. ممکنه پروفایل خصوصی داشته باشه."
        elif "CHAT_ADMIN_REQUIRED" in error_msg:
            return "❌ من به عنوان ادمین گروه باید دسترسی اضافه کردن عضو داشته باشم."
        elif "USER_DEACTIVATED" in error_msg:
            return "❌ این اکانت کاربر غیرفعال شده."
        elif "USER_BANNED" in error_msg:
            return "❌ این کاربر از گروه بن شده."
        elif "USER_RESTRICTED" in error_msg:
            return "❌ این کاربر تنظیمات محدودکننده داره."
        elif "PEER_ID_INVALID" in error_msg:
            return "❌ آیدی کاربر نامعتبره. لطفاً دوباره بررسی کنید."
        else:
            return f"❌ خطا در دعوت کاربر: {error_msg}"
    except Exception as e:
        logger.error(f"Error in invite_chat_member: {e}")
        return f"❌ خطای غیرمنتظره: {str(e)}"

def create_group_invite_link(chat_id: int) -> str:
    """
    Create an invite link for the group.

    Args:
        chat_id: The chat ID of the group

    Returns:
        The invite link or error message
    """
    if _bot_instance is None:
        return "❌ Bot instance not initialized. Please restart the bot."

    try:
        invite_link = _bot_instance.create_chat_invite_link(chat_id)
        if invite_link and invite_link.invite_link:
            return f"🔗 لینک دعوت گروه:\n{invite_link.invite_link}\n\nاین لینک رو با کسایی که میخواید اضافه کنید به اشتراک بذارید!"
        else:
            return "❌ ساخت لینک دعوت ناموفق بود. ممکنه دسترسی لازم رو نداشته باشم."
    except telebot.apihelper.ApiTelegramException as e:
        error_msg = str(e)
        if "CHAT_ADMIN_REQUIRED" in error_msg:
            return "❌ برای ساخت لینک دعوت به دسترسی ادمین نیاز دارم."
        elif "CHAT_WRITE Forbidden" in error_msg:
            return "❌ دسترسی ساخت لینک دعوت رو ندارم."
        else:
            return f"❌ خطا در ساخت لینک دعوت: {error_msg}"
    except Exception as e:
        logger.error(f"Error in create_group_invite_link: {e}")
        return f"❌ خطای غیرمنتظره: {str(e)}"

def get_group_admins(chat_id: int) -> str:
    """
    Get list of admins in the group.

    Args:
        chat_id: The chat ID of the group

    Returns:
        Formatted list of admins or error message
    """
    if _bot_instance is None:
        return "❌ Bot instance not initialized. Please restart the bot."

    try:
        admins = _bot_instance.get_chat_administrators(chat_id)
        if not admins:
            return "ℹ️ ادمینی در این گروه یافت نشد."

        response = "👑 ادمین‌های گروه:\n\n"
        for i, admin in enumerate(admins, 1):
            user = admin.user
            name = user.first_name or "نامشخص"
            username = f"t.me/{user.username}" if user.username else "فاقد یوزرنیم"
            status = admin.status
            response += f"{i}. {name} ({username}) - {status}\n"

        return response
    except telebot.apihelper.ApiTelegramException as e:
        error_msg = str(e)
        if "CHAT_ADMIN_REQUIRED" in error_msg:
            return "❌ برای مشاهده ادمین‌ها به دسترسی ادمین نیاز دارم."
        else:
            return f"❌ خطا در دریافت ادمین‌ها: {error_msg}"
    except Exception as e:
        logger.error(f"Error in get_group_admins: {e}")
        return f"❌ خطای غیرمنتظره: {str(e)}"
