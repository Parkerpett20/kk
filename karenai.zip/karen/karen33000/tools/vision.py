# tools/vision.py
import os
import logging
from pathlib import Path
from typing import Optional, Dict
from google import genai
from google.genai import types
from config import GEMINI_API_KEY, MODELS

logger = logging.getLogger(__name__)

# Initialize client
try:
    client = genai.Client(api_key=GEMINI_API_KEY)
    logger.debug("Gemini client initialized for vision tasks")
except Exception as e:
    logger.error(f"Failed to initialize Gemini client: {e}")
    client = None

# Constants
WORKSPACE_DIR = "workspace"
SUPPORTED_FORMATS = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
}
MAX_IMAGE_SIZE = 20 * 1024 * 1024  # 20MB limit
DEFAULT_PROMPT = "Please analyze this image and provide a detailed description."


def _validate_file_path(filename: str) -> tuple[bool, str]:
    """Validate and sanitize file path
    
    Returns:
        Tuple of (is_valid, safe_path)
    """
    if not filename or not isinstance(filename, str):
        return False, ""
    
    # Get safe path
    basename = os.path.basename(filename)
    safe_path = os.path.join(WORKSPACE_DIR, basename)
    
    # Check file exists
    if not os.path.exists(safe_path):
        return False, safe_path
    
    # Check file extension
    file_ext = os.path.splitext(basename)[1].lower()
    if file_ext not in SUPPORTED_FORMATS:
        return False, safe_path
    
    return True, safe_path


def _get_mime_type(filename: str) -> str:
    """Get MIME type from filename"""
    file_ext = os.path.splitext(filename)[1].lower()
    return SUPPORTED_FORMATS.get(file_ext, 'image/jpeg')


def _validate_prompt(prompt: str) -> bool:
    """Validate analysis prompt"""
    if not prompt or not isinstance(prompt, str):
        return False
    if len(prompt.strip()) == 0:
        return False
    if len(prompt) > 2000:  # Reasonable limit
        return False
    return True


def analyze_image_file(filename: str, prompt: str = None) -> str:
    """Analyzes an image file using Google's vision model.
    
    Args:
        filename: Name of the image file in workspace (e.g., 'chart.png')
        prompt: Analysis question or instructions (optional)
    
    Returns:
        Analysis result or error message with emoji indicator
    
    Supported formats: .jpg, .jpeg, .png, .gif, .webp
    
    Example:
        >>> analyze_image_file("chart.png", "What does this chart show?")
    """
    # Validate client
    if not client:
        error_msg = "Vision service not initialized"
        logger.error(error_msg)
        return f"❌ {error_msg}"
    
    # Use default prompt if not provided
    if prompt is None:
        prompt = DEFAULT_PROMPT
    
    # Validate inputs
    if not _validate_prompt(prompt):
        error_msg = "Invalid prompt: Please provide a non-empty prompt (max 2000 chars)"
        logger.warning(f"Invalid prompt: {prompt}")
        return f"❌ {error_msg}"
    
    # Validate and get safe path
    is_valid, safe_path = _validate_file_path(filename)
    
    if not is_valid:
        if not os.path.exists(safe_path):
            error_msg = f"Image not found: {safe_path}"
            logger.warning(error_msg)
            return f"❌ {error_msg}"
        else:
            file_ext = os.path.splitext(filename)[1].lower()
            error_msg = f"Unsupported image format: {file_ext}. Supported: {', '.join(SUPPORTED_FORMATS.keys())}"
            logger.warning(error_msg)
            return f"❌ {error_msg}"
    
    logger.info(f"Analyzing image: {filename}")
    
    try:
        # Check file size
        file_size = os.path.getsize(safe_path)
        if file_size > MAX_IMAGE_SIZE:
            error_msg = f"Image too large: {file_size / 1024 / 1024:.1f}MB (max 20MB)"
            logger.warning(error_msg)
            return f"⚠️ {error_msg}"
        
        logger.debug(f"Image file size: {file_size / 1024:.1f}KB")
        
        # Read image
        with open(safe_path, "rb") as f:
            image_data = f.read()
        
        logger.debug(f"Loaded {len(image_data)} bytes from {safe_path}")
        
        # Get MIME type
        mime_type = _get_mime_type(filename)
        
        # Create image part
        image_part = types.Part.from_bytes(data=image_data, mime_type=mime_type)
        
        # Analyze with vision model
        logger.debug(f"Calling vision model with prompt: {prompt[:50]}...")
        response = client.models.generate_content(
            model=MODELS.get("vision", "gemini-2.0-flash"),
            contents=[image_part, prompt]
        )
        
        result = response.text.strip() if response and response.text else ""
        
        if not result:
            logger.warning(f"Empty response from vision model for {filename}")
            return "⚠️ Vision model returned empty response"
        
        logger.info(f"Image analysis complete: {len(result)} characters")
        return result
        
    except IOError as ie:
        error_msg = f"File read error: {str(ie)}"
        logger.error(error_msg)
        return f"❌ {error_msg}"
    
    except Exception as e:
        error_msg = f"Vision analysis error: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


def analyze_image_url(image_url: str, prompt: str = None) -> str:
    """Analyzes an image from a URL using Google's vision model.
    
    Args:
        image_url: Direct URL to the image
        prompt: Analysis question or instructions (optional)
    
    Returns:
        Analysis result or error message
    """
    if not client:
        return "❌ Vision service not initialized"
    
    if not image_url or not isinstance(image_url, str):
        return "❌ Invalid URL provided"
    
    if not image_url.startswith(('http://', 'https://')):
        return "❌ URL must start with http:// or https://"
    
    if prompt is None:
        prompt = DEFAULT_PROMPT
    
    if not _validate_prompt(prompt):
        return "❌ Invalid prompt"
    
    logger.info(f"Analyzing image from URL: {image_url[:50]}...")
    
    try:
        # Fetch image from URL
        import urllib.request
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        req = urllib.request.Request(image_url, headers=headers)
        with urllib.request.urlopen(req, timeout=15) as response:
            image_data = response.read()
        
        logger.debug(f"Downloaded {len(image_data)} bytes from URL")
        
        # Determine MIME type
        mime_type = response.headers.get('Content-Type', 'image/jpeg')
        
        # Analyze
        image_part = types.Part.from_bytes(data=image_data, mime_type=mime_type)
        response = client.models.generate_content(
            model=MODELS.get("vision", "gemini-2.0-flash"),
            contents=[image_part, prompt]
        )
        
        return response.text.strip() if response and response.text else "⚠️ Empty response"
        
    except Exception as e:
        error_msg = f"Error analyzing URL image: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


def get_supported_formats() -> Dict[str, str]:
    """Get supported image formats
    
    Returns:
        Dictionary of file extensions to MIME types
    """
    return SUPPORTED_FORMATS.copy()
