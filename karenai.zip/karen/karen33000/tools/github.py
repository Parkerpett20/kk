# tools/github.py
import urllib.request
import json
import logging
from typing import Optional, Dict
from urllib.error import URLError, HTTPError

logger = logging.getLogger(__name__)

# Constants
GITHUB_API_URL = "https://api.github.com"
DEFAULT_TIMEOUT = 15
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Karen-Agent/1.0"


def _validate_github_params(owner: str, repo: str) -> bool:
    """Validate GitHub owner and repo name format"""
    if not owner or not isinstance(owner, str):
        return False
    if not repo or not isinstance(repo, str):
        return False
    
    # GitHub allows alphanumeric, hyphens, and underscores
    if not all(c.isalnum() or c in '-_' for c in owner):
        return False
    if not all(c.isalnum() or c in '-_.' for c in repo):
        return False
    
    return True


def get_repo_info(owner: str, repo: str) -> str:
    """Fetches details about a public GitHub repository.
    
    Args:
        owner: GitHub username or organization name
        repo: Repository name
    
    Returns:
        Formatted repository information or error message with emoji indicator
    
    Example:
        >>> get_repo_info("torvalds", "linux")
    """
    # Validate inputs
    if not _validate_github_params(owner, repo):
        error_msg = "Invalid GitHub owner or repository name format"
        logger.warning(f"Invalid GitHub params: owner='{owner}', repo='{repo}'")
        return f"❌ {error_msg}"
    
    logger.info(f"Fetching GitHub repo info: {owner}/{repo}")
    
    url = f"{GITHUB_API_URL}/repos/{owner}/{repo}"
    
    try:
        headers = {'User-Agent': USER_AGENT}
        req = urllib.request.Request(url, headers=headers)
        
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
            data = json.loads(response.read().decode('utf-8'))
            
            # Extract information
            full_name = data.get('full_name', f'{owner}/{repo}')
            description = data.get('description', 'No description')
            stars = data.get('stargazers_count', 0)
            forks = data.get('forks_count', 0)
            language = data.get('language', 'Unknown')
            watchers = data.get('watchers_count', 0)
            updated = data.get('updated_at', 'Unknown')
            url_link = data.get('html_url', url)
            
            logger.info(f"Successfully fetched info for {full_name}")
            
            result = (
                f"📦 Repository: {full_name}\n"
                f"📝 Description: {description}\n"
                f"⭐ Stars: {stars:,} | 🍴 Forks: {forks:,} | 👁️ Watchers: {watchers:,}\n"
                f"💻 Language: {language}\n"
                f"🕐 Last Updated: {updated}\n"
                f"🔗 URL: {url_link}"
            )
            
            return result
            
    except HTTPError as he:
        if he.code == 404:
            error_msg = "Repository not found (404)"
        elif he.code == 403:
            error_msg = "Access forbidden - API rate limit exceeded (403)"
        elif he.code == 401:
            error_msg = "Authentication required (401)"
        else:
            error_msg = f"GitHub API error ({he.code})"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except URLError as ue:
        error_msg = f"Cannot reach GitHub API: {ue.reason}"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except json.JSONDecodeError as je:
        error_msg = "Invalid JSON response from GitHub API"
        logger.error(f"{error_msg}: {je}")
        return f"❌ {error_msg}"
    
    except Exception as e:
        error_msg = f"GitHub API error: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


def search_repositories(query: str, language: str = None, sort: str = "stars") -> str:
    """Search for repositories on GitHub.
    
    Args:
        query: Search query (e.g., "machine learning Python")
        language: Filter by programming language
        sort: Sort results by "stars", "forks", or "updated"
    
    Returns:
        Formatted search results or error message
    """
    if not query or not isinstance(query, str):
        error_msg = "Invalid search query"
        logger.warning(f"Invalid GitHub search query: {query}")
        return f"❌ {error_msg}"
    
    if len(query.strip()) < 2:
        return "❌ Search query must be at least 2 characters"
    
    logger.info(f"Searching GitHub repositories: {query}")
    
    try:
        # Build search URL
        search_q = query
        if language:
            search_q += f" language:{language}"
        
        url = f"{GITHUB_API_URL}/search/repositories?q={urllib.parse.quote(search_q)}&sort={sort}&order=desc&per_page=5"
        
        headers = {'User-Agent': USER_AGENT}
        req = urllib.request.Request(url, headers=headers)
        
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
            data = json.loads(response.read().decode('utf-8'))
            items = data.get('items', [])
            
            if not items:
                logger.warning(f"No repositories found for: {query}")
                return f"⚠️ No repositories found for: {query}"
            
            result = f"🔍 Search Results for: {query}\n\n"
            for i, repo in enumerate(items[:5], 1):
                result += (
                    f"{i}. 📦 {repo['full_name']}\n"
                    f"   ⭐ {repo['stargazers_count']:,} stars\n"
                    f"   📝 {repo.get('description', 'No description')[:100]}\n\n"
                )
            
            logger.info(f"Found {len(items)} repositories matching: {query}")
            return result
            
    except Exception as e:
        error_msg = f"Search error: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


def get_user_info(username: str) -> str:
    """Fetch GitHub user/organization information.
    
    Args:
        username: GitHub username or organization name
    
    Returns:
        Formatted user information or error message
    """
    if not username or not isinstance(username, str):
        return "❌ Invalid username"
    
    if not all(c.isalnum() or c in '-_' for c in username):
        return "❌ Invalid username format"
    
    logger.info(f"Fetching GitHub user info: {username}")
    
    try:
        url = f"{GITHUB_API_URL}/users/{username}"
        headers = {'User-Agent': USER_AGENT}
        req = urllib.request.Request(url, headers=headers)
        
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
            data = json.loads(response.read().decode('utf-8'))
            
            result = (
                f"👤 User: {data.get('login', username)}\n"
                f"📝 Name: {data.get('name', 'N/A')}\n"
                f"📍 Location: {data.get('location', 'N/A')}\n"
                f"📚 Public Repos: {data.get('public_repos', 0)}\n"
                f"👥 Followers: {data.get('followers', 0)} | Following: {data.get('following', 0)}\n"
                f"🔗 URL: {data.get('html_url', 'N/A')}\n"
                f"🖼️ Avatar:\n![avatar]({data.get('avatar_url', '')})"
            )
            
            logger.info(f"Successfully fetched user info for {username}")
            return result
            
    except Exception as e:
        error_msg = f"Error fetching user info: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


def get_trending_repos(language: str = None, since: str = "daily") -> str:
    """Get trending repositories (using GitHub API alternative).
    
    Args:
        language: Programming language filter
        since: "daily", "weekly", or "monthly"
    
    Returns:
        Formatted trending repositories or error message
    
    Note: Uses an alternative source since GitHub doesn't have official trending API
    """
    logger.info(f"Fetching trending repositories ({since})")
    
    try:
        # Alternative: Use GitHub Search API to find popular recent repos
        query = "stars:>1000"
        if language:
            query += f" language:{language}"
        
        url = f"{GITHUB_API_URL}/search/repositories?q={urllib.parse.quote(query)}&sort=stars&order=desc&per_page=10"
        
        headers = {'User-Agent': USER_AGENT}
        req = urllib.request.Request(url, headers=headers)
        
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
            data = json.loads(response.read().decode('utf-8'))
            items = data.get('items', [])
            
            result = f"🔥 Trending Repositories ({since})\n\n"
            for i, repo in enumerate(items[:5], 1):
                result += (
                    f"{i}. 📦 {repo['full_name']}\n"
                    f"   ⭐ {repo['stargazers_count']:,} stars\n"
                    f"   💬 {repo.get('description', 'No description')[:80]}\n\n"
                )
            
            return result
            
    except Exception as e:
        logger.error(f"Error fetching trending repos: {e}")
        return f"❌ Error fetching trending repositories: {str(e)}"


# Add urllib.parse for URL encoding
import urllib.parse
