# tools/youtube.py
import urllib.request
import urllib.parse
import re
import logging
from typing import List, Dict

logger = logging.getLogger(__name__)


def _validate_query(query: str) -> bool:
    """Validate search query"""
    if not query or not isinstance(query, str):
        return False
    if len(query.strip()) < 2:
        return False
    return True


def search_youtube(query: str) -> str:
    """Searches YouTube for videos and returns titles and links.
    Args:
        query: The search query (e.g., 'Python tutorials', 'machine learning').
    Returns:
        Formatted string with up to 5 video results or a direct search link.
    """
    # Validate input
    if not _validate_query(query):
        logger.warning(f"Invalid YouTube query: {query}")
        return "Error: Please provide a valid search query (at least 2 characters)."
    
    logger.info(f"Searching YouTube for: {query}")
    
    # YouTube blocks direct scraping; provide a direct search link as fallback
    try:
        # Encode query for URL
        encoded_query = urllib.parse.quote(query)
        search_url = f"https://www.youtube.com/results?search_query={encoded_query}"
        
        # Try to fetch and parse
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9'
        }
        
        logger.debug(f"Attempting to fetch: {search_url}")
        req = urllib.request.Request(search_url, headers=headers)
        
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8', errors='ignore')
            results = _extract_videos_from_html(html)
            
            if results:
                # Format successful results
                formatted_results = []
                for idx, video in enumerate(results[:5], 1):
                    formatted_results.append(
                        f"{idx}. {video['title'][:80]}\n   🔗 https://www.youtube.com/watch?v={video['id']}"
                    )
                output = "🎬 YouTube Search Results:\n\n" + "\n\n".join(formatted_results)
                logger.info(f"Found {len(results)} videos for: {query}")
                return output
    
    except (urllib.error.HTTPError, urllib.error.URLError, Exception) as e:
        logger.debug(f"Direct scraping failed ({type(e).__name__}), using fallback link")
    
    # Fallback: provide direct YouTube search link
    search_url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}"
    return (
        f"🎬 YouTube Search for: {query}\n\n"
        f"I couldn't access YouTube directly (it blocks automated requests).\n"
        f"But you can search here:\n\n"
        f"🔗 {search_url}\n\n"
        f"Just click the link above to see the results!"
    )


def _extract_videos_from_html(html: str) -> List[Dict[str, str]]:
    """Extract video information from YouTube HTML response.
    
    Tries multiple patterns for better robustness.
    """
    results = []
    seen_ids = set()
    
    try:
        # Pattern 1: Standard videoId and title extraction
        pattern1 = r'"videoId":"([^"]+)".*?"title":\s*\{"runs":\s*\[\{"text":"([^"]+)"\}'
        matches1 = re.findall(pattern1, html)
        
        for video_id, title in matches1:
            if video_id not in seen_ids and title:
                seen_ids.add(video_id)
                results.append({
                    "id": video_id,
                    "title": title.replace('\\', '')
                })
        
        # Pattern 2: Alternative pattern for recent HTML structure
        if not results:
            pattern2 = r'href="\/watch\?v=([^"]+)".*?title="([^"]+)"'
            matches2 = re.findall(pattern2, html)
            
            for video_id, title in matches2:
                if video_id not in seen_ids and title:
                    seen_ids.add(video_id)
                    results.append({
                        "id": video_id,
                        "title": title
                    })
        
        logger.debug(f"Extracted {len(results)} videos using patterns")
        
    except Exception as e:
        logger.error(f"Error extracting videos from HTML: {e}")
    
    return results


def get_youtube_video_info(video_id: str) -> str:
    """Get basic information about a specific YouTube video.
    
    Args:
        video_id: YouTube video ID (found in URLs like youtube.com/watch?v=VIDEO_ID)
    
    Returns:
        Video information or direct link to video
    """
    # Validate video ID format
    if not video_id or not re.match(r'^[a-zA-Z0-9_-]{11}$', video_id):
        logger.warning(f"Invalid YouTube video ID: {video_id}")
        return "Error: Invalid YouTube video ID format. (Must be 11 alphanumeric characters)"
    
    try:
        logger.info(f"Fetching info for video: {video_id}")
        url = f"https://www.youtube.com/watch?v={video_id}"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Language': 'en-US,en;q=0.9'
        }
        
        req = urllib.request.Request(url, headers=headers)
        
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8', errors='ignore')
            
            # Try to extract title from page title tag
            title_match = re.search(r'<title>(.+?)</title>', html)
            if title_match:
                title = title_match.group(1).replace(' - YouTube', '').strip()
                return f"🎥 Video: {title}\n🔗 {url}"
    
    except (urllib.error.HTTPError, urllib.error.URLError, Exception) as e:
        logger.debug(f"Direct scraping failed for {video_id}: {type(e).__name__}")
    
    # Fallback: provide direct link to video
    return (
        f"🎥 YouTube Video\n\n"
        f"I couldn't fetch the exact title (YouTube blocks automated requests),\n"
        f"but here's the direct link:\n\n"
        f"🔗 https://www.youtube.com/watch?v={video_id}\n\n"
        f"Click the link to watch the video!"
    )
