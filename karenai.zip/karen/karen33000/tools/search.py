# tools/search.py
import re
import logging
from google.genai import types
from config import EXA_API_KEY

logger = logging.getLogger(__name__)


def get_search_tool() -> types.Tool:
    """Returns Google Search tool in Gemini SDK format."""
    try:
        tool = types.Tool(googleSearch=types.GoogleSearch())
        logger.debug("Google Search tool initialized successfully")
        return tool
    except Exception as e:
        logger.error(f"Failed to initialize Google Search tool: {e}", exc_info=True)
        raise


def create_search_enabled_model(client):
    """Attempt to create or configure a model with search enabled.

    This is a lightweight helper that should not raise with mock clients
    used in tests. Returns a small descriptor or None if it cannot be
    created.
    """
    try:
        if not client:
            return None
        # Some SDKs may support configuring tools on model creation.
        # For now return a simple descriptor for test compatibility.
        return {"search_enabled": True}
    except Exception:
        logger.exception("Failed to create search-enabled model")
        return None


def _search_via_exa(query: str, num_results: int = 5) -> str:
    """Search using Exa AI API.

    Args:
        query: Search query string
        num_results: Number of results to return

    Returns:
        Formatted search results (real data), or empty string on failure
        (missing key, missing package, or search error) so that callers
        never inject fake/placeholder results into the model prompt.
    """
    if not EXA_API_KEY:
        logger.error("EXA_API_KEY خالی است؛ جستجوی واقعی وب غیرفعال است.")
        return ""

    try:
        from exa_py import Exa
    except ImportError:
        logger.error("پکیج exa-py نصب نیست. ابتدا نصب کنید: pip install exa-py")
        return ""

    try:
        exa = Exa(EXA_API_KEY)
        try:
            result = exa.search(
                query,
                num_results=min(num_results, 10),
                type="auto",
                contents={"highlights": True}
            )
        except TypeError:
            # سازگاری با نسخه‌های قدیمی‌تر SDK
            result = exa.search_and_contents(
                query,
                num_results=min(num_results, 10),
                highlights=True,
                text=False
            )

        if not result.results:
            return f"No results found for '{query}'."

        # قالب‌بندی نتایج
        out_lines = [f"Top results for '{query}':"]
        for i, r in enumerate(result.results[:num_results], start=1):
            title = (r.title or "").strip()
            url = r.url or ""
            snippet = ""

            if getattr(r, "highlights", None) and r.highlights:
                snippet = (r.highlights[0] or "").strip()
            elif getattr(r, "text", None):
                snippet = str(r.text).strip()
                if not title and getattr(r, "title", None) is None:
                    title = snippet[:80]

            # تمیزکاری متن‌های به‌هم‌ریخته‌ی استخراجی
            if snippet:
                snippet = re.sub(r"\s+", " ", snippet).strip()[:300]

            out_lines.append(f"{i}. {title}")
            if snippet:
                out_lines.append(f"   {snippet}")
            if url:
                out_lines.append(f"   {url}")

        return "\n".join(out_lines)

    except Exception as e:
        logger.warning(f"Exa search failed: {e}")
        return ""


def perform_web_search(query: str, **kwargs) -> str:
    """Perform a web search using Exa AI.

    Args:
        query: Search query string
        **kwargs: Additional args (ignored)

    Returns:
        Real search results as a formatted string, or an empty string when
        a live search could not be performed. An empty result lets the
        caller know no real data was fetched (instead of a misleading stub).
    """
    if not query or not isinstance(query, str):
        logger.warning(f"Invalid search query: {query}")
        return "Invalid search query. Please provide a non-empty string."

    logger.info(f"Performing web search for: {query}")

    # جستجوی واقعی با Exa AI
    exa_result = _search_via_exa(query)
    if exa_result:
        logger.debug("Search completed via Exa AI")
        return exa_result

    # بدون نتیجه‌ی واقعی، متن جعلی برنگردان؛ خالی برگردان تا مدل
    # گمراه نشود و متن‌های ساختگی را به‌عنوان خبر جا نزند.
    logger.error(f"وب‌سرچ برای «{query}» نتیجه‌ی واقعی برنگرداند (Exa).")
    return ""