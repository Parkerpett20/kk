# tools/secretary_service.py
"""
سرویس منشی شخصی - پاسخ هوشمند به پیام‌های دریافتی کاربر از اکانت خودش
حالت‌ها:
- always: همیشه جواب بده
- offline: فقط وقتی کاربر آفلاین است جواب بده
- manual: فقط پیام‌ها را فوروارد کن (کاربر خودش جواب می‌دهد)
"""
import threading
import logging
import asyncio
import time
from tools.userbot_manager import get_client_for_user, is_user_online, async_is_user_online, _get_or_create_loop, _run_async
from core.executor import AgentExecutor
from memory.user_settings import user_settings

logger = logging.getLogger(__name__)

_monitor_threads = {}  # user_id -> Thread
_active_monitors = set()  # user_ids that have active monitoring
_monitor_tasks = {}  # user_id -> asyncio.Task (the monitoring task on the shared loop)

# جلوگیری از loop بی‌نهایت: ذخیره زمان آخرین پاسخ به هر sender
# {user_id: {sender_id: last_reply_timestamp}}
_reply_cooldowns = {}
_REPLY_COOLDOWN_SECONDS = 3  # حداقل فاصله بین پاسخ‌ها (فقط برای جلوگیری از race condition)

# ذخیره اینکه به هر sender چند بار جواب داده‌ایم (برای سلام فقط در بار اول)
# {user_id: {sender_id: reply_count}}
_reply_counts = {}


def get_secretary_mode(user_id: int) -> str:
    """دریافت حالت منشی کاربر"""
    return user_settings.get_setting(user_id, 'secretary_mode', 'manual')


def set_secretary_mode(user_id: int, mode: str):
    """تنظیم حالت منشی کاربر"""
    user_settings.set_setting(user_id, 'secretary_mode', mode)
    user_settings.save()


def is_secretary_enabled(user_id: int) -> bool:
    """بررسی آیا منشی فعال است"""
    return user_settings.get_setting(user_id, 'secretary_enabled', False)


def _should_auto_reply(user_id: int) -> bool:
    """بررسی آیا باید auto-reply انجام شود (نسخه sync - برای استفاده خارج از event loop)"""
    mode = get_secretary_mode(user_id)
    if mode == 'always':
        return True
    elif mode == 'offline':
        return not is_user_online(user_id)
    elif mode == 'manual':
        return False
    return False


async def _should_auto_reply_async(user_id: int) -> bool:
    """بررسی آیا باید auto-reply انجام شود (نسخه async - برای استفاده داخل event loop).

    از async_is_user_online استفاده می‌کند تا از deadlock جلوگیری شود، چون
    این تابع داخل همان event loopی فراخوانی می‌شود که کلاینت به آن متصل است.
    """
    mode = get_secretary_mode(user_id)
    if mode == 'always':
        return True
    elif mode == 'offline':
        return not await async_is_user_online(user_id)
    elif mode == 'manual':
        return False
    return False


async def _generate_reply(user_id: int, sender_name: str, message_text: str, sender_id: int = None) -> str:
    """تولید پاسخ هوشمند با استفاده از AgentExecutor.

    ⚠️ نکته مهم: AgentExecutor.run_stream یک تابع sync و blocking است که
    API call به Gemini می‌زند. اگر مستقیماً داخل event loop فراخوانی شود،
    کل event loop را block می‌کند و Telethon نمی‌تواند پیام‌های جدید دریافت کند.
    به همین دلیل از run_in_executor استفاده می‌کنیم تا در یک thread جداگانه
    اجرا شود.
    """
    try:
        # دریافت نام کاربر از پروفایل تنظیم شده
        user_profile_name = user_settings.get_setting(user_id, 'profile_name', '')
        user_bio = user_settings.get_setting(user_id, 'profile_bio', '')

        # بررسی آیا این اولین پیام از این sender است
        is_first_message = False
        if sender_id is not None:
            if user_id not in _reply_counts:
                _reply_counts[user_id] = {}
            reply_count = _reply_counts[user_id].get(sender_id, 0)
            is_first_message = reply_count == 0

        # ساخت پرامپت برای منشی
        if is_first_message:
            # پیام اول - سلام با نام فرستنده و معرفی
            if user_profile_name:
                intro = (
                    f"تو منشی شخصی {user_profile_name} هستی. "
                    f"این اولین پیام از {sender_name} است. "
                    f"با یک سلام گرم شروع کن: «سلام {sender_name} عزیز! 👋» "
                    f"سپس خودت را معرفی کن: «من دستیار هوش مصنوعی {user_profile_name} هستم. "
                    f"ایشان الان آنلاین نیستند، کاری دارید در خدمتم.» "
                    f"اگر {user_bio} و bio تنظیم شده بود، می‌توانی اشاره‌ای به آن بکنی. "
                    f"متن پیام: {message_text}"
                )
            else:
                intro = (
                    f"تو منشی شخصی هستی. "
                    f"این اولین پیام از {sender_name} است. "
                    f"با یک سلام گرم شروع کن: «سلام {sender_name} عزیز! 👋» "
                    f"سپس خودت را معرفی کن: «من دستیار هوش مصنوعی هستم. "
                    f"کاربر الان آنلاین نیستند، کاری دارید در خدمتم.» "
                    f"متن پیام: {message_text}"
                )
            secretary_prompt = intro
        else:
            # پیام‌های بعدی - بدون سلام تکراری
            if user_profile_name:
                secretary_prompt = (
                    f"تو منشی شخصی {user_profile_name} هستی. "
                    f"پیام زیر از {sender_name} دریافت شده است. "
                    f"یک پاسخ مودبانه، دوستانه و مناسب بنویس که از طرف {user_profile_name} ارسال شود. "
                    f"⚠️ مهم: سلام نکن و خودت را دوباره معرفی نکن، چون قبلاً معرفی شده‌ای. "
                    f"مستقیماً به پیام جواب بده. "
                    f"اگر پیام سوالی است، جواب بده. اگر پیام مهم است، به کاربر اطلاع بده که بعداً جواب می‌دهد. "
                    f"متن پیام: {message_text}"
                )
            else:
                secretary_prompt = (
                    f"تو منشی شخصی هستی و از طرف کاربر به پیام‌ها جواب می‌دهی. "
                    f"پیام زیر از {sender_name} دریافت شده است. "
                    f"یک پاسخ مودبانه، دوستانه و مناسب بنویس که از طرف کاربر ارسال شود. "
                    f"⚠️ مهم: سلام نکن و خودت را دوباره معرفی نکن، چون قبلاً معرفی شده‌ای. "
                    f"مستقیماً به پیام جواب بده. "
                    f"اگر پیام سوالی است، جواب بده. اگر پیام مهم است، به کاربر اطلاع بده که بعداً جواب می‌دهد. "
                    f"متن پیام: {message_text}"
                )

        # اجرای AgentExecutor.run_stream در یک thread جداگانه برای جلوگیری
        # از block شدن event loop (چون این تابع sync و blocking است)
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            lambda: AgentExecutor.run_stream(
                chat_id=user_id,
                user_text=secretary_prompt,
                chat_type="private",
                user_id=user_id
            )
        )

        responses, plan = result

        if responses and len(responses) > 0:
            return responses[0]
        return "سلام! در حال حاضر نمی‌توانم جواب بدهم، بعداً با شما در تماس خواهم بود. 🙏"
    except Exception as e:
        logger.error(f"Error generating reply for user {user_id}: {e}")
        return "سلام! در حال حاضر در دسترس نیستم، بعداً جواب می‌دهم. 🙏"


async def _monitor_messages(user_id: int, bot, chat_id: int):
    """مانیتور پیام‌های دریافتی کاربر و پاسخ هوشمند"""
    client = get_client_for_user(user_id)
    if not client:
        logger.warning(f"No client for user {user_id}")
        return

    try:
        from telethon import events
        from telebot.types import ForceReply

        # کش کردن me (اطلاعات خود کاربر) برای جلوگیری از API call در هر پیام
        me = await client.get_me()
        my_id = me.id
        logger.info(f"Secretary monitoring for user {user_id} (account: {my_id})")

        # دریافت آیدی ربات کارن برای نادیده گرفتن پیام‌های آن
        # (جلوگیری از loop: منشی به پیام‌های ربات کارن جواب ندهد)
        karen_bot_id = None
        try:
            karen_me = bot.get_me()
            karen_bot_id = karen_me.id
            logger.info(f"Karen bot ID: {karen_bot_id} - will skip its messages")
        except Exception as e:
            logger.warning(f"Could not get Karen bot ID: {e}")

        @client.on(events.NewMessage(incoming=True, func=lambda e: e.is_private))
        async def handle_new_message(event):
            """پردازش پیام دریافتی جدید"""
            try:
                sender = await event.get_sender()

                # ⚠️ فیلترهای حیاتی برای جلوگیری از loop بی‌نهایت:

                # 1. نادیده گرفتن پیام‌های ربات‌ها (bot accounts)
                # این مهم‌ترین فیلتر است - اگر به ربات دیگری جواب بدهیم،
                # ربات جواب می‌دهد و loop بی‌نهایت ایجاد می‌شود
                if hasattr(sender, 'bot') and sender.bot:
                    logger.info(f"Skipping bot message from {sender.id} for user {user_id}")
                    return

                # 2. نادیده گرفتن پیام‌های خود کاربر (self messages)
                if sender.id == my_id:
                    logger.info(f"Skipping own message for user {user_id}")
                    return

                # 3. نادیده گرفتن پیام‌های ربات کارن (جلوگیری از loop با خود ربات)
                if karen_bot_id and sender.id == karen_bot_id:
                    logger.info(f"Skipping Karen bot message for user {user_id}")
                    return

                # 4. نادیده گرفتن پیام‌های بدون متن (فایل، عکس و غیره) در حالت auto-reply
                message_text = event.message.text or ""
                if not message_text.strip():
                    logger.info(f"Skipping non-text message for user {user_id}")
                    return

                sender_name = f"{sender.first_name or ''} {sender.last_name or ''}".strip() or "Unknown"
                sender_username = f"@{sender.username}" if sender.username else "بدون یوزرنیم"

                logger.info(f"Secretary received message for user {user_id} from {sender_name}")

                # 5. بررسی cooldown برای جلوگیری از race condition
                # فقط ۳ ثانیه فاصله برای جلوگیری از پردازش همزمان پیام‌های تکراری
                now = time.time()
                if user_id not in _reply_cooldowns:
                    _reply_cooldowns[user_id] = {}
                user_cooldowns = _reply_cooldowns[user_id]
                last_reply = user_cooldowns.get(sender.id, 0)
                if now - last_reply < _REPLY_COOLDOWN_SECONDS:
                    logger.info(f"Skipping message from {sender.id} due to cooldown ({now - last_reply:.1f}s < {_REPLY_COOLDOWN_SECONDS}s)")
                    return

                # بررسی آیا باید auto-reply انجام شود (نسخه async برای جلوگیری از deadlock)
                should_reply = await _should_auto_reply_async(user_id)

                if should_reply:
                    # تولید و ارسال پاسخ هوشمند (با sender_id برای تشخیص پیام اول)
                    reply_text = await _generate_reply(user_id, sender_name, message_text, sender_id=sender.id)

                    # ارسال پاسخ از اکانت کاربر
                    try:
                        await client.send_message(sender.id, reply_text, reply_to=event.message.id)
                        # ثبت زمان پاسخ برای cooldown
                        user_cooldowns[sender.id] = now
                        # افزایش شمارنده پاسخ برای این sender (برای سلام فقط در بار اول)
                        if user_id not in _reply_counts:
                            _reply_counts[user_id] = {}
                        _reply_counts[user_id][sender.id] = _reply_counts[user_id].get(sender.id, 0) + 1
                        logger.info(f"Auto-reply sent from user {user_id} to {sender.id}")

                        # اطلاع به کاربر در چت کارن
                        # ⚠️ bot.send_message یک تابع sync است و باید در thread جداگانه
                        # اجرا شود تا event loop را block نکند
                        notification = (
                            f"📨 منشی خودکار فعال بود\n\n"
                            f"👤 از: {sender_name} ({sender_username})\n"
                            f"💬 پیام: {message_text[:200]}\n\n"
                            f"✅ پاسخ منشی: {reply_text[:200]}"
                        )
                        try:
                            loop = asyncio.get_event_loop()
                            await loop.run_in_executor(
                                None,
                                lambda: bot.send_message(chat_id, notification)
                            )
                        except Exception:
                            pass
                    except Exception as e:
                        logger.error(f"Error sending auto-reply for user {user_id}: {e}")
                else:
                    # حالت manual - فقط فوروارد کن
                    msg_text = (
                        f"📩 پیام جدید از {sender_name} ({sender_username}):\n\n"
                        f"{message_text}\n\n"
                        f"💡 برای جواب دادن، روی این پیام ریپلای کن."
                    )
                    try:
                        markup = ForceReply()
                        # اجرای bot.send_message در thread جداگانه برای جلوگیری از block شدن
                        loop = asyncio.get_event_loop()
                        sent = await loop.run_in_executor(
                            None,
                            lambda: bot.send_message(chat_id, msg_text, reply_markup=markup)
                        )
                        # ذخیره mapping برای جواب دستی
                        user_settings.set_setting(
                            user_id,
                            f"pending_reply_{sent.message_id}",
                            {"telethon_msg_id": event.message.id, "sender_id": sender.id}
                        )
                        user_settings.save()
                    except Exception as e:
                        logger.error(f"Error forwarding message to user: {e}")

            except Exception as e:
                logger.error(f"Error handling new message for user {user_id}: {e}")

        logger.info(f"Started monitoring messages for user {user_id}")
        await client.run_until_disconnected()

    except Exception as e:
        logger.error(f"Error in monitor_messages for user {user_id}: {e}")
    finally:
        _active_monitors.discard(user_id)


def start_monitoring(user_id: int, bot, chat_id: int) -> bool:
    """شروع مانیتورینگ پیام‌های کاربر.

    ⚠️ نکته مهم: مانیتورینگ باید روی همان event loopی اجرا شود که کلاینت
    Telethon به آن متصل است. اگر یک event loop جدید بسازیم، Telethon خطای
    "The asyncio event loop must not change after connection" می‌دهد.
    به همین دلیل از _get_or_create_loop و run_coroutine_threadsafe استفاده
    می‌کنیم تا کوروتین را روی همان loop مشترک schedule کنیم.
    """
    if user_id in _active_monitors:
        logger.info(f"Monitoring already running for user {user_id}")
        return True

    client = get_client_for_user(user_id)
    if not client:
        # تلاش برای اتصال مجدد با سشن ذخیره شده
        from tools.userbot_manager import reconnect_user
        logger.info(f"No client for user {user_id}, trying to reconnect...")
        if not reconnect_user(user_id):
            logger.warning(f"Reconnect failed for user {user_id}, cannot start monitoring")
            return False
        client = get_client_for_user(user_id)
        if not client:
            logger.warning(f"Still no client for user {user_id} after reconnect")
            return False

    # schedule کردن _monitor_messages روی همان event loop مشترک
    # که کلاینت Telethon به آن متصل است (جلوگیری از خطای event loop change)
    loop = _get_or_create_loop()

    # ایجاد یک task روی loop مشترک
    future = asyncio.run_coroutine_threadsafe(
        _monitor_messages(user_id, bot, chat_id),
        loop
    )

    # ذخیره task برای مدیریت بعدی
    _monitor_tasks[user_id] = future
    _active_monitors.add(user_id)
    logger.info(f"Started monitoring for user {user_id} on shared event loop")
    return True


def stop_monitoring(user_id: int):
    """توقف مانیتورینگ کاربر"""
    if user_id in _active_monitors:
        _active_monitors.discard(user_id)
        logger.info(f"Stopped monitoring for user {user_id}")

    # لغو task مانیتورینگ اگر وجود دارد
    future = _monitor_tasks.pop(user_id, None)
    if future and not future.done():
        try:
            future.cancel()
        except Exception:
            pass

    # قطع اتصال کلاینت
    from tools.userbot_manager import stop_userbot
    stop_userbot(user_id)


def is_monitoring(user_id: int) -> bool:
    """بررسی آیا مانیتورینگ فعال است"""
    return user_id in _active_monitors


async def send_reply(user_id: int, reply_text: str, telethon_msg_id: int, sender_id: int) -> bool:
    """ارسال جواب دستی کاربر از اکانت خودش"""
    client = get_client_for_user(user_id)
    if not client:
        logger.warning(f"No client for user {user_id}")
        return False

    try:
        await client.send_message(sender_id, reply_text, reply_to=telethon_msg_id)
        logger.info(f"Sent manual reply from user {user_id} to {sender_id}")
        return True
    except Exception as e:
        logger.error(f"Error sending reply for user {user_id}: {e}")
        return False


def get_active_secretaries() -> list:
    """دریافت لیست کاربرانی که منشی آن‌ها فعال است"""
    active = []
    try:
        for user_id_str, settings in user_settings.settings.items():
            if settings.get('secretary_enabled', False):
                active.append(int(user_id_str))
    except Exception as e:
        logger.error(f"Error getting active secretaries: {e}")
    return active


def start_all_active_secretaries(bot) -> dict:
    """شروع مانیتورینگ برای تمام کاربرانی که منشی فعال دارند

    Returns:
        دیکشنری user_id -> bool (موفقیت)
    """
    results = {}
    active_users = get_active_secretaries()

    for user_id in active_users:
        # اطمینان از اتصال userbot
        from tools.userbot_manager import reconnect_user
        if reconnect_user(user_id):
            # دریافت chat_id کاربر (همان user_id در چت خصوصی با کارن)
            results[user_id] = start_monitoring(user_id, bot, user_id)
        else:
            results[user_id] = False
            logger.warning(f"Could not reconnect userbot for user {user_id}")

    return results