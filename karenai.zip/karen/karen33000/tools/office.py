# tools/office.py
"""Office document tools powered by OfficeCLI.

This module wraps the OfficeCLI binary (https://github.com/iOfficeAI/OfficeCLI)
to give Karen the ability to create, read, and modify Office documents
(.docx, .xlsx, .pptx) directly from chat.

OfficeCLI is a single-binary CLI with no dependencies and no Office installation
required. It provides a document DOM API for Word, Excel, and PowerPoint.
"""

import os
import json
import shutil
import logging
import subprocess
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)

OFFICE_DIR = "office_workspace"
OFFICECLI_BIN = shutil.which("officecli") or "officecli"

# Supported formats and their extensions
SUPPORTED_FORMATS = {
    "docx": ".docx",
    "word": ".docx",
    "xlsx": ".xlsx",
    "excel": ".xlsx",
    "pptx": ".pptx",
    "ppt": ".pptx",
    "powerpoint": ".pptx",
}


def _ensure_office_dir():
    """Ensure the office workspace directory exists."""
    try:
        if not os.path.exists(OFFICE_DIR):
            os.makedirs(OFFICE_DIR)
    except Exception as e:
        logger.error(f"Error creating office workspace: {e}")


def _safe_filename(filename: str) -> str:
    """Sanitize filename to prevent path traversal."""
    if not filename:
        return ""
    return os.path.basename(filename)


def _get_full_path(filename: str) -> str:
    """Get the full path inside the office workspace."""
    _ensure_office_dir()
    safe = _safe_filename(filename)
    return os.path.join(OFFICE_DIR, safe)


def _run_officecli(args: List[str], timeout: int = 60) -> str:
    """Run an officecli command and return its output."""
    if not shutil.which("officecli"):
        return "❌ OfficeCLI is not installed. Please install it with: npm install -g @officecli/officecli"

    cmd = [OFFICECLI_BIN] + args
    logger.debug(f"Running officecli: {' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            shell=False
        )
        output = result.stdout.strip()
        if result.stderr and not output:
            output = result.stderr.strip()
        if result.returncode != 0 and not output:
            return f"❌ OfficeCLI error (exit code {result.returncode})"
        return output if output else "✅ Command completed successfully."
    except subprocess.TimeoutExpired:
        return f"❌ OfficeCLI command timed out after {timeout} seconds."
    except FileNotFoundError:
        return "❌ OfficeCLI binary not found. Please install it with: npm install -g @officecli/officecli"
    except Exception as e:
        logger.error(f"Error running officecli: {e}", exc_info=True)
        return f"❌ Error running officecli: {str(e)}"


def _normalize_format(fmt: str) -> str:
    """Normalize format name to extension."""
    if not fmt:
        return ""
    fmt = fmt.lower().strip().lstrip(".")
    return SUPPORTED_FORMATS.get(fmt, fmt if fmt.startswith(".") else f".{fmt}")


def _validate_filename(filename: str) -> bool:
    """Validate filename has a supported office extension."""
    if not filename or not isinstance(filename, str):
        return False
    ext = os.path.splitext(filename)[1].lower()
    return ext in [".docx", ".xlsx", ".pptx"]


def _parse_props(props: str) -> List[str]:
    """Parse properties into --prop key=value CLI arguments."""
    if not props:
        return []
    if isinstance(props, str):
        result = []
        for item in props.split(","):
            item = item.strip()
            if "=" in item:
                result.extend(["--prop", item])
        return result
    return []


# ============================================================
# L1: Create, Read & Inspect
# ============================================================

def create_office_document(filename: str, format: str = None) -> str:
    """Create a blank Office document (.docx, .xlsx, or .pptx).

    Args:
        filename: The output filename (e.g., 'report.docx', 'slides.pptx', 'data.xlsx')
        format: Optional format override ('docx', 'xlsx', 'pptx'). If not provided,
                inferred from the filename extension.

    Returns:
        Success or error message.

    Example:
        >>> create_office_document("report.docx")
        "✅ Created report.docx"
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."

    full_path = _get_full_path(filename)
    if os.path.exists(full_path):
        return f"⚠️ File '{filename}' already exists in workspace."

    result = _run_officecli(["create", full_path])
    if "❌" in result:
        return result
    return f"✅ Created {filename} in office_workspace/"


def view_office_document(filename: str, mode: str = "outline") -> str:
    """View an Office document's content or structure.

    Args:
        filename: The document filename (e.g., 'report.docx')
        mode: View mode - 'outline' (structure), 'stats' (statistics),
              'issues' (problems), 'text' (plain text), 'annotated' (text with formatting)

    Returns:
        Document content or structure information.

    Example:
        >>> view_office_document("report.docx", mode="text")
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."

    valid_modes = ["outline", "stats", "issues", "text", "annotated", "html"]
    if mode not in valid_modes:
        return f"❌ Invalid mode '{mode}'. Valid modes: {', '.join(valid_modes)}"

    full_path = _get_full_path(filename)
    if not os.path.exists(full_path):
        return f"❌ File '{filename}' not found in workspace."

    return _run_officecli(["view", full_path, mode])


def get_office_content(filename: str, path: str = "/", depth: int = 1) -> str:
    """Get a node and its children from an Office document.

    Args:
        filename: The document filename
        path: XML path to the node (e.g., '/body/p[1]', '/slide[1]', '/Sheet1/A1')
        depth: How many levels of children to expand

    Returns:
        Node content as text.

    Example:
        >>> get_office_content("report.docx", "/body/p[1]")
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."

    full_path = _get_full_path(filename)
    if not os.path.exists(full_path):
        return f"❌ File '{filename}' not found in workspace."

    return _run_officecli(["get", full_path, path, "--depth", str(depth)])


def query_office_document(filename: str, selector: str) -> str:
    """Query an Office document using CSS-like selectors.

    Args:
        filename: The document filename
        selector: CSS-like selector (e.g., 'paragraph[style=Normal]', 'shape[fill=FF0000]')

    Returns:
        Matching elements.

    Example:
        >>> query_office_document("report.docx", "paragraph[style=Heading1]")
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."
    if not selector:
        return "❌ Selector is required."

    full_path = _get_full_path(filename)
    if not os.path.exists(full_path):
        return f"❌ File '{filename}' not found in workspace."

    return _run_officecli(["query", full_path, selector])


def validate_office_document(filename: str) -> str:
    """Validate an Office document against OpenXML schema.

    Args:
        filename: The document filename

    Returns:
        Validation result.

    Example:
        >>> validate_office_document("report.docx")
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."

    full_path = _get_full_path(filename)
    if not os.path.exists(full_path):
        return f"❌ File '{filename}' not found in workspace."

    return _run_officecli(["validate", full_path])


# ============================================================
# L2: DOM Operations
# ============================================================

def add_office_element(
    filename: str,
    path: str,
    element_type: str,
    props: str = None,
    after: str = None,
    before: str = None,
    index: int = None
) -> str:
    """Add an element to an Office document.

    Args:
        filename: The document filename
        path: Parent path (e.g., '/body' for docx, '/' for pptx, '/Sheet1' for xlsx)
        element_type: Element type (e.g., 'paragraph', 'slide', 'shape', 'cell', 'table')
        props: Properties as "key=value,key2=value2" string (e.g., 'text=Hello,bold=true')
        after: Insert after this path
        before: Insert before this path
        index: 0-based position to insert at

    Returns:
        Success or error message.

    Example:
        >>> add_office_element("report.docx", "/body", "paragraph",
        ...                    {"text": "Hello World", "style": "Heading1"})
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."
    if not element_type:
        return "❌ Element type is required."

    full_path = _get_full_path(filename)
    if not os.path.exists(full_path):
        return f"❌ File '{filename}' not found in workspace."

    args = ["add", full_path, path, "--type", element_type]
    args.extend(_parse_props(props))

    if after:
        args.extend(["--after", after])
    if before:
        args.extend(["--before", before])
    if index is not None:
        args.extend(["--index", str(index)])

    return _run_officecli(args)


def set_office_property(
    filename: str,
    path: str,
    props: str,
    find: str = None,
    replace: str = None
) -> str:
    """Set properties on an element in an Office document.

    Args:
        filename: The document filename
        path: Path to the element (e.g., '/body/p[1]', '/slide[1]/shape[2]', '/Sheet1/A1')
        props: Properties as "key=value,key2=value2" string (e.g., 'bold=true,color=FF0000')
        find: Optional text to find and format/replace
        replace: Optional replacement text (used with find)

    Returns:
        Success or error message.

    Example:
        >>> set_office_property("report.docx", "/body/p[1]",
        ...                     {"bold": "true", "color": "FF0000"})
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."
    if not props:
        return "❌ Properties are required."

    full_path = _get_full_path(filename)
    if not os.path.exists(full_path):
        return f"❌ File '{filename}' not found in workspace."

    args = ["set", full_path, path]
    args.extend(_parse_props(props))

    if find:
        args.extend(["--find", find])
    if replace:
        args.extend(["--replace", replace])

    return _run_officecli(args)


def remove_office_element(filename: str, path: str) -> str:
    """Remove an element from an Office document.

    Args:
        filename: The document filename
        path: Path to the element to remove (e.g., '/body/p[4]', '/slide[2]')

    Returns:
        Success or error message.

    Example:
        >>> remove_office_element("report.docx", "/body/p[4]")
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."
    if not path:
        return "❌ Path is required."

    full_path = _get_full_path(filename)
    if not os.path.exists(full_path):
        return f"❌ File '{filename}' not found in workspace."

    return _run_officecli(["remove", full_path, path])


def move_office_element(filename: str, path: str, to: str = None, index: int = None) -> str:
    """Move an element within an Office document.

    Args:
        filename: The document filename
        path: Path to the element to move
        to: Target parent path
        index: Target index

    Returns:
        Success or error message.
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."

    full_path = _get_full_path(filename)
    if not os.path.exists(full_path):
        return f"❌ File '{filename}' not found in workspace."

    args = ["move", full_path, path]
    if to:
        args.extend(["--to", to])
    if index is not None:
        args.extend(["--index", str(index)])

    return _run_officecli(args)


def swap_office_elements(filename: str, path1: str, path2: str) -> str:
    """Swap two elements in an Office document.

    Args:
        filename: The document filename
        path1: First element path
        path2: Second element path

    Returns:
        Success or error message.
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."

    full_path = _get_full_path(filename)
    if not os.path.exists(full_path):
        return f"❌ File '{filename}' not found in workspace."

    return _run_officecli(["swap", full_path, path1, path2])


def batch_office_operations(filename: str, operations: str) -> str:
    """Execute multiple operations on an Office document in one save cycle.

    Args:
        filename: The document filename
        operations: JSON string of operations list.
                   Each op: {"command": "set", "path": "/Sheet1/A1", "props": {"value": "Name"}}

    Returns:
        Batch result.

    Example:
        >>> batch_office_operations("data.xlsx", [
        ...     {"command": "set", "path": "/Sheet1/A1", "props": {"value": "Name"}},
        ...     {"command": "set", "path": "/Sheet1/B1", "props": {"value": "Score"}}
        ... ])
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx, .xlsx, or .pptx extension."

    full_path = _get_full_path(filename)
    if not os.path.exists(full_path):
        return f"❌ File '{filename}' not found in workspace."

    if isinstance(operations, str):
        ops_json = operations
    elif isinstance(operations, list):
        ops_json = json.dumps(operations, ensure_ascii=False)
    else:
        return "❌ Operations must be a list or JSON string."

    return _run_officecli(["batch", full_path, "--commands", ops_json, "--json"])


# ============================================================
# High-level convenience functions
# ============================================================

def text_to_word_document(text: str, filename: str = "document.docx", title: str = None) -> str:
    """Convert plain text into a formatted Word document (.docx).

    This is a high-level function that creates a Word document from text.
    Lines starting with '#' become headings, blank lines create paragraph breaks.

    Args:
        text: The text content to convert to a Word document
        filename: Output filename (default: 'document.docx')
        title: Optional document title (added as a Title style)

    Returns:
        Success or error message.

    Example:
        >>> text_to_word_document("سلام دنیا", "hello.docx", title="عنوان")
    """
    if not text or not text.strip():
        return "❌ Text content is required."
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .docx extension."

    full_path = _get_full_path(filename)
    if os.path.exists(full_path):
        return f"⚠️ File '{filename}' already exists. Use a different name."

    # Create the document
    result = _run_officecli(["create", full_path])
    if "❌" in result:
        return result

    lines = text.split("\n")
    ops = []

    if title:
        ops.append({
            "command": "add", "path": "/body", "type": "paragraph",
            "props": {"text": title, "style": "Title"}
        })

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # Detect heading levels
        if line.startswith("### "):
            ops.append({
                "command": "add", "path": "/body", "type": "paragraph",
                "props": {"text": line[4:].strip(), "style": "Heading3"}
            })
        elif line.startswith("## "):
            ops.append({
                "command": "add", "path": "/body", "type": "paragraph",
                "props": {"text": line[3:].strip(), "style": "Heading2"}
            })
        elif line.startswith("# "):
            ops.append({
                "command": "add", "path": "/body", "type": "paragraph",
                "props": {"text": line[2:].strip(), "style": "Heading1"}
            })
        elif line.startswith("- ") or line.startswith("* "):
            ops.append({
                "command": "add", "path": "/body", "type": "paragraph",
                "props": {"text": line[2:].strip(), "style": "ListBullet"}
            })
        else:
            ops.append({
                "command": "add", "path": "/body", "type": "paragraph",
                "props": {"text": line}
            })

    if ops:
        batch_result = _run_officecli(
            ["batch", full_path, "--commands", json.dumps(ops, ensure_ascii=False), "--json"]
        )
        if "❌" in batch_result:
            return batch_result

    return f"✅ Word document created: office_workspace/{filename}"


def text_to_powerpoint(text: str, filename: str = "presentation.pptx", title: str = None) -> str:
    """Convert text into a PowerPoint presentation (.pptx).

    This is a high-level function that creates a PPT from text.
    Lines starting with '## ' become new slides (slide titles).
    Other lines become content shapes on the current slide.

    Args:
        text: The text content. Use '## ' for slide titles, other lines for content.
        filename: Output filename (default: 'presentation.pptx')
        title: Optional presentation title (first slide)

    Returns:
        Success or error message.

    Example:
        >>> text_to_powerpoint("## معرفی\nاین یک اسلاید است", "intro.pptx")
    """
    if not text or not text.strip():
        return "❌ Text content is required."
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .pptx extension."

    full_path = _get_full_path(filename)
    if os.path.exists(full_path):
        return f"⚠️ File '{filename}' already exists. Use a different name."

    # Create the presentation
    result = _run_officecli(["create", full_path])
    if "❌" in result:
        return result

    lines = text.split("\n")
    slide_count = 0
    current_slide = 1
    shape_index = 2  # shape[1] is usually the title placeholder

    # Add title slide if provided
    if title:
        result = _run_officecli([
            "add", full_path, "/", "--type", "slide",
            "--prop", f"title={title}"
        ])
        if "❌" in result:
            return result
        slide_count += 1
        current_slide = 1

    for line in lines:
        line = line.strip()
        if not line:
            continue

        if line.startswith("## "):
            # New slide
            slide_title = line[3:].strip()
            result = _run_officecli([
                "add", full_path, "/", "--type", "slide",
                "--prop", f"title={slide_title}"
            ])
            if "❌" in result:
                return result
            slide_count += 1
            current_slide = slide_count
            shape_index = 2
        elif line.startswith("# "):
            # Title slide
            slide_title = line[2:].strip()
            result = _run_officecli([
                "add", full_path, "/", "--type", "slide",
                "--prop", f"title={slide_title}"
            ])
            if "❌" in result:
                return result
            slide_count += 1
            current_slide = slide_count
            shape_index = 2
        else:
            # Add content shape to current slide
            result = _run_officecli([
                "add", full_path, f"/slide[{current_slide}]", "--type", "shape",
                "--prop", f"text={line}",
                "--prop", f"y={shape_index * 2}cm"
            ])
            if "❌" in result:
                return result
            shape_index += 1

    if slide_count == 0:
        # No slides were added, add a default one
        result = _run_officecli([
            "add", full_path, "/", "--type", "slide",
            "--prop", "title=Presentation"
        ])
        if "❌" in result:
            return result

    return f"✅ PowerPoint created: office_workspace/{filename}"


def data_to_excel(data: str, filename: str = "data.xlsx") -> str:
    """Convert data into an Excel spreadsheet (.xlsx).

    Args:
        data: JSON string of data. Can be a list of lists or dict of lists.
              - List of lists: '[["header1", "header2"], ["val1", "val2"]]'
              - Dict of lists: '{"Name": ["Alice", "Bob"], "Score": [95, 87]}'
        filename: Output filename (default: 'data.xlsx')

    Returns:
        Success or error message.

    Example:
        >>> data_to_excel([["Name", "Score"], ["Alice", 95], ["Bob", 87]], "grades.xlsx")
    """
    if not _validate_filename(filename):
        return "❌ Invalid filename. Use .xlsx extension."

    # Parse data
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except json.JSONDecodeError:
            return "❌ Invalid JSON data string."

    if isinstance(data, dict):
        # Convert dict of lists to list of lists (columns)
        headers = list(data.keys())
        rows = []
        max_len = max(len(v) for v in data.values()) if data else 0
        for i in range(max_len):
            row = []
            for h in headers:
                vals = data[h]
                row.append(vals[i] if i < len(vals) else "")
            rows.append(row)
        data = [headers] + rows
    elif not isinstance(data, list) or not data:
        return "❌ Data must be a list of lists, dict of lists, or JSON string."

    full_path = _get_full_path(filename)
    if os.path.exists(full_path):
        return f"⚠️ File '{filename}' already exists. Use a different name."

    # Create the spreadsheet
    result = _run_officecli(["create", full_path])
    if "❌" in result:
        return result

    # Write data using batch operations
    ops = []
    for row_idx, row in enumerate(data, start=1):
        for col_idx, value in enumerate(row):
            col_letter = chr(ord('A') + col_idx) if col_idx < 26 else f"A{col_idx // 26}{chr(ord('A') + col_idx % 26)}"
            cell_path = f"/Sheet1/{col_letter}{row_idx}"
            ops.append({
                "command": "set",
                "path": cell_path,
                "props": {"value": str(value)}
            })

    if ops:
        batch_result = _run_officecli(
            ["batch", full_path, "--commands", json.dumps(ops, ensure_ascii=False), "--json"]
        )
        if "❌" in batch_result:
            return batch_result

    return f"✅ Excel spreadsheet created: office_workspace/{filename}"


def list_office_files() -> str:
    """List all Office documents in the workspace.

    Returns:
        List of available office files.
    """
    _ensure_office_dir()
    try:
        files = os.listdir(OFFICE_DIR)
        office_files = [f for f in files if f.endswith((".docx", ".xlsx", ".pptx"))]
        if not office_files:
            return "No office documents in workspace yet. Create one with create_office_document."
        return "Office documents in workspace:\n" + "\n".join([f"- {f}" for f in office_files])
    except Exception as e:
        return f"Failed to list office files: {str(e)}"


def get_office_help(topic: str = None) -> str:
    """Get help about OfficeCLI commands and schemas.

    Args:
        topic: Optional help topic (e.g., 'docx', 'docx paragraph', 'xlsx cell', 'pptx slide')

    Returns:
        Help text from OfficeCLI.

    Example:
        >>> get_office_help("docx paragraph")
    """
    if topic:
        return _run_officecli(["help", topic])
    return _run_officecli(["help"])


def officecli_version() -> str:
    """Get the installed OfficeCLI version.

    Returns:
        Version string.
    """
    return _run_officecli(["--version"])
