# tools/telethon_client.py
import os
import asyncio
import logging
import threading
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

load_dotenv()

_client = None
_initialized = False
_available = False
_loop = None
_loop_thread = None


def is_available() -> bool:
    """بررسی آیا Telethon پیکربندی شده"""
    global _initialized, _available
    if not _initialized:
        _available = bool(
            os.getenv("TELETHON_API_ID") and os.getenv("TELETHON_API_HASH")
        )
        _initialized = True
    return _available


def _get_or_create_loop():
    """دریافت یا ایجاد event loop اختصاصی برای Telethon"""
    global _loop, _loop_thread
    if _loop is not None and _loop.is_running():
        return _loop
    
    _loop = asyncio.new_event_loop()
    _loop_thread = threading.Thread(target=_loop.run_forever, daemon=True)
    _loop_thread.start()
    return _loop


def _run_async(coro):
    """اجرای async function در sync context"""
    loop = _get_or_create_loop()
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result(timeout=60)


async def _init_client():
    """ایجاد و اتصال کلاینت Telethon"""
    global _client

    if _client is not None:
        return _client

    api_id = os.getenv("TELETHON_API_ID")
    api_hash = os.getenv("TELETHON_API_HASH")
    session_name = os.getenv("TELETHON_SESSION_NAME", "karen_userbot")

    if not api_id or not api_hash:
        logger.warning("TELETHON_API_ID یا TELETHON_API_HASH تنظیم نشده")
        return None

    try:
        from telethon import TelegramClient

        _client = TelegramClient(session_name, int(api_id), api_hash)
        await _client.start()
        logger.info("✅ Telethon userbot connected successfully")
        return _client
    except Exception as e:
        logger.error(f"خطا در اتصال Telethon: {e}")
        _client = None
        return None


def ensure_connected() -> bool:
    """اطمینان از اتصال کلاینت Telethon"""
    if not is_available():
        return False

    try:
        result = _run_async(_init_client())
        return result is not None
    except Exception as e:
        logger.error(f"خطا در اتصال Telethon: {e}")
        return False


def resolve_phone_to_user_id(phone_number: str) -> int | None:
    """
    تبدیل شماره تلفن به user_id

    Args:
        phone_number: شماره تلفن با فرمت بین‌المللی (مثلاً +989121234567)

    Returns:
        user_id یا None اگر پیدا نشد
    """
    if not is_available():
        return None

    phone_number = normalize_phone(phone_number)

    async def _resolve():
        client = await _init_client()
        if client is None:
            return None

        try:
            entity = await client.get_entity(phone_number)
            if entity and hasattr(entity, "id"):
                logger.info(f"شماره {phone_number} -> user_id: {entity.id}")
                return entity.id
            return None
        except ValueError:
            logger.warning(f"کاربری با شماره {phone_number} یافت نشد")
            return None
        except Exception as e:
            logger.error(f"خطا در رفع شماره {phone_number}: {e}")
            return None

    return _run_async(_resolve())


def resolve_username_to_user_id(username: str) -> int | None:
    """
    تبدیل یوزرنیم به user_id

    Args:
        username: یوزرنیم بدون @

    Returns:
        user_id یا None اگر پیدا نشد
    """
    if not is_available():
        return None

    username = username.lstrip("@")

    async def _resolve():
        client = await _init_client()
        if client is None:
            return None

        try:
            entity = await client.get_entity(username)
            if entity and hasattr(entity, "id"):
                logger.info(f"یوزرنیم @{username} -> user_id: {entity.id}")
                return entity.id
            return None
        except ValueError:
            logger.warning(f"کاربری با یوزرنیم @{username} یافت نشد")
            return None
        except Exception as e:
            logger.error(f"خطا در رفع یوزرنیم @{username}: {e}")
            return None

    return _run_async(_resolve())


def normalize_phone(phone_number: str) -> str:
    """نرمالایز شماره تلفن به فرمت بین‌المللی"""
    phone = phone_number.strip().replace(" ", "").replace("-", "").replace("(", "").replace(")", "")

    if phone.startswith("00"):
        phone = "+" + phone[2:]
    elif phone.startswith("0"):
        phone = "+98" + phone[1:]
    elif not phone.startswith("+"):
        phone = "+98" + phone

    return phone


def get_chat_members(chat_id: int) -> list:
    """
    دریافت لیست کامل اعضای گروه با استفاده از Telethon
    
    Args:
        chat_id: آیدی عددی گروه
    
    Returns:
        لیست دیکشنری‌های حاوی اطلاعات اعضا
    """
    if not is_available():
        return []

    async def _get_members():
        client = await _init_client()
        if client is None:
            return []

        try:
            from telethon.tl.functions.channels import GetParticipantsRequest
            from telethon.tl.types import (
                ChannelParticipantsSearch,
                ChannelParticipantsRecent,
                ChannelParticipantsAdmins
            )
            
            # resolve entity از chat_id
            entity = await client.get_entity(chat_id)
            
            participants = []
            offset = 0
            limit = 100
            
            while True:
                result = await client(GetParticipantsRequest(
                    channel=entity,
                    filter=ChannelParticipantsSearch(''),
                    offset=offset,
                    limit=limit,
                    hash=0
                ))
                
                if not result.users:
                    break
                
                participants.extend(result.users)
                
                if len(result.users) < limit:
                    break
                
                offset += len(result.users)
            
            members = []
            for user in participants:
                member_info = {
                    "user_id": user.id,
                    "username": user.username or "",
                    "first_name": user.first_name or "",
                    "last_name": user.last_name or "",
                    "phone": getattr(user, 'phone', None) or "",
                    "is_bot": user.bot if hasattr(user, 'bot') else False,
                    "is_premium": user.premium if hasattr(user, 'premium') else False
                }
                members.append(member_info)
            
            logger.info(f"دریافت {len(members)} عضو از گروه {chat_id}")
            return members
            
        except Exception as e:
            logger.error(f"خطا در دریافت اعضای گروه {chat_id}: {e}")
            return []

    return _run_async(_get_members())


def get_chat_admins(chat_id: int) -> list:
    """
    دریافت لیست ادمین‌های گروه با استفاده از Telethon
    
    Args:
        chat_id: آیدی عددی گروه
    
    Returns:
        لیست دیکشنری‌های حاوی اطلاعات ادمین‌ها
    """
    if not is_available():
        return []

    async def _get_admins():
        client = await _init_client()
        if client is None:
            return []

        try:
            from telethon.tl.functions.channels import GetParticipantsRequest
            from telethon.tl.types import ChannelParticipantsAdmins
            
            # resolve entity از chat_id
            entity = await client.get_entity(chat_id)
            
            result = await client(GetParticipantsRequest(
                channel=entity,
                filter=ChannelParticipantsAdmins(),
                offset=0,
                limit=100,
                hash=0
            ))
            
            admins = []
            for user in result.users:
                admin_info = {
                    "user_id": user.id,
                    "username": user.username or "",
                    "first_name": user.first_name or "",
                    "last_name": user.last_name or "",
                    "is_bot": user.bot if hasattr(user, 'bot') else False
                }
                admins.append(admin_info)
            
            logger.info(f"دریافت {len(admins)} ادمین از گروه {chat_id}")
            return admins
            
        except Exception as e:
            logger.error(f"خطا در دریافت ادمین‌های گروه {chat_id}: {e}")
            return []

    return _run_async(_get_admins())


def get_chat_info(chat_id: int) -> dict:
    """
    دریافت اطلاعات کلی گروه با استفاده از Telethon
    
    Args:
        chat_id: آیدی عددی گروه
    
    Returns:
        دیکشنری حاوی اطلاعات گروه
    """
    if not is_available():
        return {}

    async def _get_info():
        client = await _init_client()
        if client is None:
            return {}

        try:
            entity = await client.get_entity(chat_id)
            
            info = {
                "id": entity.id,
                "title": entity.title if hasattr(entity, 'title') else "",
                "username": entity.username if hasattr(entity, 'username') else "",
                "description": entity.about if hasattr(entity, 'about') else "",
                "member_count": entity.participants_count if hasattr(entity, 'participants_count') else 0,
                "is_verified": entity.verified if hasattr(entity, 'verified') else False,
                "is_restricted": entity.restricted if hasattr(entity, 'restricted') else False,
                "is_scam": entity.scam if hasattr(entity, 'scam') else False,
                "is_fake": entity.fake if hasattr(entity, 'fake') else False
            }
            
            logger.info(f"دریافت اطلاعات گروه {chat_id}: {info['title']}")
            return info
            
        except Exception as e:
            logger.error(f"خطا در دریافت اطلاعات گروه {chat_id}: {e}")
            return {}

    return _run_async(_get_info())
