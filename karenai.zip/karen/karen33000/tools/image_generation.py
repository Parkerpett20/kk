import urllib.parse
import urllib.request
import logging
from typing import Tuple, Optional

logger = logging.getLogger(__name__)

# Constants
MAX_PROMPT_LENGTH = 500
MIN_PROMPT_LENGTH = 10
IMAGE_GENERATION_API = "https://image.pollinations.ai/p"
IMAGE_WIDTH = 1024
IMAGE_HEIGHT = 1024


def _validate_prompt(prompt: str) -> bool:
    """Validate image generation prompt"""
    if not prompt or not isinstance(prompt, str):
        return False

    prompt_clean = prompt.strip()
    if len(prompt_clean) < MIN_PROMPT_LENGTH:
        return False
    if len(prompt_clean) > MAX_PROMPT_LENGTH:
        return False

    return True


def _validate_url(url: str) -> bool:
    """Validate generated image URL"""
    try:
        urllib.parse.urlparse(url)
        return url.startswith(('http://', 'https://'))
    except Exception:
        return False


def generate_image_url(prompt: str, width: int = IMAGE_WIDTH, height: int = IMAGE_HEIGHT) -> str:
    """Generates an image from a text description using Pollinations AI.

    Args:
        prompt: Detailed description of the image to generate (10-500 chars)
        width: Image width in pixels (default: 1024)
        height: Image height in pixels (default: 1024)

    Returns:
        Image URL or error message with emoji indicator

    Example:
        >>> generate_image_url("A serene mountain landscape at sunset")
    """
    # Validate prompt
    if not _validate_prompt(prompt):
        if not prompt or not isinstance(prompt, str):
            error_msg = "Invalid prompt: Must be a non-empty string"
        elif len(prompt.strip()) < MIN_PROMPT_LENGTH:
            error_msg = f"Prompt too short: Minimum {MIN_PROMPT_LENGTH} characters required"
        else:
            error_msg = f"Prompt too long: Maximum {MAX_PROMPT_LENGTH} characters allowed"

        logger.warning(f"Invalid image prompt: {error_msg}")
        return f"❌ {error_msg}"

    # Validate dimensions
    if not isinstance(width, int) or not isinstance(height, int):
        return "❌ Width and height must be integers"

    if width < 256 or width > 2048 or height < 256 or height > 2048:
        return "❌ Width and height must be between 256 and 2048 pixels"

    logger.info(f"Generating image: prompt='{prompt[:50]}...' size={width}x{height}")

    try:
        # Encode prompt
        encoded_prompt = urllib.parse.quote(prompt)

        # Build URL
        image_url = (
            f"{IMAGE_GENERATION_API}/{encoded_prompt}"
            f"?width={width}&height={height}&nologo=true"
        )

        logger.debug(f"Generated image URL: {image_url[:80]}...")

        # Validate URL
        if not _validate_url(image_url):
            logger.error(f"Invalid generated URL: {image_url}")
            return f"❌ Failed to generate valid image URL"

        # Optional: Verify URL is accessible (commented out to avoid slowdown)
        # try:
        #     req = urllib.request.Request(image_url, headers={'User-Agent': 'Mozilla/5.0'})
        #     with urllib.request.urlopen(req, timeout=5) as response:
        #         if response.status != 200:
        #             logger.warning(f"URL returned status {response.status}")
        # except Exception as e:
        #     logger.warning(f"Could not verify URL: {e}")

        logger.info(f"Image URL generated successfully for prompt: {prompt[:30]}...")
        return f"✅ Image generated successfully!\n\n🖼️ Image URL: {image_url}"

    except Exception as e:
        error_msg = f"Image generation failed: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


def generate_image_batch(prompts: list, width: int = IMAGE_WIDTH, height: int = IMAGE_HEIGHT) -> dict:
    """Generate multiple images from a list of prompts

    Args:
        prompts: List of image descriptions
        width: Image width in pixels
        height: Image height in pixels

    Returns:
        Dictionary with 'successful' and 'failed' lists
    """
    if not isinstance(prompts, list):
        logger.warning("Batch generation received non-list input")
        return {"successful": [], "failed": ["Input must be a list of prompts"]}

    if len(prompts) > 10:  # Reasonable batch limit
        logger.warning(f"Batch size too large: {len(prompts)} > 10")
        return {"successful": [], "failed": ["Batch size exceeds limit (max 10)"]}

    results = {"successful": [], "failed": []}

    for i, prompt in enumerate(prompts, 1):
        logger.debug(f"Generating batch image {i}/{len(prompts)}")
        result = generate_image_url(prompt, width, height)

        # Check if successful (starts with ✅)
        if result.startswith("✅"):
            # Extract URL from result
            lines = result.split('\n')
            url_line = [l for l in lines if 'http' in l]
            if url_line:
                url = url_line[0].replace('🖼️ Image URL: ', '').strip()
                results["successful"].append({"prompt": prompt, "url": url})
            else:
                results["successful"].append({"prompt": prompt, "url": result})
        else:
            results["failed"].append({"prompt": prompt, "error": result})

    logger.info(f"Batch generation complete: {len(results['successful'])} successful, {len(results['failed'])} failed")
    return results


def estimate_generation_time(prompt_length: int) -> str:
    """Estimate generation time based on prompt length

    Args:
        prompt_length: Length of the prompt in characters

    Returns:
        Estimated time range as string
    """
    if prompt_length < 50:
        return "Fast (1-3 seconds)"
    elif prompt_length < 150:
        return "Normal (3-8 seconds)"
    else:
        return "Complex (8-15 seconds)"