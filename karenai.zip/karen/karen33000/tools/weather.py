# tools/weather.py
import urllib.request
import json
import logging
from typing import Optional, Dict
from urllib.error import URLError, HTTPError
from datetime import datetime

logger = logging.getLogger(__name__)

# Constants
WEATHER_API_URL = "https://api.weatherapi.com/v1/current.json"
FORECAST_API_URL = "https://api.weatherapi.com/v1/forecast.json"
DEFAULT_TIMEOUT = 10

# Fallback weather service (Open-Meteo - free, no API key needed)
OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"

# City name translations (Persian to English)
CITY_TRANSLATIONS = {
    'تهران': 'Tehran',
    'شیراز': 'Shiraz',
    'اصفهان': 'Isfahan',
    'تبریز': 'Tabriz',
    'مشهد': 'Mashhad',
    'کرج': 'Karaj',
    'کیش': 'Kish',
    'اهواز': 'Ahvaz',
}

# Weather condition descriptions
WEATHER_CONDITIONS = {
    'clear': '☀️ صاف و آفتابی',
    'cloudy': '☁️ ابری',
    'rain': '🌧️ بارانی',
    'snow': '❄️ برفانی',
    'thunder': '⛈️ رعد و برق',
    'windy': '💨 بادی',
    'fog': '🌫️ مه آلود',
}


def _normalize_city_name(city: str) -> str:
    """Normalize city name - translate Persian to English if needed"""
    if not city or not isinstance(city, str):
        return ""
    
    city_clean = city.strip()
    
    # Check if city is in Persian, translate if needed
    if city_clean in CITY_TRANSLATIONS:
        return CITY_TRANSLATIONS[city_clean]
    
    return city_clean


def _validate_city_name(city: str) -> bool:
    """Validate city name"""
    if not city or not isinstance(city, str):
        return False
    
    if len(city.strip()) < 2:
        return False
    
    if len(city) > 100:
        return False
    
    return True


def get_weather(city: str) -> str:
    """Retrieves current weather status for a city.
    
    Args:
        city: Name of the city (English or Persian)
    
    Returns:
        Formatted weather information or error message with emoji indicator
    
    Example:
        >>> get_weather("Tehran")
        "🌡️ Tehran: ☀️ صاف و آفتابی, 22°C, Humidity: 45%"
        >>> get_weather("تهران")
        Same as above (automatically translated)
    """
    # Validate input
    if not _validate_city_name(city):
        error_msg = "Invalid city name"
        logger.warning(f"Invalid city name: {city}")
        return f"❌ {error_msg}"
    
    # Normalize city name
    city_normalized = _normalize_city_name(city)
    
    logger.info(f"Fetching weather for: {city_normalized}")
    
    try:
        # Try Open-Meteo API (free, no key needed)
        result = _get_weather_open_meteo(city_normalized)
        if result and not result.startswith("❌"):
            logger.info(f"Successfully fetched weather for {city_normalized}")
            return result
        
        # Fallback: Return simulated weather
        logger.warning(f"Could not fetch real weather for {city_normalized}, using fallback")
        return _get_weather_fallback(city_normalized)
        
    except Exception as e:
        error_msg = f"Weather service error: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"⚠️ {error_msg}"


def _get_weather_open_meteo(city: str) -> str:
    """Fetch weather using Open-Meteo free API"""
    try:
        # Geocode the city first
        geocode_url = f"https://geocoding-api.open-meteo.com/v1/search?name={urllib.parse.quote(city)}&count=1&language=en"
        
        logger.debug(f"Geocoding: {geocode_url[:60]}...")
        
        req = urllib.request.Request(geocode_url, headers={'User-Agent': 'Karen-Agent/1.0'})
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
            geo_data = json.loads(response.read().decode('utf-8'))
            
            results = geo_data.get('results', [])
            if not results:
                logger.warning(f"City not found: {city}")
                return f"❌ City not found: {city}"
            
            location = results[0]
            latitude = location.get('latitude')
            longitude = location.get('longitude')
            country = location.get('country', '')
            
            # Fetch weather
            weather_url = f"{OPEN_METEO_URL}?latitude={latitude}&longitude={longitude}&current=temperature_2m,weather_code,relative_humidity_2m,weather_code"
            
            logger.debug(f"Fetching weather from: {weather_url[:60]}...")
            
            req = urllib.request.Request(weather_url, headers={'User-Agent': 'Karen-Agent/1.0'})
            with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
                weather_data = json.loads(response.read().decode('utf-8'))
                current = weather_data.get('current', {})
                
                temp = current.get('temperature_2m', 'N/A')
                humidity = current.get('relative_humidity_2m', 'N/A')
                weather_code = current.get('weather_code', 0)
                
                # Map weather code to description
                weather_desc = _get_weather_description(weather_code)
                
                result = (
                    f"🌡️ **{city}** ({country})\n"
                    f"{weather_desc}\n"
                    f"🌡️ Temperature: {temp}°C\n"
                    f"💧 Humidity: {humidity}%"
                )
                
                return result
                
    except URLError as ue:
        logger.error(f"URL error: {ue.reason}")
        return f"❌ Cannot reach weather service: {ue.reason}"
    except json.JSONDecodeError:
        logger.error("Invalid JSON response")
        return "❌ Invalid weather service response"
    except Exception as e:
        logger.error(f"Weather fetch error: {e}")
        return f"❌ {str(e)}"


def _get_weather_description(weather_code: int) -> str:
    """Convert weather code to description"""
    # WMO Weather interpretation codes
    if weather_code == 0:
        return "☀️ صاف و آفتابی (Clear Sky)"
    elif weather_code in [1, 2]:
        return "🌤️ تا حدودی ابری (Partly Cloudy)"
    elif weather_code == 3:
        return "☁️ ابری (Overcast)"
    elif weather_code in [45, 48]:
        return "🌫️ مه آلود (Foggy)"
    elif weather_code in [51, 53, 55, 61, 63, 65, 80, 81, 82]:
        return "🌧️ بارانی (Rainy)"
    elif weather_code in [71, 73, 75, 77, 80, 85, 86]:
        return "❄️ برفانی (Snowy)"
    elif weather_code in [80, 81, 82]:
        return "⛈️ رعد و برق (Thunderstorm)"
    else:
        return "🌦️ متغیر (Variable)"


def _get_weather_fallback(city: str) -> str:
    """Return simulated weather for fallback"""
    import random
    
    conditions = ['☀️ صاف و آفتابی', '☁️ ابری', '🌦️ نیمه ابری']
    temp = random.randint(15, 30)
    humidity = random.randint(30, 80)
    condition = random.choice(conditions)
    
    logger.info(f"Returning fallback weather for: {city}")
    
    result = (
        f"🌡️ **{city}** (Simulated)\n"
        f"{condition}\n"
        f"🌡️ Temperature: ~{temp}°C\n"
        f"💧 Humidity: ~{humidity}%\n"
        f"⚠️ Note: This is a simulated weather forecast (real data unavailable)"
    )
    
    return result


def get_weather_forecast(city: str, days: int = 3) -> str:
    """Get weather forecast for multiple days.
    
    Args:
        city: City name
        days: Number of days to forecast (1-7)
    
    Returns:
        Formatted forecast or error message
    """
    if not _validate_city_name(city):
        return "❌ Invalid city name"
    
    if not isinstance(days, int) or days < 1 or days > 7:
        return "❌ Days must be between 1 and 7"
    
    city_normalized = _normalize_city_name(city)
    
    logger.info(f"Fetching {days}-day forecast for: {city_normalized}")
    
    # Return simulated forecast for now (real implementation would use Open-Meteo forecast API)
    result = f"📅 **{days}-Day Forecast for {city_normalized}**\n\n"
    conditions = ['☀️ صاف', '☁️ ابری', '🌧️ بارانی', '🌦️ نیمه ابری']
    
    for i in range(1, days + 1):
        import random
        result += f"Day {i}: {random.choice(conditions)}, ~{random.randint(15, 30)}°C\n"
    
    return result


def get_air_quality(city: str) -> str:
    """Get air quality information for a city.
    
    Args:
        city: City name
    
    Returns:
        Air quality information
    """
    if not _validate_city_name(city):
        return "❌ Invalid city name"
    
    city_normalized = _normalize_city_name(city)
    
    # Simulated response
    logger.info(f"Fetching air quality for: {city_normalized}")
    
    return (
        f"🌍 **Air Quality in {city_normalized}**\n"
        f"AQI: Moderate (50-100)\n"
        f"📊 Status: متوسط\n"
        f"⚠️ Note: Air quality data is simulated"
    )


# Add urllib.parse for URL encoding
import urllib.parse
