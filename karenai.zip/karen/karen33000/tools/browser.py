# tools/browser.py
import urllib.request
import re
import logging
from typing import Tuple
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# Constants
MAX_CONTENT_LENGTH = 4000
DEFAULT_TIMEOUT = 15
BUFFER_SIZE = 8192


def _is_valid_url(url: str) -> bool:
    """Validate URL format"""
    if not url or not isinstance(url, str):
        return False
    try:
        result = urlparse(url)
        return all([result.scheme in ['http', 'https'], result.netloc])
    except Exception:
        return False


def _extract_text_from_html(html: str) -> str:
    """Extract clean text from HTML content"""
    try:
        # Remove script and style tags
        clean_html = re.sub(r'<(script|style).*?>.*?</\1>', '', html, flags=re.DOTALL)
        # Remove HTML tags
        text = re.sub(r'<[^>]*>', ' ', clean_html)
        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    except Exception as e:
        logger.error(f"Error extracting text from HTML: {e}")
        return ""


def browse_url(url: str) -> str:
    """Fetches the raw text content of a given URL. Use this to read the contents of a webpage.
    
    Args:
        url: The exact HTTP or HTTPS URL to browse (e.g., 'https://example.com').
    
    Returns:
        Extracted text content (max 4000 chars) or error message.
    """
    # Validate URL
    if not _is_valid_url(url):
        error_msg = "Invalid URL format. Please provide a valid HTTP/HTTPS URL."
        logger.warning(f"Invalid URL provided: {url}")
        return f"❌ {error_msg}"
    
    logger.info(f"Browsing URL: {url}")
    
    try:
        # Create request with proper headers
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        req = urllib.request.Request(url, headers=headers)
        
        # Fetch content with timeout
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
            # Check content type
            content_type = response.headers.get('Content-Type', '')
            if 'text' not in content_type and 'html' not in content_type:
                logger.warning(f"Non-text content type: {content_type}")
                return f"⚠️ Content is not HTML/text (Type: {content_type[:50]})"
            
            # Read content in chunks to avoid memory issues
            content = b''
            while len(content) < MAX_CONTENT_LENGTH * 2:  # Read slightly more
                chunk = response.read(BUFFER_SIZE)
                if not chunk:
                    break
                content += chunk
            
            # Decode HTML
            html = content.decode('utf-8', errors='ignore')
            logger.debug(f"Downloaded {len(html)} bytes from {url}")
            
            # Extract text
            text = _extract_text_from_html(html)
            
            # Limit output length
            text = text[:MAX_CONTENT_LENGTH]
            
            if not text:
                logger.warning(f"No text content extracted from {url}")
                return "⚠️ No readable text content found on this page."
            
            logger.info(f"Successfully extracted {len(text)} characters from {url}")
            return text
            
    except urllib.error.URLError as ue:
        error_msg = f"Cannot reach URL - Network error: {ue.reason}"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except urllib.error.HTTPError as he:
        if he.code == 404:
            error_msg = "Page not found (404)"
        elif he.code == 403:
            error_msg = "Access forbidden (403)"
        elif he.code == 500:
            error_msg = "Server error (500)"
        else:
            error_msg = f"HTTP Error {he.code}"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except socket.timeout:
        error_msg = f"Request timeout after {DEFAULT_TIMEOUT} seconds"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except Exception as e:
        error_msg = f"Error browsing webpage: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


def get_page_title(url: str) -> str:
    """Extract page title from URL
    
    Args:
        url: The URL to fetch title from
    
    Returns:
        Page title or error message
    """
    if not _is_valid_url(url):
        return "❌ Invalid URL format"
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        req = urllib.request.Request(url, headers=headers)
        
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
            html = response.read(MAX_CONTENT_LENGTH).decode('utf-8', errors='ignore')
            
            # Extract title tag
            title_match = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
            if title_match:
                return f"📄 {title_match.group(1)}"
            
            # Try h1 tag as fallback
            h1_match = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            if h1_match:
                return f"📄 {h1_match.group(1)}"
            
            return "⚠️ Could not find page title"
            
    except Exception as e:
        logger.error(f"Error getting page title from {url}: {e}")
        return f"⚠️ Error: {str(e)}"


# Optional: import socket for timeout handling
try:
    import socket
except ImportError:
    pass
