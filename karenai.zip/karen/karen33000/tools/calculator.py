# tools/calculator.py
import logging

logger = logging.getLogger(__name__)

def calculate_math(expression: str) -> str:
    """Evaluates mathematical operations safely.
    Args:
        expression: A string containing math operations (e.g., '14 * 12 + 5').
    """
    if not expression or not expression.strip():
        logger.warning("تلاش برای محاسبه‌ی عبارت خالی")
        return "Error: Empty expression"
    
    try:
        # فیلتر کردن اولیه‌ برای اجرای نسبتاً ایمن
        allowed_chars = set("0123456789+-*/(). ")
        if not set(expression).issubset(allowed_chars):
            logger.warning(f"عبارت ناایمن شامل کاراکتر‌های غیرمجاز: {expression}")
            return "Error: Contains unsafe characters."
        result = eval(expression, {"__builtins__": None}, {})
        logger.debug(f"محاسبه‌ی موفق: {expression} = {result}")
        return f"Result of `{expression}` is: {result}"
    except ZeroDivisionError:
        logger.warning(f"تقسیم بر صفر در: {expression}")
        return "Error: Division by zero"
    except SyntaxError as se:
        logger.warning(f"خطای ترکیب دستوری: {se}")
        return f"Syntax error: {str(se)}"
    except Exception as e:
        logger.error(f"خطا در محاسبه {expression}: {e}", exc_info=True)
        return f"Calculation failed: {str(e)}"