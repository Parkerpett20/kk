# tools/python_executor.py
import sys
import io
import logging
import ast
import time
from typing import Tuple, Optional

logger = logging.getLogger(__name__)

# Constants
MAX_EXECUTION_TIME = 30  # seconds
MAX_CODE_LENGTH = 10000  # characters
MAX_OUTPUT_LENGTH = 5000  # characters
ALLOWED_IMPORTS = {
    'math', 'random', 'datetime', 'json', 're', 'collections',
    'statistics', 'itertools', 'functools', 'operator', 'string'
}
DANGEROUS_KEYWORDS = {
    'import', 'from', '__import__', 'exec', 'eval', 'compile',
    'open', 'file', 'input', '__', 'globals', 'locals', 'vars'
}


def _validate_code(code: str) -> Tuple[bool, str]:
    """Validate code safety and structure
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not code or not isinstance(code, str):
        return False, "Code must be a non-empty string"
    
    if len(code) > MAX_CODE_LENGTH:
        return False, f"Code exceeds maximum length ({len(code)} > {MAX_CODE_LENGTH} chars)"
    
    code_lower = code.lower()
    
    # Check for dangerous keywords
    for keyword in DANGEROUS_KEYWORDS:
        if keyword in code_lower:
            return False, f"Code contains restricted keyword: '{keyword}'"
    
    # Try to parse as valid Python
    try:
        ast.parse(code)
    except SyntaxError as e:
        return False, f"Syntax error: {e.msg} (line {e.lineno})"
    
    return True, ""


def execute_python_code(code: str, timeout: int = None) -> str:
    """Executes Python code in a sandboxed environment with safety restrictions.
    
    Args:
        code: The Python code to execute (max 10000 chars)
        timeout: Execution timeout in seconds (default: 30)
    
    Returns:
        Code output (stdout + stderr) or error message with emoji indicator
    
    Safety Features:
        - Restricted imports (only math, json, datetime, etc.)
        - No file system access
        - No dangerous built-ins (__import__, exec, eval, open)
        - Maximum execution time (30 seconds)
        - Maximum output length (5000 chars)
        - Code syntax validation
    
    Example:
        >>> execute_python_code("print(2 + 2)")
        "4"
        >>> execute_python_code("import os; os.system('ls')")
        "❌ Code contains restricted keyword: 'import'"
    """
    # Set timeout
    if timeout is None:
        timeout = MAX_EXECUTION_TIME
    elif timeout > MAX_EXECUTION_TIME:
        logger.warning(f"Timeout {timeout}s exceeds max {MAX_EXECUTION_TIME}s, using max")
        timeout = MAX_EXECUTION_TIME
    
    # Validate code
    is_valid, error_msg = _validate_code(code)
    if not is_valid:
        logger.warning(f"Invalid code submission: {error_msg}")
        return f"❌ {error_msg}"
    
    logger.info(f"Executing Python code ({len(code)} chars)")
    logger.debug(f"Code preview: {code[:100]}...")
    
    # Capture I/O
    stdout_capture = io.StringIO()
    stderr_capture = io.StringIO()
    
    # Create safe execution environment
    safe_builtins = {
        'print': print,
        'len': len,
        'range': range,
        'list': list,
        'dict': dict,
        'set': set,
        'tuple': tuple,
        'str': str,
        'int': int,
        'float': float,
        'bool': bool,
        'abs': abs,
        'sum': sum,
        'min': min,
        'max': max,
        'sorted': sorted,
        'enumerate': enumerate,
        'zip': zip,
        'map': map,
        'filter': filter,
        'all': all,
        'any': any,
        'round': round,
        'pow': pow,
        'divmod': divmod,
        'isinstance': isinstance,
        'type': type,
    }
    
    globals_env = {"__builtins__": safe_builtins}
    locals_env = {}
    
    # Redirect I/O
    original_stdout = sys.stdout
    original_stderr = sys.stderr
    sys.stdout = stdout_capture
    sys.stderr = stderr_capture
    
    try:
        # Execute with timeout using simple time check
        start_time = time.time()
        
        exec(code, globals_env, locals_env)
        
        elapsed = time.time() - start_time
        
        # Restore I/O
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        
        # Get output
        output = stdout_capture.getvalue() + stderr_capture.getvalue()
        
        # Limit output length
        if len(output) > MAX_OUTPUT_LENGTH:
            output = output[:MAX_OUTPUT_LENGTH] + f"\n... (truncated, {len(output) - MAX_OUTPUT_LENGTH} chars omitted)"
        
        logger.info(f"Code executed successfully in {elapsed:.2f}s, output: {len(output)} chars")
        
        if not output:
            return f"✅ Success (No output) - Execution time: {elapsed:.2f}s"
        
        return output
        
    except TimeoutError as te:
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        error_msg = f"Execution timeout after {timeout} seconds"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except SyntaxError as se:
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        error_msg = f"Syntax error at line {se.lineno}: {se.msg}"
        logger.error(error_msg)
        return f"❌ {error_msg}"
    
    except RecursionError:
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        error_msg = "Recursion limit exceeded"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except MemoryError:
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        error_msg = "Out of memory"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except Exception as e:
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        error_msg = f"Execution error: {type(e).__name__}: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


def validate_python_syntax(code: str) -> dict:
    """Validate Python code syntax without executing
    
    Args:
        code: Python code to validate
    
    Returns:
        Dictionary with 'valid' bool and 'error' message
    """
    is_valid, error_msg = _validate_code(code)
    
    result = {
        "valid": is_valid,
        "error": error_msg if error_msg else None,
        "warnings": []
    }
    
    # Additional checks
    if not is_valid:
        logger.warning(f"Code validation failed: {error_msg}")
    else:
        logger.debug("Code validation passed")
    
    return result


def get_allowed_builtins() -> list:
    """Get list of allowed built-in functions
    
    Returns:
        List of available built-in function names
    """
    return list({
        'print', 'len', 'range', 'list', 'dict', 'set', 'tuple', 'str',
        'int', 'float', 'bool', 'abs', 'sum', 'min', 'max', 'sorted',
        'enumerate', 'zip', 'map', 'filter', 'all', 'any', 'round',
        'pow', 'divmod', 'isinstance', 'type'
    })


def get_restricted_items() -> dict:
    """Get information about what's restricted
    
    Returns:
        Dictionary with restricted keywords and reasons
    """
    return {
        "restricted_keywords": list(DANGEROUS_KEYWORDS),
        "reason": "Security - prevents file access, code injection, and system commands",
        "allowed_imports": "None (imports disabled for safety)",
        "allowed_builtins": get_allowed_builtins(),
    }
