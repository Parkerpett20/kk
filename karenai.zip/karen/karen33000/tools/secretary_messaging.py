"""ابزار ارسال پیام به مخاطبین از طریق userbot منشی شخصی.

این ابزار به کارن (هوش مصنوعی) اجازه می‌دهد پیام‌هایی را از طریق
اکانت تلگرام کاربر به مخاطبینش ارسال کند. مثلاً کاربر می‌گوید:
«به Nn بگو بیا بیرون» و کارن پیام «مهدی می‌گه بیا بیرون» را به Nn ارسال می‌کند.
"""
import logging
from tools.userbot_manager import get_client_for_user, is_authorized, _run_async
from memory.user_settings import user_settings

logger = logging.getLogger(__name__)


async def _resolve_contact_by_name(user_id: int, contact_name: str):
    """جستجوی مخاطب بر اساس نام در دیالوگ‌های تلگرام کاربر.

    Args:
        user_id: آیدی کاربر کارن
        contact_name: نام مخاطب برای جستجو (مثلاً "Nn" یا "علی")

    Returns:
        (entity, display_name) یا (None, None) اگر پیدا نشد
    """
    client = get_client_for_user(user_id)
    if not client:
        return None, None

    try:
        from telethon.tl.types import User, Chat, Channel

        contact_name_lower = contact_name.lower().strip()

        # دریافت لیست دیالوگ‌ها
        dialogs = await client.get_dialogs(limit=100)

        # جستجو در دیالوگ‌ها - اولویت با کاربران (نه گروه‌ها)
        best_match = None
        best_match_name = None
        best_score = 0

        for dialog in dialogs:
            entity = dialog.entity
            # فقط کاربران (نه گروه‌ها یا کانال‌ها)
            if not isinstance(entity, User):
                continue
            # نادیده گرفتن ربات‌ها و خود کاربر
            if hasattr(entity, 'bot') and entity.bot:
                continue

            # ساخت نام کامل
            first_name = (entity.first_name or '').strip()
            last_name = (entity.last_name or '').strip()
            full_name = f"{first_name} {last_name}".strip()
            username = (entity.username or '').strip()

            # محاسبه امتیاز تطابق
            score = 0
            if full_name.lower() == contact_name_lower:
                score = 100  # تطابق کامل
            elif full_name.lower().startswith(contact_name_lower):
                score = 80  # تطابق از ابتدا
            elif contact_name_lower in full_name.lower():
                score = 60  # شامل شدن
            elif username.lower() == contact_name_lower:
                score = 70  # تطابق یوزرنیم
            elif username.lower().startswith(contact_name_lower):
                score = 50  # تطابق یوزرنیم از ابتدا
            elif first_name.lower() == contact_name_lower:
                score = 75  # تطابق فقط نام کوچک

            if score > best_score:
                best_score = score
                best_match = entity
                best_match_name = full_name or username or str(entity.id)

        if best_match and best_score >= 50:
            logger.info(f"Resolved contact '{contact_name}' to '{best_match_name}' (id: {best_match.id}, score: {best_score})")
            return best_match, best_match_name

        return None, None

    except Exception as e:
        logger.error(f"Error resolving contact '{contact_name}' for user {user_id}: {e}")
        return None, None


async def _send_message_async(user_id: int, contact_name: str, message: str):
    """ارسال پیام به مخاطب از طریق userbot (نسخه async)."""
    # بررسی آیا userbot متصل است - مستقیماً از _clients بررسی می‌کنیم
    # تا از deadlock جلوگیری شود (is_authorized از _run_async استفاده می‌کند
    # که داخل _run_async دیگر باعث deadlock می‌شود)
    from tools.userbot_manager import _clients, async_reconnect_user
    client = _clients.get(user_id)
    if not client:
        # تلاش برای اتصال مجدد با سشن ذخیره شده (نسخه async برای جلوگیری از deadlock)
        logger.info(f"Client not in memory for user {user_id}, trying to reconnect...")
        if await async_reconnect_user(user_id):
            client = _clients.get(user_id)
        else:
            # تلاش مجدد - گاهی اوقات اتصال اول به دلیل مسائل شبکه ناموفق است
            logger.info(f"First reconnect attempt failed for user {user_id}, retrying...")
            if await async_reconnect_user(user_id):
                client = _clients.get(user_id)

        if not client:
            return {"success": False, "error": "منشی شخصی در حافظه بارگذاری نشده است. سشن تلگرام شما ممکن است منقضی شده باشد. لطفاً از منوی /settings بخش منشی شخصی، مجدداً وارد شوید."}

    # بررسی واقعی بودن authorization
    try:
        is_auth = await client.is_user_authorized()
        if not is_auth:
            return {"success": False, "error": "سشن تلگرام شما معتبر نیست (authorized نیست). لطفاً از منوی /settings بخش منشی شخصی، مجدداً وارد شوید."}
    except Exception as e:
        logger.error(f"Error checking authorization for user {user_id}: {e}", exc_info=True)
        return {"success": False, "error": "خطا در بررسی وضعیت منشی. لطفاً کمی بعد دوباره تلاش کنید."}

    # جستجوی مخاطب
    entity, display_name = await _resolve_contact_by_name(user_id, contact_name)
    if not entity:
        return {"success": False, "error": f"مخاطبی با نام '{contact_name}' در لیست چت‌های شما پیدا نشد. مطمئن شوید نام را درست وارد کرده‌اید."}

    # ارسال پیام
    try:
        await client.send_message(entity.id, message)
        logger.info(f"Secretary sent message to {display_name} (id: {entity.id}) on behalf of user {user_id}")
        return {
            "success": True,
            "contact_name": display_name,
            "contact_id": entity.id,
            "message": message
        }
    except Exception as e:
        logger.error(f"Error sending message to {contact_name} for user {user_id}: {e}")
        return {"success": False, "error": f"خطا در ارسال پیام: {str(e)}"}


def send_message_to_contact(contact_name: str, message: str, user_id: int = None) -> str:
    """ارسال پیام به یک مخاطب تلگرام از طریق اکانت کاربر (userbot).

    این تابع به کارن اجازه می‌دهد پیامی را از طرف کاربر به مخاطبینش ارسال کند.
    مثلاً وقتی کاربر می‌گوید «به Nn بگو بیا بیرون»، این تابع پیام را به Nn ارسال می‌کند.

    Args:
        contact_name: نام مخاطب (نام، نام خانوادگی یا یوزرنیم). مثلاً "Nn" یا "علی" یا "mahdi"
        message: پیامی که باید ارسال شود. مثلاً "مهدی می‌گه بیا بیرون"
        user_id: آیدی عددی کاربر کارن (اختیاری - اگر داده نشود از تنظیمات استفاده می‌شود)

    Returns:
        پیام نتیجه به صورت متن
    """
    if not contact_name or not message:
        return "❌ نام مخاطب و پیام هر دو لازم هستند."

    # اگر user_id داده نشده، از تنظیمات سراسری استفاده کن
    # (در عمل از طریق executor با chat_id پاس داده می‌شود)
    if user_id is None:
        # تلاش برای پیدا کردن کاربرانی که منشی فعال دارند
        from tools.secretary_service import get_active_secretaries
        active_users = get_active_secretaries()
        if not active_users:
            return "❌ هیچ کاربری منشی شخصی فعال ندارد."
        if len(active_users) == 1:
            user_id = active_users[0]
        else:
            return f"❌ چند کاربر منشی فعال دارند. user_id لازم است. کاربران فعال: {active_users}"

    try:
        result = _run_async(_send_message_async(user_id, contact_name, message))
        if result.get("success"):
            return f"✅ پیام به {result.get('contact_name', contact_name)} ارسال شد.\n📝 پیام: {message}"
        else:
            return f"❌ {result.get('error', 'خطا در ارسال پیام')}"
    except Exception as e:
        logger.error(f"Error in send_message_to_contact: {e}")
        return f"❌ خطای غیرمنتظره: {str(e)}"


async def _list_contacts_async(user_id: int, query: str = ""):
    """لیست کردن مخاطبین کاربر (نسخه async)."""
    # بررسی مستقیم از _clients برای جلوگیری از deadlock
    from tools.userbot_manager import _clients, async_reconnect_user
    client = _clients.get(user_id)
    if not client:
        # تلاش برای اتصال مجدد با سشن ذخیره شده
        logger.info(f"Client not in memory for user {user_id} (list_contacts), trying to reconnect...")
        if await async_reconnect_user(user_id):
            client = _clients.get(user_id)
        else:
            # تلاش مجدد
            logger.info(f"First reconnect attempt failed for user {user_id} (list_contacts), retrying...")
            if await async_reconnect_user(user_id):
                client = _clients.get(user_id)

        if not client:
            return {"success": False, "error": "منشی شخصی در حافظه بارگذاری نشده است. سشن تلگرام شما ممکن است منقضی شده باشد. لطفاً از منوی /settings بخش منشی شخصی، مجدداً وارد شوید."}

    # بررسی واقعی بودن authorization
    try:
        is_auth = await client.is_user_authorized()
        if not is_auth:
            return {"success": False, "error": "سشن تلگرام شما معتبر نیست. لطفاً از منوی /settings بخش منشی شخصی، مجدداً وارد شوید."}
    except Exception as e:
        logger.error(f"Error checking authorization for user {user_id}: {e}", exc_info=True)
        return {"success": False, "error": "خطا در بررسی وضعیت منشی. لطفاً کمی بعد دوباره تلاش کنید."}

    try:
        from telethon.tl.types import User

        dialogs = await client.get_dialogs(limit=50)
        contacts = []
        query_lower = query.lower().strip() if query else ""

        for dialog in dialogs:
            entity = dialog.entity
            if not isinstance(entity, User):
                continue
            if hasattr(entity, 'bot') and entity.bot:
                continue

            first_name = (entity.first_name or '').strip()
            last_name = (entity.last_name or '').strip()
            full_name = f"{first_name} {last_name}".strip()
            username = entity.username or ''

            if query_lower and query_lower not in full_name.lower() and query_lower not in username.lower():
                continue

            contacts.append({
                "id": entity.id,
                "name": full_name,
                "username": username,
                "phone": getattr(entity, 'phone', None)
            })

        return {"success": True, "contacts": contacts}

    except Exception as e:
        logger.error(f"Error listing contacts for user {user_id}: {e}")
        return {"success": False, "error": str(e)}


def list_contacts(query: str = "", user_id: int = None) -> str:
    """لیست مخاطبین تلگرام کاربر که می‌توان به آن‌ها پیام ارسال کرد.

    Args:
        query: عبارت جستجو (اختیاری). مثلاً "علی" برای فیلتر کردن
        user_id: آیدی عددی کاربر کارن

    Returns:
        لیست مخاطبین به صورت متن
    """
    if user_id is None:
        from tools.secretary_service import get_active_secretaries
        active_users = get_active_secretaries()
        if not active_users:
            return "❌ هیچ کاربری منشی شخصی فعال ندارد."
        if len(active_users) == 1:
            user_id = active_users[0]
        else:
            return f"❌ چند کاربر منشی فعال دارند. user_id لازم است."

    try:
        result = _run_async(_list_contacts_async(user_id, query))
        if result.get("success"):
            contacts = result.get("contacts", [])
            if not contacts:
                return "هیچ مخاطبی یافت نشد."

            lines = [f"📋 لیست مخاطبین ({len(contacts)} نفر):\n"]
            for c in contacts[:20]:  # حداکثر 20 نفر
                name = c["name"]
                username = f" @{c['username']}" if c.get("username") else ""
                lines.append(f"• {name}{username}")

            if len(contacts) > 20:
                lines.append(f"\n... و {len(contacts) - 20} مخاطب دیگر")

            return "\n".join(lines)
        else:
            return f"❌ {result.get('error', 'خطا')}"
    except Exception as e:
        logger.error(f"Error in list_contacts: {e}")
        return f"❌ خطای غیرمنتظره: {str(e)}"