# tools/translate.py
import urllib.request
import urllib.parse
import json
import logging
from typing import Optional
from urllib.error import URLError, HTTPError

logger = logging.getLogger(__name__)

# Supported language pairs
SUPPORTED_LANGUAGES = {
    'en': 'English',
    'fa': 'Persian/Farsi',
    'es': 'Spanish',
    'fr': 'French',
    'de': 'German',
    'it': 'Italian',
    'pt': 'Portuguese',
    'ru': 'Russian',
    'zh': 'Chinese',
    'ja': 'Japanese',
    'ar': 'Arabic',
    'tr': 'Turkish',
}

DEFAULT_TIMEOUT = 15
TRANSLATION_API = "https://api.mymemory.translated.net/get"


def _validate_language_code(lang_code: str) -> bool:
    """Validate language code format"""
    if not lang_code or not isinstance(lang_code, str):
        return False
    if len(lang_code) < 2 or len(lang_code) > 5:
        return False
    if not lang_code.replace('-', '').isalnum():
        return False
    return True


def _validate_text_input(text: str) -> bool:
    """Validate text to translate"""
    if not text or not isinstance(text, str):
        return False
    if len(text.strip()) == 0:
        return False
    if len(text) > 5000:  # Prevent excessively long translations
        return False
    return True


def translate(text: str, from_lang: str = "fa", to_lang: str = "en") -> str:
    """Translates text from one language to another using MyMemory API.
    
    Args:
        text: The text to translate (max 5000 characters)
        from_lang: Language code of the source (default: 'fa' for Persian)
        to_lang: Language code of the target (default: 'en' for English)
    
    Returns:
        Translated text or error message with emoji indicator
    
    Example:
        >>> translate("سلام", from_lang="fa", to_lang="en")
        "Hello"
    """
    # Validate inputs
    if not _validate_text_input(text):
        error_msg = "Invalid text: Please provide non-empty text (max 5000 chars)"
        logger.warning(f"Invalid text input for translation: {text[:50] if text else 'None'}")
        return f"❌ {error_msg}"
    
    if not _validate_language_code(from_lang) or not _validate_language_code(to_lang):
        error_msg = f"Invalid language codes. Use 2-5 character codes (e.g., 'en', 'fa', 'es')"
        logger.warning(f"Invalid language codes: from_lang={from_lang}, to_lang={to_lang}")
        return f"❌ {error_msg}"
    
    if from_lang == to_lang:
        logger.debug(f"Source and target languages are the same: {from_lang}")
        return f"⚠️ Source and target languages are the same: {from_lang}"
    
    logger.info(f"Translating from {from_lang} to {to_lang}")
    
    try:
        # Prepare URL
        encoded_text = urllib.parse.quote(text)
        url = f"{TRANSLATION_API}?q={encoded_text}&langpair={from_lang}|{to_lang}"
        
        logger.debug(f"Translation API URL: {url[:80]}...")
        
        # Make request
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        req = urllib.request.Request(url, headers=headers)
        
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
            # Parse response
            response_data = json.loads(response.read().decode('utf-8'))
            
            # Check response status
            response_status = response_data.get("responseStatus", 0)
            if response_status != 200:
                error_msg = f"Translation API error (status: {response_status})"
                logger.warning(error_msg)
                return f"⚠️ {error_msg}"
            
            # Extract translation
            translated = response_data.get("responseData", {}).get("translatedText", "")
            
            if not translated or translated.strip() == text.strip():
                logger.warning(f"No translation available or identical to source")
                return f"⚠️ No translation available for the given text"
            
            logger.info(f"Translation successful: {len(translated)} characters")
            return translated
            
    except HTTPError as he:
        if he.code == 429:
            error_msg = "Translation service rate limited"
        elif he.code == 503:
            error_msg = "Translation service temporarily unavailable"
        else:
            error_msg = f"Translation service error ({he.code})"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except URLError as ue:
        error_msg = f"Cannot reach translation service: {ue.reason}"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except json.JSONDecodeError as je:
        error_msg = "Invalid response from translation service"
        logger.error(f"{error_msg}: {je}")
        return f"❌ {error_msg}"
    
    except Exception as e:
        error_msg = f"Translation error: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


def get_supported_languages() -> dict:
    """Get list of supported languages
    
    Returns:
        Dictionary of language codes to language names
    """
    return SUPPORTED_LANGUAGES.copy()


def batch_translate(texts: list, from_lang: str = "fa", to_lang: str = "en") -> dict:
    """Translate multiple texts
    
    Args:
        texts: List of text strings to translate
        from_lang: Source language code
        to_lang: Target language code
    
    Returns:
        Dictionary with 'successful' and 'failed' keys containing results
    """
    if not isinstance(texts, list):
        logger.warning("batch_translate received non-list input")
        return {"successful": [], "failed": ["Invalid input: expected list"]}
    
    if len(texts) > 20:  # Reasonable limit for batch operations
        logger.warning(f"Batch size too large: {len(texts)} > 20")
        return {"successful": [], "failed": ["Batch size exceeds limit (max 20)"]}
    
    results = {"successful": [], "failed": []}
    
    for i, text in enumerate(texts):
        logger.debug(f"Translating batch item {i+1}/{len(texts)}")
        result = translate(text, from_lang, to_lang)
        
        # Check if it's an error (starts with emoji indicators)
        if result.startswith("❌") or result.startswith("⚠️"):
            results["failed"].append({"original": text, "error": result})
        else:
            results["successful"].append({"original": text, "translated": result})
    
    logger.info(f"Batch translation complete: {len(results['successful'])} successful, {len(results['failed'])} failed")
    return results
