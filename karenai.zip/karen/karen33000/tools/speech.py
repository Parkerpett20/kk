# tools/speech.py
import os
import urllib.request
import urllib.parse
import logging
from pathlib import Path
from typing import Tuple
from urllib.error import URLError, HTTPError

logger = logging.getLogger(__name__)

# Constants
WORKSPACE_DIR = "workspace"
MAX_TEXT_LENGTH = 250  # Google TTS limit
SUPPORTED_LANGUAGES = {
    'fa': 'Persian',
    'en': 'English',
    'es': 'Spanish',
    'fr': 'French',
    'de': 'German',
    'ar': 'Arabic',
}
DEFAULT_TIMEOUT = 15


def _ensure_workspace_dir() -> bool:
    """Ensure workspace directory exists"""
    try:
        Path(WORKSPACE_DIR).mkdir(exist_ok=True)
        logger.debug(f"Workspace directory ready: {WORKSPACE_DIR}")
        return True
    except Exception as e:
        logger.error(f"Failed to create workspace directory: {e}")
        return False


def _validate_text_input(text: str) -> bool:
    """Validate text for speech conversion"""
    if not text or not isinstance(text, str):
        return False
    if len(text.strip()) == 0:
        return False
    return True


def _validate_filename(filename: str) -> bool:
    """Validate and sanitize filename"""
    if not filename or not isinstance(filename, str):
        return False
    # Check for dangerous characters
    dangerous_chars = ['/', '\\', ':', '*', '?', '"', '<', '>', '|']
    if any(char in filename for char in dangerous_chars):
        return False
    # Must be an audio file
    if not filename.lower().endswith(('.mp3', '.wav', '.ogg')):
        return False
    return True


def speak_text(text: str, filename: str = "output.mp3", language: str = "fa") -> str:
    """Converts text to spoken audio and saves it in workspace.
    
    Args:
        text: The text string to convert to speech (max 250 chars)
        filename: Target filename for the saved audio file (must end in .mp3, .wav, or .ogg)
        language: Target language code (default: 'fa' for Persian)
    
    Returns:
        Success message with file path or error message with emoji indicator
    
    Example:
        >>> speak_text("سلام جهان", filename="greeting.mp3", language="fa")
        "✅ Speech generated. File saved as workspace/greeting.mp3"
    """
    # Validate inputs
    if not _validate_text_input(text):
        error_msg = "Invalid text: Please provide non-empty text"
        logger.warning(f"Invalid text for speech: {text}")
        return f"❌ {error_msg}"
    
    if not _validate_filename(filename):
        error_msg = "Invalid filename: Must be .mp3, .wav, or .ogg file without special characters"
        logger.warning(f"Invalid filename: {filename}")
        return f"❌ {error_msg}"
    
    if language not in SUPPORTED_LANGUAGES:
        error_msg = f"Unsupported language: {language}. Supported: {', '.join(SUPPORTED_LANGUAGES.keys())}"
        logger.warning(error_msg)
        return f"❌ {error_msg}"
    
    # Ensure workspace exists
    if not _ensure_workspace_dir():
        return "❌ Failed to create workspace directory"
    
    # Limit text length
    text_truncated = text[:MAX_TEXT_LENGTH]
    if len(text) > MAX_TEXT_LENGTH:
        logger.debug(f"Text truncated from {len(text)} to {MAX_TEXT_LENGTH} chars")
    
    safe_path = os.path.join(WORKSPACE_DIR, filename)
    
    try:
        # URL encode text
        encoded_text = urllib.parse.quote(text_truncated)
        url = f"https://translate.google.com/translate_tts?ie=UTF-8&tl={language}&client=tw-ob&q={encoded_text}"
        
        logger.info(f"Generating speech for {len(text_truncated)} chars in {language}")
        logger.debug(f"TTS URL: {url[:80]}...")
        
        # Make request
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        req = urllib.request.Request(url, headers=headers)
        
        # Fetch audio
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
            # Check content type
            content_type = response.headers.get('Content-Type', '')
            if 'audio' not in content_type and 'mpeg' not in content_type:
                logger.warning(f"Unexpected content type: {content_type}")
            
            # Write file
            audio_data = response.read()
            with open(safe_path, "wb") as f:
                f.write(audio_data)
            
            logger.info(f"Speech generated successfully: {len(audio_data)} bytes")
            return f"✅ Speech generated. File saved as {safe_path} ({len(audio_data)} bytes)"
    
    except HTTPError as he:
        if he.code == 403:
            error_msg = "Access denied - Google TTS service blocked request"
        elif he.code == 429:
            error_msg = "Rate limited - Too many requests to TTS service"
        else:
            error_msg = f"HTTP error {he.code}"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except URLError as ue:
        error_msg = f"Cannot reach speech service: {ue.reason}"
        logger.error(error_msg)
        return f"⚠️ {error_msg}"
    
    except IOError as ie:
        error_msg = f"File write error: {str(ie)}"
        logger.error(error_msg)
        return f"❌ {error_msg}"
    
    except Exception as e:
        error_msg = f"Speech generation failed: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


def get_supported_languages() -> dict:
    """Get supported languages for speech generation
    
    Returns:
        Dictionary of language codes to language names
    """
    return SUPPORTED_LANGUAGES.copy()


def list_generated_speeches() -> list:
    """List all generated speech files in workspace
    
    Returns:
        List of audio filenames, or empty list if workspace doesn't exist
    """
    try:
        if not os.path.exists(WORKSPACE_DIR):
            logger.debug("Workspace directory does not exist")
            return []
        
        audio_files = [
            f for f in os.listdir(WORKSPACE_DIR)
            if f.lower().endswith(('.mp3', '.wav', '.ogg'))
        ]
        logger.debug(f"Found {len(audio_files)} audio files")
        return audio_files
    
    except Exception as e:
        logger.error(f"Error listing audio files: {e}")
        return []
