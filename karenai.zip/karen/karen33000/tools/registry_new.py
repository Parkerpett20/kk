"""Tool Registry - Central registry for all available tools and plugins"""

import logging
from typing import List, Dict, Any, Optional
from google.genai import types

logger = logging.getLogger(__name__)

# Import tool functions
try:
    from tools.calculator import calculate_math
    logger.debug("Calculator tool imported")
except ImportError as e:
    logger.warning(f"Could not import calculator tool: {e}")

try:
    from tools.browser import browse_url, get_page_title
    logger.debug("Browser tool imported")
except ImportError as e:
    logger.warning(f"Could not import browser tool: {e}")

try:
    from tools.search import get_search_tool, perform_web_search
    logger.debug("Search tool imported")
except ImportError as e:
    logger.warning(f"Could not import search tool: {e}")

try:
    from tools.youtube import search_youtube, get_youtube_video_info
    logger.debug("YouTube tool imported")
except ImportError as e:
    logger.warning(f"Could not import youtube tool: {e}")

try:
    from tools.group_management import invite_chat_member, create_group_invite_link, get_group_admins
    logger.debug("Group management tool imported")
except ImportError as e:
    logger.warning(f"Could not import group management tool: {e}")

try:
    from tools.translate import translate, batch_translate
    logger.debug("Translate tool imported")
except ImportError as e:
    logger.warning(f"Could not import translate tool: {e}")

try:
    from tools.speech import speak_text, list_generated_speeches
    logger.debug("Speech tool imported")
except ImportError as e:
    logger.warning(f"Could not import speech tool: {e}")

try:
    from tools.vision import analyze_image_file, analyze_image_url
    logger.debug("Vision tool imported")
except ImportError as e:
    logger.warning(f"Could not import vision tool: {e}")

try:
    from tools.image_generation import generate_image_url, generate_image_batch
    logger.debug("Image generation tool imported")
except ImportError as e:
    logger.warning(f"Could not import image generation tool: {e}")

try:
    from tools.github import get_repo_info, search_repositories, get_user_info
    logger.debug("GitHub tool imported")
except ImportError as e:
    logger.warning(f"Could not import github tool: {e}")

try:
    from tools.weather import get_weather, get_weather_forecast, get_air_quality
    logger.debug("Weather tool imported")
except ImportError as e:
    logger.warning(f"Could not import weather tool: {e}")

try:
    from tools.filesystem import read_file, write_file, list_files
    logger.debug("Filesystem tool imported")
except ImportError as e:
    logger.warning(f"Could not import filesystem tool: {e}")

try:
    from tools.python_executor import execute_python_code, validate_python_syntax
    logger.debug("Python executor tool imported")
except ImportError as e:
    logger.warning(f"Could not import python executor tool: {e}")

try:
    from tools.secretary_messaging import send_message_to_contact, list_contacts
    logger.debug("Secretary messaging tool imported")
except ImportError as e:
    logger.warning(f"Could not import secretary messaging tool: {e}")

try:
    from tools.office import (
        create_office_document, view_office_document, get_office_content,
        query_office_document, validate_office_document, add_office_element,
        set_office_property, remove_office_element, move_office_element,
        swap_office_elements, batch_office_operations, text_to_word_document,
        text_to_powerpoint, data_to_excel, list_office_files,
        get_office_help, officecli_version
    )
    logger.debug("Office document tools imported")
except ImportError as e:
    logger.warning(f"Could not import office document tools: {e}")

# Import plugin functions
try:
    from plugins.weather.weather_plugin import fetch_weather
    logger.debug("Weather plugin imported")
except ImportError as e:
    logger.warning(f"Could not import weather plugin: {e}")

try:
    from plugins.github.github_plugin import fetch_github_user_profile
    logger.debug("GitHub plugin imported")
except ImportError as e:
    logger.warning(f"Could not import github plugin: {e}")

try:
    from plugins.calendar.calendar_plugin import get_gregorian_calendar_details
    logger.debug("Calendar plugin imported")
except ImportError as e:
    logger.warning(f"Could not import calendar plugin: {e}")

try:
    from plugins.notes.notes_plugin import save_note, read_note
    logger.debug("Notes plugin imported")
except ImportError as e:
    logger.warning(f"Could not import notes plugin: {e}")

try:
    from plugins.todo.todo_plugin import add_todo_item, list_todo_items, complete_todo_item
    logger.debug("TODO plugin imported")
except ImportError as e:
    logger.warning(f"Could not import todo plugin: {e}")


# Tool categories
TOOL_CATEGORIES = {
    'calculation': ['calculate_math'],
    'browser': ['browse_url', 'get_page_title'],
    'search': ['perform_web_search', 'get_search_tool'],
    'media': ['search_youtube', 'get_youtube_video_info', 'analyze_image_file', 'analyze_image_url', 'generate_image_url'],
    'language': ['translate', 'batch_translate'],
    'audio': ['speak_text', 'list_generated_speeches'],
    'developer': ['get_repo_info', 'search_repositories', 'get_user_info', 'execute_python_code'],
    'info': ['get_weather', 'get_weather_forecast', 'get_air_quality'],
    'files': ['read_file', 'write_file', 'list_files'],
    'group_management': ['invite_chat_member', 'create_group_invite_link', 'get_group_admins'],
    'secretary': ['send_message_to_contact', 'list_contacts'],
    'office': [
        'create_office_document', 'view_office_document', 'get_office_content',
        'query_office_document', 'validate_office_document', 'add_office_element',
        'set_office_property', 'remove_office_element', 'move_office_element',
        'swap_office_elements', 'batch_office_operations', 'text_to_word_document',
        'text_to_powerpoint', 'data_to_excel', 'list_office_files',
        'get_office_help', 'officecli_version'
    ],
}


def get_available_tools(
    needs_search: bool = False,
    category: Optional[str] = None,
    exclude_dangerous: bool = True
) -> List[Any]:
    """Get available tools registry, optionally filtered by category.
    
    Args:
        needs_search: Include Google Search tool if True
        category: Filter by tool category (None = all)
        exclude_dangerous: Exclude potentially dangerous tools like code execution
    
    Returns:
        List of available tool functions
    
    Example:
        >>> tools = get_available_tools(needs_search=True)
        >>> calculator_tools = get_available_tools(category='calculation')
    """
    tools = []
    
    # Add tools by category if specified
    if category:
        if category not in TOOL_CATEGORIES:
            logger.warning(f"Unknown tool category: {category}")
            return []
        
        selected = TOOL_CATEGORIES[category]
        
        # Map tool names to functions (simplified)
        tool_map = {
            'calculate_math': calculate_math if 'calculate_math' in globals() else None,
            'browse_url': browse_url if 'browse_url' in globals() else None,
            'get_search_tool': get_search_tool if 'get_search_tool' in globals() else None,
            'perform_web_search': perform_web_search if 'perform_web_search' in globals() else None,
            'search_youtube': search_youtube if 'search_youtube' in globals() else None,
            'translate': translate if 'translate' in globals() else None,
            'speak_text': speak_text if 'speak_text' in globals() else None,
            'analyze_image_file': analyze_image_file if 'analyze_image_file' in globals() else None,
            'generate_image_url': generate_image_url if 'generate_image_url' in globals() else None,
            'get_repo_info': get_repo_info if 'get_repo_info' in globals() else None,
            'get_weather': get_weather if 'get_weather' in globals() else None,
            'execute_python_code': execute_python_code if 'execute_python_code' in globals() and not exclude_dangerous else None,
            'invite_chat_member': invite_chat_member if 'invite_chat_member' in globals() else None,
            'create_group_invite_link': create_group_invite_link if 'create_group_invite_link' in globals() else None,
            'get_group_admins': get_group_admins if 'get_group_admins' in globals() else None,
            'send_message_to_contact': send_message_to_contact if 'send_message_to_contact' in globals() else None,
            'list_contacts': list_contacts if 'list_contacts' in globals() else None,
            'create_office_document': create_office_document if 'create_office_document' in globals() else None,
            'view_office_document': view_office_document if 'view_office_document' in globals() else None,
            'get_office_content': get_office_content if 'get_office_content' in globals() else None,
            'query_office_document': query_office_document if 'query_office_document' in globals() else None,
            'validate_office_document': validate_office_document if 'validate_office_document' in globals() else None,
            'add_office_element': add_office_element if 'add_office_element' in globals() else None,
            'set_office_property': set_office_property if 'set_office_property' in globals() else None,
            'remove_office_element': remove_office_element if 'remove_office_element' in globals() else None,
            'move_office_element': move_office_element if 'move_office_element' in globals() else None,
            'swap_office_elements': swap_office_elements if 'swap_office_elements' in globals() else None,
            'batch_office_operations': batch_office_operations if 'batch_office_operations' in globals() else None,
            'text_to_word_document': text_to_word_document if 'text_to_word_document' in globals() else None,
            'text_to_powerpoint': text_to_powerpoint if 'text_to_powerpoint' in globals() else None,
            'data_to_excel': data_to_excel if 'data_to_excel' in globals() else None,
            'list_office_files': list_office_files if 'list_office_files' in globals() else None,
            'get_office_help': get_office_help if 'get_office_help' in globals() else None,
            'officecli_version': officecli_version if 'officecli_version' in globals() else None,
        }
        
        for tool_name in selected:
            if tool_name in tool_map and tool_map[tool_name]:
                tools.append(tool_map[tool_name])
                logger.debug(f"Added tool from category {category}: {tool_name}")
    
    else:
        # Add all tools
        base_tools = [
            calculate_math if 'calculate_math' in globals() else None,
            browse_url if 'browse_url' in globals() else None,
            search_youtube if 'search_youtube' in globals() else None,
            translate if 'translate' in globals() else None,
            speak_text if 'speak_text' in globals() else None,
            analyze_image_file if 'analyze_image_file' in globals() else None,
            generate_image_url if 'generate_image_url' in globals() else None,
            get_repo_info if 'get_repo_info' in globals() else None,
            get_weather if 'get_weather' in globals() else None,
            read_file if 'read_file' in globals() else None,
            send_message_to_contact if 'send_message_to_contact' in globals() else None,
            list_contacts if 'list_contacts' in globals() else None,
            text_to_word_document if 'text_to_word_document' in globals() else None,
            text_to_powerpoint if 'text_to_powerpoint' in globals() else None,
            data_to_excel if 'data_to_excel' in globals() else None,
            list_office_files if 'list_office_files' in globals() else None,
        ]
        
        # Add Python executor only if not excluded
        if not exclude_dangerous:
            base_tools.append(execute_python_code if 'execute_python_code' in globals() else None)
        
        # Filter out None values
        tools = [t for t in base_tools if t is not None]
        logger.info(f"Loaded {len(tools)} base tools")
    
    # Add search tool if requested
    if needs_search:
        try:
            search_tool = types.Tool(googleSearch=types.GoogleSearch())
            tools.append(search_tool)
            logger.debug("Added Google Search tool")
        except Exception as e:
            logger.error(f"Failed to add Google Search tool: {e}")
    
    logger.info(f"Returning {len(tools)} tools")
    return tools


def get_tool_info(tool_name: str) -> Dict[str, Any]:
    """Get information about a specific tool.
    
    Args:
        tool_name: Name of the tool
    
    Returns:
        Dictionary with tool information (name, description, parameters)
    """
    tool_info = {
        'calculate_math': {
            'name': 'Math Calculator',
            'description': 'Evaluate mathematical expressions safely',
            'category': 'calculation',
            'parameters': ['expression'],
            'safe': True
        },
        'browse_url': {
            'name': 'Web Browser',
            'description': 'Browse and extract text from web pages',
            'category': 'browser',
            'parameters': ['url'],
            'safe': True
        },
        'search_youtube': {
            'name': 'YouTube Search',
            'description': 'Search for videos on YouTube',
            'category': 'media',
            'parameters': ['query'],
            'safe': True
        },
        'translate': {
            'name': 'Translator',
            'description': 'Translate text between languages',
            'category': 'language',
            'parameters': ['text', 'from_lang', 'to_lang'],
            'safe': True
        },
        'get_weather': {
            'name': 'Weather Information',
            'description': 'Get current weather for a city',
            'category': 'info',
            'parameters': ['city'],
            'safe': True
        },
        'execute_python_code': {
            'name': 'Python Executor',
            'description': 'Execute Python code in sandboxed environment',
            'category': 'developer',
            'parameters': ['code', 'timeout'],
            'safe': False,
            'warning': 'Restricted - only safe operations allowed'
        },
    }
    
    if tool_name in tool_info:
        return tool_info[tool_name]
    
    return {'error': f'Tool "{tool_name}" not found in registry'}


def list_all_tools() -> Dict[str, List[str]]:
    """List all available tools by category.
    
    Returns:
        Dictionary mapping categories to tool lists
    """
    return TOOL_CATEGORIES.copy()


def get_tool_statistics() -> Dict[str, Any]:
    """Get statistics about available tools.
    
    Returns:
        Dictionary with tool statistics
    """
    all_tools = list_all_tools()
    
    return {
        'total_categories': len(all_tools),
        'total_tools': sum(len(tools) for tools in all_tools.values()),
        'categories': all_tools,
        'safe_tools_count': sum(len(tools) for cat, tools in all_tools.items() if cat != 'developer'),
        'potentially_dangerous': ['execute_python_code'],
    }
