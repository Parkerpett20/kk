# tools/filesystem.py
import os
import logging

logger = logging.getLogger(__name__)

WORKSPACE_DIR = "workspace"

def _ensure_workspace():
    try:
        if not os.path.exists(WORKSPACE_DIR):
            os.makedirs(WORKSPACE_DIR)
    except Exception as e:
        logger.error(f"خطا در ایجاد workspace: {e}")

def write_file(filename: str, content: str) -> str:
    """Writes text content to a file inside the workspace directory.
    Args:
        filename: The target filename (e.g., 'summary.txt').
        content: The text content to write.
    """
    _ensure_workspace()
    safe_path = os.path.join(WORKSPACE_DIR, os.path.basename(filename))
    try:
        with open(safe_path, "w", encoding="utf-8") as f:
            f.write(content)
        logger.debug(f"فایل نوشته شد: {safe_path}")
        return f"Successfully wrote to workspace/{os.path.basename(filename)}."
    except IOError as ie:
        logger.error(f"خطای I/O در نوشتن فایل: {ie}")
        return f"Failed to write file: {str(ie)}"
    except Exception as e:
        logger.error(f"خطا در نوشتن فایل: {e}", exc_info=True)
        return f"Failed to write file: {str(e)}"

def read_file(filename: str) -> str:
    """Reads and returns the content of a file inside the workspace directory.
    Args:
        filename: The name of the file to read.
    """
    _ensure_workspace()
    safe_path = os.path.join(WORKSPACE_DIR, os.path.basename(filename))
    if not os.path.exists(safe_path):
        logger.warning(f"فایل پیدا نشد: {safe_path}")
        return f"Error: File 'workspace/{os.path.basename(filename)}' not found."
    try:
        with open(safe_path, "r", encoding="utf-8") as f:
            content = f.read()
        logger.debug(f"فایل خوانده شد: {safe_path}")
        return content
    except IOError as ie:
        logger.error(f"خطای I/O در خواندن فایل: {ie}")
        return f"Failed to read file: {str(ie)}"
    except Exception as e:
        logger.error(f"خطا در خواندن فایل: {e}", exc_info=True)
        return f"Failed to read file: {str(e)}"

def list_files() -> str:
    """Lists all files available in the workspace directory."""
    _ensure_workspace()
    try:
        files = os.listdir(WORKSPACE_DIR)
        if not files:
            return "Workspace is empty."
        return "Workspace files:\n" + "\n".join([f"- {f}" for f in files])
    except Exception as e:
        return f"Failed to list files: {str(e)}"