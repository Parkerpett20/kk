# tests/__init__.py
"""
Test suite for Karen AI Agent
"""

__version__ = "1.0.0"
__author__ = "Karen Development Team"
