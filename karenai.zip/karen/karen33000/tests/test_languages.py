# tests/test_languages.py
import pytest
import os
import json
import tempfile
from memory.user_settings import UserSettings
from core.languages import get_text, get_welcome_message, get_language_keyboard, LANGUAGES

class TestUserSettings:
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.filepath = os.path.join(self.temp_dir, "test_settings.json")
        self.settings = UserSettings(self.filepath)
    
    def teardown_method(self):
        if os.path.exists(self.filepath):
            os.remove(self.filepath)
        os.rmdir(self.temp_dir)
    
    def test_new_user_detection(self):
        assert self.settings.is_new_user(12345) is True
        assert self.settings.get_language(12345) == "fa"
    
    def test_set_language(self):
        self.settings.set_language(12345, "en")
        assert self.settings.get_language(12345) == "en"
        assert self.settings.is_new_user(12345) is False
    
    def test_persistence(self):
        self.settings.set_language(12345, "ar")
        new_settings = UserSettings(self.filepath)
        assert new_settings.get_language(12345) == "ar"
    
    def test_multiple_users(self):
        self.settings.set_language(111, "en")
        self.settings.set_language(222, "ar")
        assert self.settings.get_language(111) == "en"
        assert self.settings.get_language(222) == "ar"
        assert self.settings.get_language(333) == "fa"  # default

class TestLanguages:
    def test_get_text_persian(self):
        text = get_text(12345, "welcome")
        assert "سلام رفیق" in text
    
    def test_get_text_with_kwargs(self):
        text = get_text(12345, "member_count", count=10)
        assert "10" in text
    
    def test_all_languages_have_required_keys(self):
        required_keys = ["welcome", "choose_language", "language_selected", 
                        "clear_memory", "processing", "thinking_deep", 
                        "quick_response", "error"]
        for lang_code, lang_data in LANGUAGES.items():
            for key in required_keys:
                assert key in lang_data, f"Missing key '{key}' in language '{lang_code}'"

class TestLanguageKeyboard:
    def test_keyboard_creation(self):
        markup = get_language_keyboard()
        assert markup is not None
        assert len(markup.keyboard) == len(LANGUAGES)