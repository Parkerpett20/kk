# tests/test_tools.py
"""
Tests for tools modules
"""
import pytest
from unittest.mock import patch, MagicMock


class TestCalculator:
    """Test calculator tool"""
    
    def test_simple_addition(self):
        """Test basic addition"""
        from tools.calculator import calculate_math
        result = calculate_math("2 + 2")
        assert "4" in result
    
    def test_complex_expression(self):
        """Test complex math expression"""
        from tools.calculator import calculate_math
        result = calculate_math("14 * 12 + 5")
        assert "173" in result
    
    def test_division(self):
        """Test division"""
        from tools.calculator import calculate_math
        result = calculate_math("10 / 2")
        assert "5" in result
    
    def test_division_by_zero(self):
        """Test division by zero handling"""
        from tools.calculator import calculate_math
        result = calculate_math("10 / 0")
        assert "Error" in result or "division" in result.lower()
    
    def test_unsafe_characters_rejected(self):
        """Test that unsafe characters are rejected"""
        from tools.calculator import calculate_math
        result = calculate_math("import os; os.system('ls')")
        assert "Error" in result or "unsafe" in result.lower()
    
    def test_empty_expression(self):
        """Test empty expression handling"""
        from tools.calculator import calculate_math
        result = calculate_math("")
        assert "Error" in result or "Empty" in result
    
    def test_syntax_error(self):
        """Test syntax error handling"""
        from tools.calculator import calculate_math
        result = calculate_math("2 +")
        assert "Error" in result or "Syntax" in result or "failed" in result.lower()


class TestFileSystem:
    """Test filesystem tool"""
    
    def test_write_and_read_file(self, temp_data_dir):
        """Test writing and reading files"""
        import os
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_data_dir)
            from tools.filesystem import write_file, read_file
            
            # Write file
            result = write_file("test.txt", "Hello World")
            assert "Successfully wrote" in result
            
            # Read file
            content = read_file("test.txt")
            assert "Hello World" in content
        finally:
            os.chdir(original_cwd)
    
    def test_list_files(self, temp_data_dir):
        """Test listing files"""
        import os
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_data_dir)
            from tools.filesystem import write_file, list_files
            
            write_file("file1.txt", "content1")
            write_file("file2.txt", "content2")
            
            result = list_files()
            assert "file1.txt" in result
            assert "file2.txt" in result
        finally:
            os.chdir(original_cwd)
    
    def test_read_nonexistent_file(self, temp_data_dir):
        """Test reading non-existent file"""
        import os
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_data_dir)
            from tools.filesystem import read_file
            
            result = read_file("nonexistent.txt")
            assert "not found" in result.lower() or "error" in result.lower()
        finally:
            os.chdir(original_cwd)


class TestWeather:
    """Test weather tool"""
    
    def test_normalize_city_name_english(self):
        """Test city name normalization with English names"""
        from tools.weather import _normalize_city_name
        assert _normalize_city_name("Tehran") == "Tehran"
        assert _normalize_city_name("  London  ") == "London"
    
    def test_normalize_city_name_persian(self):
        """Test city name normalization with Persian names"""
        from tools.weather import _normalize_city_name
        assert _normalize_city_name("تهران") == "Tehran"
        assert _normalize_city_name("شیراز") == "Shiraz"
    
    def test_validate_city_name_valid(self):
        """Test city name validation with valid names"""
        from tools.weather import _validate_city_name
        assert _validate_city_name("Tehran") == True
        assert _validate_city_name("New York") == True
    
    def test_validate_city_name_invalid(self):
        """Test city name validation with invalid names"""
        from tools.weather import _validate_city_name
        assert _validate_city_name("") == False
        assert _validate_city_name("A") == False
        assert _validate_city_name(None) == False
        assert _validate_city_name("a" * 101) == False
    
    def test_get_weather_invalid_city(self):
        """Test weather retrieval with invalid city"""
        from tools.weather import get_weather
        result = get_weather("")
        assert "Invalid" in result or "❌" in result
    
    def test_get_weather_fallback(self):
        """Test weather with fallback"""
        from tools.weather import get_weather
        result = get_weather("TestCity")
        assert isinstance(result, str)
        assert len(result) > 0
    
    def test_get_weather_description(self):
        """Test weather code to description conversion"""
        from tools.weather import _get_weather_description
        desc0 = _get_weather_description(0)
        desc1 = _get_weather_description(1)
        desc45 = _get_weather_description(45)
        
        assert "Clear" in desc0 or "صاف" in desc0
        assert isinstance(desc1, str)
        assert isinstance(desc45, str)
    
    def test_get_weather_forecast_invalid_days(self):
        """Test forecast with invalid number of days"""
        from tools.weather import get_weather_forecast
        result = get_weather_forecast("Tehran", days=10)
        assert "between 1 and 7" in result or "❌" in result
    
    def test_get_weather_forecast_valid(self):
        """Test forecast with valid input"""
        from tools.weather import get_weather_forecast
        result = get_weather_forecast("Tehran", days=3)
        assert isinstance(result, str)
        assert "Tehran" in result or "forecast" in result.lower()
    
    def test_get_air_quality_invalid_city(self):
        """Test air quality with invalid city"""
        from tools.weather import get_air_quality
        result = get_air_quality("")
        assert "Invalid" in result or "❌" in result
    
    def test_get_air_quality_valid(self):
        """Test air quality with valid city"""
        from tools.weather import get_air_quality
        result = get_air_quality("Tehran")
        assert isinstance(result, str)
        assert "Air Quality" in result or "AQI" in result



    """Test GitHub tool"""
    
    def test_validate_github_params_valid(self):
        """Test parameter validation with valid inputs"""
        from tools.github import _validate_github_params
        assert _validate_github_params("torvalds", "linux") == True
        assert _validate_github_params("github", "github.com") == True
    
    def test_validate_github_params_invalid(self):
        """Test parameter validation with invalid inputs"""
        from tools.github import _validate_github_params
        assert _validate_github_params("", "repo") == False
        assert _validate_github_params("owner", "") == False
        assert _validate_github_params(None, "repo") == False
        assert _validate_github_params("owner@invalid", "repo") == False
    
    def test_get_repo_info_invalid_params(self):
        """Test repo info with invalid parameters"""
        from tools.github import get_repo_info
        result = get_repo_info("", "repo")
        assert "Invalid" in result or "❌" in result
    
    def test_search_repositories_invalid_query(self):
        """Test repository search with invalid query"""
        from tools.github import search_repositories
        result = search_repositories("")
        assert "Invalid" in result or "❌" in result
        
        result = search_repositories("a")
        assert "at least 2" in result or "❌" in result
    
    def test_get_user_info_invalid_username(self):
        """Test user info with invalid username"""
        from tools.github import get_user_info
        result = get_user_info("")
        assert "Invalid" in result or "❌" in result
    
    @patch('urllib.request.urlopen')
    def test_get_repo_info_success(self, mock_urlopen):
        """Test successful repo info retrieval"""
        from tools.github import get_repo_info
        
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            'full_name': 'test/repo',
            'description': 'Test repo',
            'stargazers_count': 100,
            'forks_count': 10,
            'language': 'Python',
            'watchers_count': 50,
            'updated_at': '2024-01-01',
            'html_url': 'https://github.com/test/repo'
        }).encode('utf-8')
        mock_urlopen.return_value.__enter__.return_value = mock_response
        
        result = get_repo_info("test", "repo")
        assert isinstance(result, str)
        assert "📦" in result or "Repository" in result



    """Test Python code executor"""
    
    def test_validate_code_valid(self):
        """Test code validation with valid code"""
        from tools.python_executor import _validate_code
        is_valid, msg = _validate_code("print(2 + 2)")
        assert is_valid == True
        assert msg == ""
    
    def test_validate_code_invalid_syntax(self):
        """Test code validation with invalid syntax"""
        from tools.python_executor import _validate_code
        is_valid, msg = _validate_code("print(2 +")
        assert is_valid == False
        assert "Syntax" in msg
    
    def test_validate_code_restricted_keyword(self):
        """Test code validation with restricted keyword"""
        from tools.python_executor import _validate_code
        is_valid, msg = _validate_code("import os")
        assert is_valid == False
        assert "restricted" in msg.lower() or "import" in msg.lower()
    
    def test_validate_code_empty(self):
        """Test code validation with empty input"""
        from tools.python_executor import _validate_code
        is_valid, msg = _validate_code("")
        assert is_valid == False
    
    def test_validate_code_too_long(self):
        """Test code validation with excessively long code"""
        from tools.python_executor import _validate_code
        is_valid, msg = _validate_code("print('x')" * 2000)
        assert is_valid == False
        assert "exceeds" in msg.lower()
    
    def test_execute_python_simple_math(self):
        """Test executing simple math code"""
        from tools.python_executor import execute_python_code
        result = execute_python_code("print(2 + 2)")
        assert "4" in result
    
    def test_execute_python_restricted_import(self):
        """Test executing code with restricted import"""
        from tools.python_executor import execute_python_code
        result = execute_python_code("import os; print(os.name)")
        assert "❌" in result or "restricted" in result.lower()
    
    def test_execute_python_no_output(self):
        """Test executing code with no output"""
        from tools.python_executor import execute_python_code
        result = execute_python_code("x = 5")
        assert "Success" in result or "No output" in result or "✅" in result
    
    def test_validate_python_syntax_valid(self):
        """Test syntax validation with valid code"""
        from tools.python_executor import validate_python_syntax
        result = validate_python_syntax("print('hello')")
        assert result["valid"] == True
        assert result["error"] is None
    
    def test_validate_python_syntax_invalid(self):
        """Test syntax validation with invalid code"""
        from tools.python_executor import validate_python_syntax
        result = validate_python_syntax("print('hello'")
        assert result["valid"] == False
        assert result["error"] is not None
    
    def test_get_allowed_builtins(self):
        """Test getting allowed built-in functions"""
        from tools.python_executor import get_allowed_builtins
        builtins = get_allowed_builtins()
        assert isinstance(builtins, list)
        assert "print" in builtins
        assert "len" in builtins
    
    def test_get_restricted_items(self):
        """Test getting restricted items info"""
        from tools.python_executor import get_restricted_items
        info = get_restricted_items()
        assert isinstance(info, dict)
        assert "restricted_keywords" in info
        assert "allowed_builtins" in info



    """Test image generation tool"""
    
    def test_validate_prompt_valid(self):
        """Test prompt validation with valid input"""
        from tools.image_generation import _validate_prompt
        assert _validate_prompt("A beautiful sunset over mountains") == True
        assert _validate_prompt("Professional portrait photography") == True
    
    def test_validate_prompt_invalid(self):
        """Test prompt validation with invalid input"""
        from tools.image_generation import _validate_prompt
        assert _validate_prompt("") == False
        assert _validate_prompt("short") == False  # Too short
        assert _validate_prompt("a" * 501) == False  # Too long
        assert _validate_prompt(None) == False
    
    def test_validate_url_valid(self):
        """Test URL validation with valid URLs"""
        from tools.image_generation import _validate_url
        assert _validate_url("https://example.com/image.jpg") == True
        assert _validate_url("http://example.com/image.png") == True
    
    def test_validate_url_invalid(self):
        """Test URL validation with invalid URLs"""
        from tools.image_generation import _validate_url
        assert _validate_url("not_a_url") == False
        assert _validate_url("ftp://example.com") == False
        assert _validate_url("") == False
    
    def test_generate_image_url_valid_prompt(self):
        """Test image generation with valid prompt"""
        from tools.image_generation import generate_image_url
        result = generate_image_url("A serene mountain landscape at sunset")
        assert isinstance(result, str)
        assert len(result) > 0
    
    def test_generate_image_url_short_prompt(self):
        """Test image generation with prompt too short"""
        from tools.image_generation import generate_image_url
        result = generate_image_url("short")
        assert "too short" in result.lower() or "❌" in result
    
    def test_generate_image_url_long_prompt(self):
        """Test image generation with prompt too long"""
        from tools.image_generation import generate_image_url
        result = generate_image_url("a" * 501)
        assert "too long" in result.lower() or "❌" in result
    
    def test_generate_image_url_custom_dimensions(self):
        """Test image generation with custom dimensions"""
        from tools.image_generation import generate_image_url
        result = generate_image_url("A valid prompt", width=512, height=512)
        assert isinstance(result, str)
    
    def test_generate_image_url_invalid_dimensions(self):
        """Test image generation with invalid dimensions"""
        from tools.image_generation import generate_image_url
        result = generate_image_url("A valid prompt", width=100, height=100)
        assert "❌" in result or "between" in result.lower()
    
    def test_generate_image_batch_invalid_input(self):
        """Test batch generation with invalid input"""
        from tools.image_generation import generate_image_batch
        result = generate_image_batch("not_a_list")
        assert "failed" in result
    
    def test_generate_image_batch_too_large(self):
        """Test batch generation with too many prompts"""
        from tools.image_generation import generate_image_batch
        large_list = ["A valid prompt"] * 15
        result = generate_image_batch(large_list)
        assert "failed" in result or len(result.get("successful", [])) < 15
    
    def test_estimate_generation_time(self):
        """Test generation time estimation"""
        from tools.image_generation import estimate_generation_time
        time1 = estimate_generation_time(30)
        time2 = estimate_generation_time(100)
        time3 = estimate_generation_time(200)
        assert isinstance(time1, str)
        assert isinstance(time2, str)
        assert isinstance(time3, str)



    """Test vision tool"""
    
    def test_validate_prompt_valid(self):
        """Test prompt validation with valid input"""
        from tools.vision import _validate_prompt
        assert _validate_prompt("What is this?") == True
        assert _validate_prompt("Describe the image in detail") == True
    
    def test_validate_prompt_invalid(self):
        """Test prompt validation with invalid input"""
        from tools.vision import _validate_prompt
        assert _validate_prompt("") == False
        assert _validate_prompt("   ") == False
        assert _validate_prompt(None) == False
        # Very long prompt
        assert _validate_prompt("a" * 2001) == False
    
    def test_get_mime_type_jpeg(self):
        """Test MIME type detection for JPEG"""
        from tools.vision import _get_mime_type
        assert _get_mime_type("image.jpg") == "image/jpeg"
        assert _get_mime_type("image.jpeg") == "image/jpeg"
    
    def test_get_mime_type_png(self):
        """Test MIME type detection for PNG"""
        from tools.vision import _get_mime_type
        assert _get_mime_type("image.png") == "image/png"
    
    def test_analyze_image_file_not_found(self):
        """Test analyzing non-existent image"""
        from tools.vision import analyze_image_file
        result = analyze_image_file("nonexistent.jpg")
        assert "not found" in result.lower() or "❌" in result
    
    def test_analyze_image_file_invalid_prompt(self):
        """Test analyzing with invalid prompt"""
        from tools.vision import analyze_image_file
        result = analyze_image_file("test.jpg", prompt="")
        assert "Invalid" in result or "❌" in result
    
    def test_analyze_image_url_invalid_url(self):
        """Test analyzing image from invalid URL"""
        from tools.vision import analyze_image_url
        result = analyze_image_url("not_a_url")
        assert "Invalid" in result or "URL" in result or "❌" in result
    
    def test_get_supported_formats(self):
        """Test getting supported image formats"""
        from tools.vision import get_supported_formats
        formats = get_supported_formats()
        assert isinstance(formats, dict)
        assert ".jpg" in formats
        assert ".png" in formats



    """Test speech tool"""
    
    def test_validate_text_input_valid(self):
        """Test text validation with valid input"""
        from tools.speech import _validate_text_input
        assert _validate_text_input("hello") == True
        assert _validate_text_input("سلام") == True
    
    def test_validate_text_input_invalid(self):
        """Test text validation with invalid input"""
        from tools.speech import _validate_text_input
        assert _validate_text_input("") == False
        assert _validate_text_input("   ") == False
        assert _validate_text_input(None) == False
    
    def test_validate_filename_valid(self):
        """Test filename validation with valid filenames"""
        from tools.speech import _validate_filename
        assert _validate_filename("output.mp3") == True
        assert _validate_filename("greeting.wav") == True
        assert _validate_filename("voice.ogg") == True
    
    def test_validate_filename_invalid(self):
        """Test filename validation with invalid filenames"""
        from tools.speech import _validate_filename
        assert _validate_filename("") == False
        assert _validate_filename("file/with/slashes.mp3") == False
        assert _validate_filename("file:with:colons.mp3") == False
        assert _validate_filename("output.txt") == False
        assert _validate_filename("output.exe") == False
    
    def test_speak_text_invalid_text(self):
        """Test speak_text with invalid text"""
        from tools.speech import speak_text
        result = speak_text("", filename="output.mp3")
        assert "Invalid" in result or "❌" in result
    
    def test_speak_text_invalid_filename(self):
        """Test speak_text with invalid filename"""
        from tools.speech import speak_text
        result = speak_text("hello", filename="output.txt")
        assert "Invalid" in result or "❌" in result
    
    def test_speak_text_unsupported_language(self):
        """Test speak_text with unsupported language"""
        from tools.speech import speak_text
        result = speak_text("hello", filename="output.mp3", language="invalid_lang")
        assert "Unsupported" in result or "❌" in result
    
    def test_get_supported_languages(self):
        """Test getting supported languages"""
        from tools.speech import get_supported_languages
        langs = get_supported_languages()
        assert isinstance(langs, dict)
        assert "fa" in langs
        assert "en" in langs
    
    def test_list_generated_speeches_empty(self):
        """Test listing speeches when workspace doesn't exist or is empty"""
        from tools.speech import list_generated_speeches
        speeches = list_generated_speeches()
        assert isinstance(speeches, list)



    """Test translation tool"""
    
    def test_validate_language_code_valid(self):
        """Test language code validation with valid codes"""
        from tools.translate import _validate_language_code
        assert _validate_language_code("en") == True
        assert _validate_language_code("fa") == True
        assert _validate_language_code("pt-BR") == True
    
    def test_validate_language_code_invalid(self):
        """Test language code validation with invalid codes"""
        from tools.translate import _validate_language_code
        assert _validate_language_code("") == False
        assert _validate_language_code("tool-long-code") == False
        assert _validate_language_code("123") == True  # Numbers are allowed
    
    def test_validate_text_input_valid(self):
        """Test text input validation with valid input"""
        from tools.translate import _validate_text_input
        assert _validate_text_input("hello") == True
        assert _validate_text_input("سلام دنیا") == True
    
    def test_validate_text_input_invalid(self):
        """Test text input validation with invalid input"""
        from tools.translate import _validate_text_input
        assert _validate_text_input("") == False
        assert _validate_text_input("   ") == False
        assert _validate_text_input(None) == False
        # Very long text
        assert _validate_text_input("a" * 5001) == False
    
    def test_translate_same_language(self):
        """Test translation with same source and target language"""
        from tools.translate import translate
        result = translate("hello", from_lang="en", to_lang="en")
        assert "same" in result.lower() or "⚠️" in result
    
    def test_translate_invalid_language_code(self):
        """Test translation with invalid language code"""
        from tools.translate import translate
        result = translate("hello", from_lang="invalid_code", to_lang="en")
        assert "Invalid" in result or "❌" in result
    
    def test_translate_empty_text(self):
        """Test translation with empty text"""
        from tools.translate import translate
        result = translate("", from_lang="en", to_lang="fa")
        assert "Invalid" in result or "❌" in result
    
    def test_get_supported_languages(self):
        """Test getting supported languages"""
        from tools.translate import get_supported_languages
        langs = get_supported_languages()
        assert isinstance(langs, dict)
        assert "en" in langs
        assert "fa" in langs
    
    def test_batch_translate_invalid_input(self):
        """Test batch translation with invalid input"""
        from tools.translate import batch_translate
        result = batch_translate("not_a_list")
        assert "failed" in result
    
    def test_batch_translate_too_large(self):
        """Test batch translation with too many items"""
        from tools.translate import batch_translate
        large_list = ["text"] * 25
        result = batch_translate(large_list)
        assert "failed" in result or len(result.get("successful", [])) < 25



    """Test search tool"""
    
    def test_get_search_tool(self):
        """Test search tool initialization"""
        from tools.search import get_search_tool
        tool = get_search_tool()
        assert tool is not None
        # Check both possible attribute names (depends on Google SDK version)
        assert hasattr(tool, 'google_search') or hasattr(tool, 'googleSearch')
    
    def test_get_search_tool_structure(self):
        """Test search tool has correct structure"""
        from tools.search import get_search_tool
        tool = get_search_tool()
        # Tool should be a types.Tool object with googleSearch attribute
        assert tool is not None
    
    def test_create_search_enabled_model_with_mock_client(self, mock_gemini_client):
        """Test creating model with search enabled"""
        from tools.search import create_search_enabled_model
        
        # This should not raise even with mock
        model = create_search_enabled_model(mock_gemini_client)
        # With mock, should still return something or handle gracefully
        assert model is None or model is not None  # Accept either result with mock
    
    def test_perform_web_search_invalid_query(self):
        """Test web search with invalid query"""
        from tools.search import perform_web_search
        
        result = perform_web_search("")
        assert "Invalid" in result or "Error" in result
        
        result = perform_web_search(None)
        assert "Invalid" in result or "Error" in result



    """Test browser tool"""
    
    def test_is_valid_url_valid(self):
        """Test URL validation with valid URLs"""
        from tools.browser import _is_valid_url
        assert _is_valid_url("https://example.com") == True
        assert _is_valid_url("http://example.com") == True
    
    def test_is_valid_url_invalid(self):
        """Test URL validation with invalid URLs"""
        from tools.browser import _is_valid_url
        assert _is_valid_url("invalid") == False
        assert _is_valid_url("") == False
        assert _is_valid_url(None) == False
        assert _is_valid_url("ftp://example.com") == False
    
    def test_browse_url_invalid_url(self):
        """Test browsing invalid URL"""
        from tools.browser import browse_url
        result = browse_url("invalid_url")
        assert "Invalid" in result or "Error" in result or "❌" in result
    
    def test_extract_text_from_html(self):
        """Test HTML text extraction"""
        from tools.browser import _extract_text_from_html
        
        html = "<html><body><p>Hello World</p><script>alert('hi')</script></body></html>"
        result = _extract_text_from_html(html)
        assert "Hello World" in result
        assert "alert" not in result
    
    @patch('urllib.request.urlopen')
    def test_browse_url_successful(self, mock_urlopen):
        """Test successful URL browsing"""
        from tools.browser import browse_url
        
        mock_response = MagicMock()
        mock_response.read.return_value = b"<html><body><p>Test content</p></body></html>"
        mock_response.headers.get.return_value = "text/html"
        mock_urlopen.return_value.__enter__.return_value = mock_response
        
        result = browse_url("https://example.com")
        assert isinstance(result, str)
    
    def test_get_page_title_invalid_url(self):
        """Test getting page title with invalid URL"""
        from tools.browser import get_page_title
        result = get_page_title("invalid")
        assert "Invalid" in result or "Error" in result



    """Test YouTube tool"""
    
    def test_validate_query_valid(self):
        """Test query validation with valid input"""
        from tools.youtube import _validate_query
        assert _validate_query("python tutorials") == True
    
    def test_validate_query_empty(self):
        """Test query validation with empty input"""
        from tools.youtube import _validate_query
        assert _validate_query("") == False
    
    def test_validate_query_too_short(self):
        """Test query validation with too short input"""
        from tools.youtube import _validate_query
        assert _validate_query("a") == False
    
    def test_validate_query_invalid_type(self):
        """Test query validation with invalid type"""
        from tools.youtube import _validate_query
        assert _validate_query(None) == False
        assert _validate_query(123) == False
    
    def test_search_youtube_invalid_query(self):
        """Test YouTube search with invalid query"""
        from tools.youtube import search_youtube
        result = search_youtube("")
        assert "Error" in result or "invalid" in result.lower()
    
    @patch('urllib.request.urlopen')
    def test_search_youtube_successful(self, mock_urlopen):
        """Test successful YouTube search"""
        from tools.youtube import search_youtube
        
        mock_response = MagicMock()
        mock_response.read.return_value = b'''
        {"videoId":"dQw4w9WgXcQ","title":{"runs":[{"text":"Test Video"}]}}
        '''
        mock_urlopen.return_value.__enter__.return_value = mock_response
        
        result = search_youtube("test query")
        # Result should either have videos or indicate none found
        assert isinstance(result, str)
    
    def test_get_youtube_video_info_invalid_id(self):
        """Test getting video info with invalid ID"""
        from tools.youtube import get_youtube_video_info
        result = get_youtube_video_info("invalid")
        assert "Error" in result or "Invalid" in result
    
    def test_get_youtube_video_info_valid_format(self):
        """Test video ID validation with correct format"""
        from tools.youtube import _validate_query
        # 11 character valid ID format
        valid_id = "dQw4w9WgXcQ"
        assert len(valid_id) == 11


