# tests/test_office.py
"""Tests for office document tools (OfficeCLI integration)"""
import os
import json
import pytest
from unittest.mock import patch, MagicMock


class TestOfficeValidation:
    """Test office tool validation functions"""

    def test_validate_filename_valid(self):
        from tools.office import _validate_filename
        assert _validate_filename("report.docx") == True
        assert _validate_filename("data.xlsx") == True
        assert _validate_filename("slides.pptx") == True

    def test_validate_filename_invalid(self):
        from tools.office import _validate_filename
        assert _validate_filename("") == False
        assert _validate_filename("file.txt") == False
        assert _validate_filename(None) == False

    def test_safe_filename(self):
        from tools.office import _safe_filename
        assert _safe_filename("report.docx") == "report.docx"
        assert _safe_filename("../../etc/passwd") == "passwd"

    def test_normalize_format(self):
        from tools.office import _normalize_format
        assert _normalize_format("docx") == ".docx"
        assert _normalize_format("word") == ".docx"
        assert _normalize_format("xlsx") == ".xlsx"
        assert _normalize_format("excel") == ".xlsx"
        assert _normalize_format("pptx") == ".pptx"
        assert _normalize_format("ppt") == ".pptx"

    def test_parse_props_string(self):
        from tools.office import _parse_props
        result = _parse_props("text=Hello,bold=true")
        assert result == ["--prop", "text=Hello", "--prop", "bold=true"]

    def test_parse_props_none(self):
        from tools.office import _parse_props
        assert _parse_props(None) == []
        assert _parse_props("") == []


class TestOfficeCreate:
    """Test office document creation"""

    def test_create_invalid_filename(self):
        from tools.office import create_office_document
        result = create_office_document("file.txt")
        assert "Invalid" in result or "❌" in result

    @patch('tools.office._run_officecli')
    def test_create_success(self, mock_run):
        from tools.office import create_office_document
        mock_run.return_value = "Created"
        result = create_office_document("unique_test_create.docx")
        assert "✅" in result
        assert "unique_test_create.docx" in result


class TestOfficeView:
    """Test office document viewing"""

    def test_view_invalid_filename(self):
        from tools.office import view_office_document
        result = view_office_document("file.txt")
        assert "Invalid" in result or "❌" in result

    def test_view_invalid_mode(self):
        from tools.office import view_office_document
        result = view_office_document("test.docx", mode="invalid_mode")
        assert "Invalid mode" in result or "❌" in result

    def test_view_file_not_found(self):
        from tools.office import view_office_document
        result = view_office_document("nonexistent.docx")
        assert "not found" in result.lower() or "❌" in result


class TestOfficeGet:
    """Test office content retrieval"""

    def test_get_invalid_filename(self):
        from tools.office import get_office_content
        result = get_office_content("file.txt")
        assert "Invalid" in result or "❌" in result

    def test_get_file_not_found(self):
        from tools.office import get_office_content
        result = get_office_content("nonexistent.docx")
        assert "not found" in result.lower() or "❌" in result


class TestOfficeQuery:
    """Test office document querying"""

    def test_query_invalid_filename(self):
        from tools.office import query_office_document
        result = query_office_document("file.txt", "paragraph")
        assert "Invalid" in result or "❌" in result

    def test_query_empty_selector(self):
        from tools.office import query_office_document
        result = query_office_document("test.docx", "")
        assert "Selector" in result or "❌" in result


class TestOfficeAdd:
    """Test office element addition"""

    def test_add_invalid_filename(self):
        from tools.office import add_office_element
        result = add_office_element("file.txt", "/body", "paragraph")
        assert "Invalid" in result or "❌" in result

    def test_add_empty_element_type(self):
        from tools.office import add_office_element
        result = add_office_element("test.docx", "/body", "")
        assert "Element type" in result or "❌" in result

    def test_add_file_not_found(self):
        from tools.office import add_office_element
        result = add_office_element("nonexistent.docx", "/body", "paragraph")
        assert "not found" in result.lower() or "❌" in result


class TestOfficeSet:
    """Test office property setting"""

    def test_set_invalid_filename(self):
        from tools.office import set_office_property
        result = set_office_property("file.txt", "/body/p[1]", "bold=true")
        assert "Invalid" in result or "❌" in result

    def test_set_empty_props(self):
        from tools.office import set_office_property
        result = set_office_property("test.docx", "/body/p[1]", None)
        assert "Properties" in result or "❌" in result


class TestOfficeRemove:
    """Test office element removal"""

    def test_remove_invalid_filename(self):
        from tools.office import remove_office_element
        result = remove_office_element("file.txt", "/body/p[1]")
        assert "Invalid" in result or "❌" in result

    def test_remove_empty_path(self):
        from tools.office import remove_office_element
        result = remove_office_element("test.docx", "")
        assert "Path" in result or "❌" in result


class TestTextToWord:
    """Test text to Word conversion"""

    def test_empty_text(self):
        from tools.office import text_to_word_document
        result = text_to_word_document("")
        assert "Text content" in result or "❌" in result

    def test_invalid_filename(self):
        from tools.office import text_to_word_document
        result = text_to_word_document("Hello", "file.txt")
        assert "Invalid" in result or "❌" in result

    @patch('tools.office._run_officecli')
    def test_success(self, mock_run):
        from tools.office import text_to_word_document
        mock_run.return_value = "OK"
        result = text_to_word_document("Hello World", "unique_test_word.docx")
        assert "✅" in result
        assert "unique_test_word.docx" in result


class TestTextToPowerPoint:
    """Test text to PowerPoint conversion"""

    def test_empty_text(self):
        from tools.office import text_to_powerpoint
        result = text_to_powerpoint("")
        assert "Text content" in result or "❌" in result

    def test_invalid_filename(self):
        from tools.office import text_to_powerpoint
        result = text_to_powerpoint("Hello", "file.txt")
        assert "Invalid" in result or "❌" in result

    @patch('tools.office._run_officecli')
    def test_success(self, mock_run):
        from tools.office import text_to_powerpoint
        mock_run.return_value = "OK"
        result = text_to_powerpoint("## Slide 1\nContent", "unique_test_ppt.pptx")
        assert "✅" in result
        assert "unique_test_ppt.pptx" in result


class TestDataToExcel:
    """Test data to Excel conversion"""

    def test_invalid_filename(self):
        from tools.office import data_to_excel
        result = data_to_excel([["A", "B"]], "file.txt")
        assert "Invalid" in result or "❌" in result

    def test_invalid_data(self):
        from tools.office import data_to_excel
        result = data_to_excel("not json", "test.xlsx")
        assert "Invalid" in result or "❌" in result

    def test_empty_data(self):
        from tools.office import data_to_excel
        result = data_to_excel([], "test.xlsx")
        assert "Data must" in result or "❌" in result

    @patch('tools.office._run_officecli')
    def test_success_list(self, mock_run):
        from tools.office import data_to_excel
        mock_run.return_value = "OK"
        result = data_to_excel('[["Name", "Score"], ["Alice", 95]]', "unique_test_list.xlsx")
        assert "✅" in result
        assert "unique_test_list.xlsx" in result

    @patch('tools.office._run_officecli')
    def test_success_dict(self, mock_run):
        from tools.office import data_to_excel
        mock_run.return_value = "OK"
        result = data_to_excel('{"Name": ["Alice"], "Score": [95]}', "unique_test_dict.xlsx")
        assert "✅" in result
        assert "unique_test_dict.xlsx" in result


class TestOfficeHelp:
    """Test office help"""

    @patch('tools.office._run_officecli')
    def test_get_help(self, mock_run):
        from tools.office import get_office_help
        mock_run.return_value = "Help text"
        result = get_office_help("docx paragraph")
        assert result == "Help text"

    @patch('tools.office._run_officecli')
    def test_get_help_no_topic(self, mock_run):
        from tools.office import get_office_help
        mock_run.return_value = "All help"
        result = get_office_help()
        assert result == "All help"


class TestOfficeCLIVersion:
    """Test officecli version"""

    @patch('tools.office._run_officecli')
    def test_version(self, mock_run):
        from tools.office import officecli_version
        mock_run.return_value = "1.0.143"
        result = officecli_version()
        assert result == "1.0.143"


class TestRouterOffice:
    """Test router office intent detection"""

    def test_router_detects_word_request(self):
        from core.router import IntentRouter
        plan = IntentRouter.route("یه متن رو به فایل ورد تبدیل کن")
        assert plan["office"] is True

    def test_router_detects_excel_request(self):
        from core.router import IntentRouter
        plan = IntentRouter.route("یه جدول اکسل بساز")
        assert plan["office"] is True

    def test_router_detects_powerpoint_request(self):
        from core.router import IntentRouter
        plan = IntentRouter.route("یه پاورپوینت برای ارائه بساز")
        assert plan["office"] is True

    def test_router_detects_english_word_request(self):
        from core.router import IntentRouter
        plan = IntentRouter.route("convert this text to a word document")
        assert plan["office"] is True

    def test_router_default_no_office(self):
        from core.router import IntentRouter
        plan = IntentRouter.route("سلام چطوری؟")
        assert plan["office"] is False