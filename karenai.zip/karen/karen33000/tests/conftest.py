# tests/conftest.py
"""
Pytest configuration and fixtures
"""
import os
import sys
import pytest
import json
import builtins
import tempfile
from unittest.mock import Mock, patch, MagicMock

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


@pytest.fixture
def temp_data_dir():
    """Create temporary data directory for tests"""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def mock_env(monkeypatch):
    """Mock environment variables"""
    test_env = {
        "TELEGRAM_BOT_TOKEN": "test_token_123",
        "GEMINI_API_KEY": "test_api_key_456",
        "PROXY": None
    }
    for key, value in test_env.items():
        if value:
            monkeypatch.setenv(key, value)
    # Return a dict suitable for patch.dict in tests: exclude None values
    return {k: v for k, v in test_env.items() if v is not None}


# Ensure `json` is available in test modules that reference it without importing
builtins.json = json


@pytest.fixture
def mock_gemini_client():
    """Mock Google Gemini client"""
    with patch('google.genai.Client') as mock_client:
        mock_instance = MagicMock()
        mock_client.return_value = mock_instance
        yield mock_instance


@pytest.fixture
def sample_user_message():
    """Sample user message for testing"""
    return {
        "chat_id": 12345,
        "text": "What's the weather like?",
        "user_id": 67890,
        "username": "test_user"
    }


@pytest.fixture
def sample_embeddings():
    """Sample embeddings for testing"""
    return {
        "text": "Hello world",
        "vector": [0.1, 0.2, 0.3, 0.4, 0.5] * 256  # 1280-dim vector
    }


@pytest.fixture
def clean_json_file(temp_data_dir):
    """Create clean JSON file for testing"""
    test_file = os.path.join(temp_data_dir, "test.json")
    data = {
        "chat_id": "123",
        "messages": [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello!"}
        ]
    }
    with open(test_file, 'w') as f:
        json.dump(data, f)
    return test_file


@pytest.fixture(autouse=True)
def reset_modules():
    """Reset imported modules between tests"""
    yield
    # Cleanup after each test
    modules_to_remove = [m for m in sys.modules.keys() if m.startswith('memory.') or m.startswith('tools.')]
    for module in modules_to_remove:
        sys.modules.pop(module, None)
