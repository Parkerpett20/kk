# tests/README.md
# Karen AI Agent - Test Suite

## Overview

Comprehensive test suite for the Karen AI Agent project using pytest.

## Structure

```
tests/
├── __init__.py              # Test package initialization
├── conftest.py              # Pytest configuration and fixtures
├── test_config.py           # Configuration tests
├── test_memory.py           # Memory module tests (long, short, vector, profile)
├── test_tools.py            # Tool tests (calculator, filesystem, registry)
├── test_plugins.py          # Plugin tests (todo, notes, calendar, weather)
├── test_utils.py            # Utility tests (logger)
├── test_integration.py      # Integration tests
└── README.md                # This file
```

## Running Tests

### Run all tests
```bash
pytest
```

### Run specific test file
```bash
pytest tests/test_memory.py
```

### Run specific test class
```bash
pytest tests/test_memory.py::TestLongMemory
```

### Run specific test function
```bash
pytest tests/test_memory.py::TestLongMemory::test_save_and_get_facts
```

### Run with coverage report
```bash
pytest --cov=. --cov-report=html
```

### Run tests with verbose output
```bash
pytest -v
```

### Run tests and stop on first failure
```bash
pytest -x
```

### Run tests in parallel (requires pytest-xdist)
```bash
pytest -n auto
```

## Test Coverage

Current test coverage includes:

### Core Modules
- ✅ Configuration loading and validation
- ✅ Logging setup and handlers

### Memory Modules
- ✅ LongMemory: Save, retrieve, persistence
- ✅ ShortMemory: Session management, history
- ✅ VectorMemory: Vector storage, similarity search
- ✅ UserProfile: Profile extraction and management

### Tools
- ✅ Calculator: Mathematical operations, error handling
- ✅ Filesystem: File read/write/list operations
- ✅ Registry: Tool registration

### Plugins
- ✅ TODO: Add, list, complete tasks
- ✅ Notes: Save, read notes
- ✅ Calendar: Gregorian calendar
- ✅ Weather: Weather queries

### Integration
- ✅ Memory integration workflows
- ✅ Tool integration workflows
- ✅ Plugin integration workflows

## Fixtures

Common fixtures available in `conftest.py`:

- `temp_data_dir`: Temporary directory for test data
- `mock_env`: Mock environment variables
- `mock_gemini_client`: Mock Google Gemini client
- `sample_user_message`: Sample user message data
- `sample_embeddings`: Sample embedding vectors
- `clean_json_file`: Clean JSON file for testing

## Best Practices

1. **Isolation**: Each test should be independent
2. **Mocking**: Use mocks for external dependencies
3. **Temporary Files**: Use `temp_data_dir` fixture for file operations
4. **Assertions**: Use clear, specific assertions
5. **Naming**: Test names should describe what they test

## Adding New Tests

When adding new tests:

1. Create test file matching pattern: `test_<module>.py`
2. Create test classes prefixed with `Test`
3. Create test methods prefixed with `test_`
4. Use meaningful test names describing the behavior
5. Use appropriate fixtures from `conftest.py`
6. Add docstrings to tests

Example:
```python
class TestNewFeature:
    """Test new feature"""
    
    def test_feature_behavior(self, mock_env):
        """Test that feature behaves correctly"""
        # Arrange
        expected = "value"
        
        # Act
        result = new_feature()
        
        # Assert
        assert result == expected
```

## Continuous Integration

These tests can be integrated with CI/CD pipelines:

```yaml
# GitHub Actions example
- name: Run tests
  run: pytest --cov --cov-report=xml

- name: Upload coverage
  uses: codecov/codecov-action@v3
```

## Troubleshooting

### Import errors
- Ensure `tests/` directory has `__init__.py`
- Check Python path includes project root

### Fixture errors
- Verify fixtures are defined in `conftest.py`
- Check fixture scope (function, class, module, session)

### Mock errors
- Ensure correct patch paths
- Verify mock return values match expected types

## Performance

To profile test performance:

```bash
pytest --durations=10  # Show 10 slowest tests
```

## Notes

- Tests use `unittest.mock` for mocking
- Temporary files are automatically cleaned up
- Coverage reports are generated in `htmlcov/` directory
