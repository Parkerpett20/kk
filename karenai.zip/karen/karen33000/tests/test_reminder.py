# tests/test_reminder.py
"""
تست‌های سیستم یادآوری
"""

import pytest
from datetime import datetime, timedelta
import pytz
from core.scheduler import Reminder, ReminderScheduler
import os
import json


@pytest.fixture
def reminder_scheduler():
    """ایجاد scheduler برای تست"""
    import tempfile
    # استفاده از temporary directory
    temp_dir = tempfile.gettempdir()
    test_file = os.path.join(temp_dir, "test_reminders.json")
    scheduler = ReminderScheduler(data_file=test_file)
    yield scheduler
    # پاکسازی
    if os.path.exists(test_file):
        os.remove(test_file)


class TestReminder:
    """تست کلاس Reminder"""
    
    def test_create_reminder(self):
        """تست ایجاد یادآوری"""
        tz = pytz.timezone('Asia/Tehran')
        run_time = datetime.now(tz) + timedelta(hours=1)
        
        reminder = Reminder(
            user_id=123456,
            message="تست",
            run_time=run_time
        )
        
        assert reminder.user_id == 123456
        assert reminder.message == "تست"
        assert reminder.enabled is True
        assert reminder.reminder_id is not None
    
    def test_reminder_to_dict(self):
        """تست تبدیل یادآوری به دیکشنری"""
        tz = pytz.timezone('Asia/Tehran')
        run_time = datetime.now(tz)
        
        reminder = Reminder(
            user_id=789,
            message="متن تست",
            run_time=run_time
        )
        
        data = reminder.to_dict()
        assert data['user_id'] == 789
        assert data['message'] == "متن تست"
        assert 'run_time' in data
    
    def test_reminder_from_dict(self):
        """تست ایجاد یادآوری از دیکشنری"""
        tz = pytz.timezone('Asia/Tehran')
        run_time = datetime.now(tz)
        
        data = {
            'user_id': 111,
            'message': 'یادآوری تست',
            'run_time': run_time.isoformat(),
            'reminder_id': 'test_123',
            'enabled': True,
            'created_at': datetime.now().isoformat()
        }
        
        reminder = Reminder.from_dict(data)
        assert reminder.user_id == 111
        assert reminder.message == 'یادآوری تست'


class TestReminderScheduler:
    """تست کلاس ReminderScheduler"""
    
    def test_add_reminder(self, reminder_scheduler):
        """تست افزودن یادآوری"""
        tz = pytz.timezone('Asia/Tehran')
        run_time = datetime.now(tz) + timedelta(hours=2)
        
        reminder_id = reminder_scheduler.add_reminder(
            user_id=12345,
            message="تست افزودن",
            run_time=run_time
        )
        
        assert reminder_id is not None
        assert reminder_id in reminder_scheduler.reminders
    
    def test_list_reminders(self, reminder_scheduler):
        """تست لیست‌کردن یادآوری‌ها"""
        tz = pytz.timezone('Asia/Tehran')
        
        # افزودن چند یادآوری
        for i in range(3):
            run_time = datetime.now(tz) + timedelta(hours=i+1)
            reminder_scheduler.add_reminder(
                user_id=999,
                message=f"تست {i}",
                run_time=run_time
            )
        
        reminders = reminder_scheduler.list_reminders(user_id=999)
        assert len(reminders) >= 3
    
    def test_delete_reminder(self, reminder_scheduler):
        """تست حذف یادآوری"""
        tz = pytz.timezone('Asia/Tehran')
        run_time = datetime.now(tz) + timedelta(hours=1)
        
        reminder_id = reminder_scheduler.add_reminder(
            user_id=555,
            message="برای حذف",
            run_time=run_time
        )
        
        assert reminder_id in reminder_scheduler.reminders
        
        result = reminder_scheduler.delete_reminder(reminder_id)
        assert result is True
        assert reminder_id not in reminder_scheduler.reminders
    
    def test_get_pending_reminders(self, reminder_scheduler):
        """تست دریافت یادآوری‌های آینده"""
        tz = pytz.timezone('Asia/Tehran')
        
        # یادآوری در آینده
        future_time = datetime.now(tz) + timedelta(hours=2)
        reminder_scheduler.add_reminder(
            user_id=777,
            message="آینده",
            run_time=future_time
        )
        
        # یادآوری در گذشته
        past_time = datetime.now(tz) - timedelta(hours=1)
        reminder_scheduler.add_reminder(
            user_id=777,
            message="گذشته",
            run_time=past_time
        )
        
        pending = reminder_scheduler.get_pending_reminders(user_id=777)
        # فقط یادآوری‌های آینده باید برگردانده شوند
        assert all(r.run_time > datetime.now(tz) for r in pending)

    def test_loaded_reminders_are_scheduled(self, reminder_scheduler, monkeypatch):
        """تست اینکه یادآوری‌های بارگذاری‌شده در scheduler برنامه‌ریزی شوند"""
        tz = pytz.timezone('Asia/Tehran')
        run_time = datetime.now(tz) + timedelta(minutes=5)
        reminder_id = reminder_scheduler.add_reminder(
            user_id=111,
            message="یادآوری بارگذاری‌شده",
            run_time=run_time
        )

        # شبیه‌سازی بارگذاری از فایل جدید
        reminder_scheduler.save_reminders = reminder_scheduler._save_reminders
        new_scheduler = ReminderScheduler(data_file=reminder_scheduler.data_file)
        assert reminder_id in new_scheduler.reminders
        assert new_scheduler.scheduler.get_job(reminder_id) is not None


class TestReminderParsing:
    """تست استخراج اطلاعات یادآوری"""
    
    def test_extract_from_farsi_text(self):
        """تست استخراج از متن فارسی"""
        from handlers.reminder import extract_reminder_info
        
        text = "یادآوری کن که دارو بخور در ساعت 08:00"
        message, run_time = extract_reminder_info(text)
        
        assert message == "دارو بخور"
        assert run_time is not None
        assert run_time.hour == 8
        assert run_time.minute == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
