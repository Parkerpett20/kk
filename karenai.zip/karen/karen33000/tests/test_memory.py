# tests/test_memory.py
"""
Tests for memory modules
"""
import pytest
import os
import json
import tempfile
from unittest.mock import patch, MagicMock
import math


class TestLongMemory:
    """Test LongMemory class"""
    
    def test_long_memory_initialization(self, temp_data_dir):
        """Test long memory initialization"""
        filepath = os.path.join(temp_data_dir, "memories.json")
        from memory.long_memory import LongMemory
        
        memory = LongMemory(filepath=filepath)
        assert memory.filepath == filepath
        assert memory.data == {}
    
    def test_save_and_get_facts(self, temp_data_dir):
        """Test saving and retrieving facts"""
        filepath = os.path.join(temp_data_dir, "memories.json")
        from memory.long_memory import LongMemory
        
        memory = LongMemory(filepath=filepath)
        memory.save_fact(123, "name", "Ali")
        memory.save_fact(123, "city", "Tehran")
        
        facts = memory.get_user_facts(123)
        assert "Ali" in facts
        assert "Tehran" in facts
    
    def test_get_nonexistent_user_facts(self, temp_data_dir):
        """Test getting facts for non-existent user"""
        filepath = os.path.join(temp_data_dir, "memories.json")
        from memory.long_memory import LongMemory
        
        memory = LongMemory(filepath=filepath)
        facts = memory.get_user_facts(999)
        assert facts == ""
    
    def test_persistence_across_instances(self, temp_data_dir):
        """Test that data persists across instances"""
        filepath = os.path.join(temp_data_dir, "memories.json")
        from memory.long_memory import LongMemory
        
        # Create first instance and save
        memory1 = LongMemory(filepath=filepath)
        memory1.save_fact(456, "role", "developer")
        
        # Create second instance and verify data exists
        memory2 = LongMemory(filepath=filepath)
        facts = memory2.get_user_facts(456)
        assert "developer" in facts


class TestShortMemory:
    """Test ShortMemory class"""
    
    def test_short_memory_initialization(self, temp_data_dir):
        """Test short memory initialization"""
        dataset_path = os.path.join(temp_data_dir, "dataset.jsonl")
        sessions_path = os.path.join(temp_data_dir, "short_memory.json")
        from memory.short_memory import ShortMemory
        
        memory = ShortMemory(dataset_path=dataset_path, sessions_path=sessions_path)
        assert memory.dataset_path == dataset_path
        assert memory.sessions == {}
    
    def test_get_history_creates_session(self, temp_data_dir):
        """Test that getting history creates a session"""
        dataset_path = os.path.join(temp_data_dir, "dataset.jsonl")
        sessions_path = os.path.join(temp_data_dir, "short_memory.json")
        from memory.short_memory import ShortMemory
        
        memory = ShortMemory(dataset_path=dataset_path, sessions_path=sessions_path)
        history = memory.get_history(789)
        assert 789 in memory.sessions
        assert isinstance(history, list)
    
    def test_add_message_to_history(self, temp_data_dir):
        """Test adding messages to history"""
        dataset_path = os.path.join(temp_data_dir, "dataset.jsonl")
        sessions_path = os.path.join(temp_data_dir, "short_memory.json")
        from memory.short_memory import ShortMemory
        
        memory = ShortMemory(dataset_path=dataset_path, sessions_path=sessions_path)
        initial_length = len(memory.get_history(789))
        memory.add(789, "user", "Hello")
        final_length = len(memory.get_history(789))
        
        assert final_length > initial_length
    
    def test_clear_history(self, temp_data_dir):
        """Test clearing history"""
        dataset_path = os.path.join(temp_data_dir, "dataset.jsonl")
        sessions_path = os.path.join(temp_data_dir, "short_memory.json")
        from memory.short_memory import ShortMemory
        
        memory = ShortMemory(dataset_path=dataset_path, sessions_path=sessions_path)
        memory.add(111, "user", "Message")
        assert len(memory.get_history(111)) > 0
        
        memory.clear(111)
        history_after_clear = memory.get_history(111)
        assert len(history_after_clear) == 0


class TestVectorMemory:
    """Test VectorMemory class"""
    
    def test_vector_memory_initialization(self, temp_data_dir):
        """Test vector memory initialization"""
        filepath = os.path.join(temp_data_dir, "vectors", "memory.json")
        from memory.vector_memory import VectorMemory
        
        memory = VectorMemory(filepath=filepath)
        assert memory.filepath == filepath
        assert memory.index == []
    
    def test_cosine_similarity(self):
        """Test cosine similarity calculation"""
        from memory.vector_memory import VectorMemory
        
        v1 = [1, 0, 0]
        v2 = [1, 0, 0]
        similarity = VectorMemory._cosine_similarity(v1, v2)
        assert similarity == pytest.approx(1.0)
    
    def test_cosine_similarity_orthogonal(self):
        """Test cosine similarity with orthogonal vectors"""
        from memory.vector_memory import VectorMemory
        
        v1 = [1, 0, 0]
        v2 = [0, 1, 0]
        similarity = VectorMemory._cosine_similarity(v1, v2)
        assert similarity == pytest.approx(0.0)
    
    def test_zero_vector_similarity(self):
        """Test similarity with zero vector"""
        from memory.vector_memory import VectorMemory
        
        v1 = [0, 0, 0]
        v2 = [1, 1, 1]
        similarity = VectorMemory._cosine_similarity(v1, v2)
        assert similarity == 0.0
    
    @patch('memory.embeddings.EmbeddingGenerator.get_vector')
    def test_add_memory(self, mock_get_vector, temp_data_dir):
        """Test adding memory"""
        filepath = os.path.join(temp_data_dir, "vectors", "memory.json")
        mock_get_vector.return_value = [0.1, 0.2, 0.3]
        
        from memory.vector_memory import VectorMemory
        memory = VectorMemory(filepath=filepath)
        memory.add_memory("Test memory", {"source": "test"})
        
        assert len(memory.index) > 0
        assert memory.index[0]["text"] == "Test memory"
        assert memory.index[0]["metadata"]["source"] == "test"


class TestUserProfile:
    """Test UserProfileManager class"""
    
    def test_user_profile_initialization(self, temp_data_dir):
        """Test user profile initialization"""
        filepath = os.path.join(temp_data_dir, "user_profile.json")
        from memory.user_profile import UserProfileManager
        
        profile = UserProfileManager(filepath=filepath)
        assert profile.filepath == filepath
        assert "name" in profile.profile
        assert "interests" in profile.profile
        assert "extracted_facts" in profile.profile
    
    def test_extract_and_update_profile(self, temp_data_dir):
        """Test extracting and updating profile"""
        filepath = os.path.join(temp_data_dir, "user_profile.json")
        from memory.user_profile import UserProfileManager
        
        profile = UserProfileManager(filepath=filepath)
        initial_facts = len(profile.profile["extracted_facts"])
        
        with patch('google.genai.Client') as mock_client:
            mock_instance = MagicMock()
            mock_response = MagicMock()
            mock_response.text = "Works as a software engineer in Python"
            mock_instance.models.generate_content.return_value = mock_response
            
            with patch('memory.user_profile.client', mock_instance):
                profile.extract_and_update("I work as a software engineer")
                assert len(profile.profile["extracted_facts"]) >= initial_facts
    
    def test_get_summary_context(self, temp_data_dir):
        """Test getting profile summary context"""
        filepath = os.path.join(temp_data_dir, "user_profile.json")
        from memory.user_profile import UserProfileManager
        
        profile = UserProfileManager(filepath=filepath)
        profile.profile["extracted_facts"] = ["Likes Python", "Engineer"]
        
        context = profile.get_summary_context()
        assert "Likes Python" in context
        assert "Engineer" in context
        assert "Persisted User Knowledge" in context
