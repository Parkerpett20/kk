# tests/test_telegram_profile.py
import pytest
import os
import json
from unittest.mock import MagicMock
from memory.telegram_profile import TelegramProfileManager


class TestTelegramProfileManager:
    """تست‌های مدیریت پروفایل تلگرام"""
    
    def setup_method(self):
        self.test_file = "data/test_telegram_profiles.json"
        if os.path.exists(self.test_file):
            os.remove(self.test_file)
        self.manager = TelegramProfileManager(filepath=self.test_file)
    
    def teardown_method(self):
        if os.path.exists(self.test_file):
            os.remove(self.test_file)
    
    def test_initialization(self):
        """تست مقداردهی اولیه"""
        assert self.manager.profiles == {}
    
    def test_update_profile(self):
        """تست بروزرسانی پروفایل"""
        self.manager.update_profile(
            user_id=123456,
            first_name="علی",
            last_name="احمدی",
            username="ali_ahmadi",
            language_code="fa"
        )
        
        profile = self.manager.get_profile(123456)
        assert profile["user_id"] == 123456
        assert profile["first_name"] == "علی"
        assert profile["last_name"] == "احمدی"
        assert profile["username"] == "ali_ahmadi"
        assert profile["language_code"] == "fa"
        assert profile["message_count"] == 1
    
    def test_update_profile_preserves_existing(self):
        """تست حفظ اطلاعات موجود هنگام بروزرسانی"""
        self.manager.update_profile(
            user_id=123456,
            first_name="علی",
            username="ali"
        )
        
        self.manager.update_profile(
            user_id=123456,
            last_name="احمدی"
        )
        
        profile = self.manager.get_profile(123456)
        assert profile["first_name"] == "علی"
        assert profile["last_name"] == "احمدی"
    
    def test_increment_message_count(self):
        """تست افزایش تعداد پیام"""
        self.manager.update_profile(user_id=123456, first_name="علی")
        
        self.manager.increment_message_count(123456)
        self.manager.increment_message_count(123456)
        
        profile = self.manager.get_profile(123456)
        assert profile["message_count"] == 3
    
    def test_get_profile_summary(self):
        """تست ساخت خلاصه پروفایل"""
        self.manager.update_profile(
            user_id=123456,
            first_name="علی",
            username="ali_ahmadi",
            language_code="fa",
            is_premium=True,
            bio="برنامه‌نویس"
        )
        
        summary = self.manager.get_profile_summary(123456)
        assert "علی" in summary
        assert "@ali_ahmadi" in summary
        assert "fa" in summary
        assert "Premium" in summary
        assert "برنامه‌نویس" in summary
    
    def test_get_profile_summary_empty(self):
        """تست خلاصه خالی برای کاربر ناشناخته"""
        summary = self.manager.get_profile_summary(999999)
        assert summary == ""
    
    def test_extract_from_message(self):
        """تست استخراج اطلاعات از پیام"""
        message = MagicMock()
        message.from_user = MagicMock()
        message.from_user.id = 123456
        message.from_user.first_name = "علی"
        message.from_user.last_name = "احمدی"
        message.from_user.username = "ali_ahmadi"
        message.from_user.language_code = "fa"
        message.from_user.is_premium = False
        message.from_user.is_bot = False
        message.from_user.is_contact = False
        message.from_user.is_mutual_contact = False
        message.from_user.is_self = False
        
        self.manager.extract_from_message(message)
        
        profile = self.manager.get_profile(123456)
        assert profile["first_name"] == "علی"
        assert profile["username"] == "ali_ahmadi"
    
    def test_store_fact(self):
        """تست ذخیره حقیقت"""
        self.manager.store_fact(123456, "برنامه‌نویس پایتون")
        self.manager.store_fact(123456, "علاقه‌مند به AI")
        
        profile = self.manager.get_profile(123456)
        assert "برنامه‌نویس پایتون" in profile["extracted_facts"]
        assert "علاقه‌مند به AI" in profile["extracted_facts"]
    
    def test_store_fact_no_duplicates(self):
        """تست عدم ذخیره تکراری حقایق"""
        self.manager.store_fact(123456, "برنامه‌نویس")
        self.manager.store_fact(123456, "برنامه‌نویس")
        
        profile = self.manager.get_profile(123456)
        assert profile["extracted_facts"].count("برنامه‌نویس") == 1
    
    def test_persistence(self):
        """تست پایداری داده‌ها"""
        self.manager.update_profile(user_id=123456, first_name="علی")
        self.manager.save()
        
        new_manager = TelegramProfileManager(filepath=self.test_file)
        profile = new_manager.get_profile(123456)
        assert profile["first_name"] == "علی"
