# tests/test_utils.py
"""
Tests for utility modules
"""
import pytest
import os
import logging
from unittest.mock import patch


class TestLogger:
    """Test logging utilities"""
    
    def test_logger_setup(self, temp_data_dir):
        """Test logger setup"""
        from utils.logger import setup_logger
        
        # Change to temp directory to avoid polluting logs/
        original_dir = os.getcwd()
        try:
            os.chdir(temp_data_dir)
            logger = setup_logger("test_karen")
            assert logger is not None
            assert isinstance(logger, logging.Logger)
        finally:
            os.chdir(original_dir)
    
    def test_logger_writes_to_file(self, temp_data_dir):
        """Test that logger writes to file"""
        from utils.logger import setup_logger
        
        original_dir = os.getcwd()
        try:
            os.chdir(temp_data_dir)
            logger = setup_logger("test_logger")
            logger.info("Test log message")
            
            # Check if log file was created
            log_files = [f for f in os.listdir("logs") if f.endswith(".log")]
            assert len(log_files) > 0
        finally:
            os.chdir(original_dir)
    
    def test_logger_multiple_handlers(self, temp_data_dir):
        """Test that logger has multiple handlers"""
        from utils.logger import setup_logger
        
        original_dir = os.getcwd()
        try:
            os.chdir(temp_data_dir)
            logger = setup_logger("multi_handler")
            # Should have file handler, error handler, and console handler
            assert len(logger.handlers) >= 2
        finally:
            os.chdir(original_dir)
