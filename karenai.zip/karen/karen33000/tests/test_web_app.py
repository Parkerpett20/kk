import pytest

from web.app import app


@pytest.fixture
def client():
    app.config.update(TESTING=True)
    with app.test_client() as client:
        yield client


def test_api_send_rejects_invalid_json(client):
    response = client.post(
        '/api/send',
        data='{"message":}',
        content_type='application/json',
    )

    assert response.status_code == 400
    payload = response.get_json()
    assert payload['error'] == 'JSON object required'


def test_api_language_rejects_invalid_json(client):
    response = client.post(
        '/api/language',
        data='not-json',
        content_type='application/json',
    )

    assert response.status_code == 400
    payload = response.get_json()
    assert payload['error'] == 'JSON object required'
