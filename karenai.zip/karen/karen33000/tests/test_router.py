from core.executor import should_request_github_target
from core.router import IntentRouter


def test_ambiguous_github_request_is_detected():
    plan = IntentRouter.route("گیت هاب فلانی رو بررسی کن")
    assert plan["github"] is True


def test_ambiguous_github_request_requires_target():
    assert should_request_github_target("گیت هاب فلانی رو بررسی کن") is True
    assert should_request_github_target("گیت هاب torvalds/linux را بررسی کن") is False
    assert should_request_github_target("پروفایل octocat را نشان بده") is False
