# tests/test_integration.py
"""
Integration tests for Karen AI Agent
"""
import pytest
from unittest.mock import patch, MagicMock


class TestMemoryIntegration:
    """Integration tests for memory modules"""
    
    def test_long_memory_with_profile(self, temp_data_dir):
        """Test long memory and profile integration"""
        import os
        
        long_mem_file = os.path.join(temp_data_dir, "memories.json")
        profile_file = os.path.join(temp_data_dir, "user_profile.json")
        
        from memory.long_memory import LongMemory
        from memory.user_profile import UserProfileManager
        
        long_mem = LongMemory(filepath=long_mem_file)
        profile = UserProfileManager(filepath=profile_file)
        
        # Save to both
        chat_id = 999
        long_mem.save_fact(chat_id, "hobby", "reading")
        profile.profile["interests"].append("reading")
        profile.save()
        
        # Verify both stored data
        facts = long_mem.get_user_facts(chat_id)
        assert "reading" in facts
        assert "reading" in profile.profile["interests"]


class TestToolIntegration:
    """Integration tests for tools"""
    
    def test_calculator_with_filesystem(self, temp_data_dir):
        """Test calculator and filesystem tools together"""
        import os
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_data_dir)
            
            from tools.calculator import calculate_math
            from tools.filesystem import write_file, read_file
            
            # Calculate
            result = calculate_math("100 * 2 + 50")
            
            # Save result to file
            write_file("calc_result.txt", result)
            
            # Read it back
            content = read_file("calc_result.txt")
            assert "250" in content
            
        finally:
            os.chdir(original_cwd)


class TestPluginIntegration:
    """Integration tests for plugins"""
    
    def test_todo_and_notes_workflow(self, temp_data_dir):
        """Test TODO and notes workflow"""
        import os
        from plugins.todo import todo_plugin
        from plugins.notes import notes_plugin
        
        # Patch files
        original_todo = todo_plugin.TODO_FILE
        original_notes = notes_plugin.NOTES_FILE
        
        todo_plugin.TODO_FILE = os.path.join(temp_data_dir, "todos.json")
        notes_plugin.NOTES_FILE = os.path.join(temp_data_dir, "notes.json")
        
        try:
            # Create task
            todo_plugin.add_todo_item("Write project documentation")
            
            # Create note
            notes_plugin.save_note("Project Plan", "Documentation in progress")
            
            # Verify both were created
            todos = todo_plugin.list_todo_items()
            assert "Write project documentation" in todos
            
            notes = notes_plugin.read_note("Project Plan")
            assert "Documentation in progress" in notes
            
        finally:
            todo_plugin.TODO_FILE = original_todo
            notes_plugin.NOTES_FILE = original_notes
