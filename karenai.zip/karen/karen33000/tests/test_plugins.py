# tests/test_plugins.py
"""
Tests for plugin modules
"""
import pytest
import os
import json
import tempfile


class TestTodoPlugin:
    """Test TODO plugin"""
    
    def test_add_todo_item(self, temp_data_dir):
        """Test adding TODO item"""
        todo_file = os.path.join(temp_data_dir, "todos.json")
        
        # Patch the TODO_FILE path
        from plugins.todo import todo_plugin
        original_todo_file = todo_plugin.TODO_FILE
        todo_plugin.TODO_FILE = todo_file
        
        try:
            result = todo_plugin.add_todo_item("Learn Python")
            assert "Added task" in result
            
            # Verify file was created
            assert os.path.exists(todo_file)
        finally:
            todo_plugin.TODO_FILE = original_todo_file
    
    def test_list_todo_items(self, temp_data_dir):
        """Test listing TODO items"""
        todo_file = os.path.join(temp_data_dir, "todos.json")
        
        from plugins.todo import todo_plugin
        original_todo_file = todo_plugin.TODO_FILE
        todo_plugin.TODO_FILE = todo_file
        
        try:
            todo_plugin.add_todo_item("Task 1")
            todo_plugin.add_todo_item("Task 2")
            
            result = todo_plugin.list_todo_items()
            assert "Task 1" in result
            assert "Task 2" in result
        finally:
            todo_plugin.TODO_FILE = original_todo_file
    
    def test_complete_todo_item(self, temp_data_dir):
        """Test completing TODO item"""
        todo_file = os.path.join(temp_data_dir, "todos.json")
        
        from plugins.todo import todo_plugin
        original_todo_file = todo_plugin.TODO_FILE
        todo_plugin.TODO_FILE = todo_file
        
        try:
            todo_plugin.add_todo_item("Task to complete")
            result = todo_plugin.complete_todo_item(1)
            assert "marked as completed" in result
        finally:
            todo_plugin.TODO_FILE = original_todo_file


class TestNotesPlugin:
    """Test Notes plugin"""
    
    def test_save_note(self, temp_data_dir):
        """Test saving note"""
        notes_file = os.path.join(temp_data_dir, "notes.json")
        
        from plugins.notes import notes_plugin
        original_notes_file = notes_plugin.NOTES_FILE
        notes_plugin.NOTES_FILE = notes_file
        
        try:
            result = notes_plugin.save_note("Test Note", "This is a test note")
            assert "saved" in result.lower() or "created" in result.lower()
        finally:
            notes_plugin.NOTES_FILE = original_notes_file
    
    def test_read_note(self, temp_data_dir):
        """Test reading note"""
        notes_file = os.path.join(temp_data_dir, "notes.json")
        
        from plugins.notes import notes_plugin
        original_notes_file = notes_plugin.NOTES_FILE
        notes_plugin.NOTES_FILE = notes_file
        
        try:
            notes_plugin.save_note("My Note", "Content here")
            result = notes_plugin.read_note("My Note")
            assert "Content here" in result
        finally:
            notes_plugin.NOTES_FILE = original_notes_file


class TestCalendarPlugin:
    """Test Calendar plugin"""
    
    def test_get_gregorian_calendar(self):
        """Test getting Gregorian calendar"""
        from plugins.calendar.calendar_plugin import get_gregorian_calendar_details
        
        result = get_gregorian_calendar_details()
        assert "year" in result.lower() or "month" in result.lower() or "day" in result.lower()


class TestWeatherPlugin:
    """Test Weather plugin"""
    
    def test_fetch_weather_invalid_city(self):
        """Test fetching weather for city"""
        from plugins.weather.weather_plugin import fetch_weather
        
        # This might fail without internet, but should handle gracefully
        result = fetch_weather("UnknownCityXYZ12345")
        assert isinstance(result, str)
