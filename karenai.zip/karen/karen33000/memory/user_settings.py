# memory/user_settings.py
import os
import json
import logging

logger = logging.getLogger(__name__)

class UserSettings:
    """مدیریت تنظیمات کاربران از جمله زبان"""
    
    def __init__(self, filepath="data/user_settings.json"):
        self.filepath = filepath
        self._ensure_dir()
        self.settings = self._load()
    
    def _ensure_dir(self):
        try:
            os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
        except Exception as e:
            logger.error(f"خطا در ایجاد دایرکتوری user_settings: {e}")
    
    def _load(self) -> dict:
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except json.JSONDecodeError as je:
                logger.warning(f"فایل user_settings.json خراب است: {je}")
            except Exception as e:
                logger.error(f"خطا در بارگذاری user_settings: {e}")
        return {}
    
    def save(self):
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, ensure_ascii=False, indent=4)
            logger.debug("تنظیمات کاربر ذخیره شد")
        except Exception as e:
            logger.error(f"خطا در ذخیره تنظیمات کاربر: {e}")
    
    def get_language(self, user_id: int) -> str:
        """دریافت زبان کاربر"""
        user_key = str(user_id)
        if user_key in self.settings:
            return self.settings[user_key].get("language", "en")
        return "en"
    
    def set_language(self, user_id: int, language: str):
        """تنظیم زبان کاربر"""
        user_key = str(user_id)
        if user_key not in self.settings:
            self.settings[user_key] = {}
        self.settings[user_key]["language"] = language
        self.save()
        logger.info(f"زبان کاربر {user_key} تغییر کرد به {language}")
    
    def is_new_user(self, user_id: int) -> bool:
        """بررسی آیا کاربر جدید است (تنظیمات ندارد)"""
        return str(user_id) not in self.settings
    
    def get_setting(self, user_id: int, key: str, default=None):
        """دریافت تنظیم خاص کاربر"""
        user_key = str(user_id)
        if user_key in self.settings:
            return self.settings[user_key].get(key, default)
        return default
    
    def set_setting(self, user_id: int, key: str, value):
        """تنظیم مقدار خاص برای کاربر"""
        user_key = str(user_id)
        if user_key not in self.settings:
            self.settings[user_key] = {}
        self.settings[user_key][key] = value
        self.save()

# نمونه سراسری
user_settings = UserSettings()