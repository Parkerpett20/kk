# memory/short_memory.py
import os
import json
import logging
from google.genai import types

logger = logging.getLogger(__name__)

class ShortMemory:
    """مدیریت تاریخچه پیام‌های کوتاه‌مدت نشست جاری بر اساس Chat ID — با ذخیره دایمی روی دیسک"""
    def __init__(self, dataset_path="data/dataset.jsonl", sessions_path="data/short_memory.json"):
        self.sessions = {}
        self.dataset_path = dataset_path
        self.sessions_path = sessions_path
        self.guardrails = self._load_guardrails()
        self._load_sessions()

    def _load_guardrails(self):
        history = []
        if not os.path.exists(self.dataset_path):
            logger.debug(f"فایل {self.dataset_path} پیدا نشد")
            return history
        try:
            with open(self.dataset_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if not line.strip(): 
                        continue
                    try:
                        data = json.loads(line)
                        for msg in data.get("messages", []):
                            if msg["role"] == "system": 
                                continue
                            role = "user" if msg["role"] == "user" else "model"
                            history.append(
                                types.Content(role=role, parts=[types.Part(text=msg["content"])])
                            )
                    except json.JSONDecodeError as je:
                        logger.warning(f"خط JSON خراب: {je}")
                        continue
            logger.info(f"تاریخچه‌ی guardrails با {len(history)} پیام بارگذاری شد")
        except Exception as e:
            logger.error(f"خطا در بارگذاری dataset: {e}", exc_info=True)
        return history

    def _load_sessions(self):
        if not os.path.exists(self.sessions_path):
            return
        try:
            with open(self.sessions_path, 'r', encoding='utf-8') as f:
                raw = json.load(f)
            for chat_id_str, messages in raw.items():
                chat_id = int(chat_id_str)
                history = list(self.guardrails)
                for msg in messages:
                    role = msg.get("role", "user")
                    text = msg.get("text", "")
                    if text:
                        history.append(types.Content(role=role, parts=[types.Part(text=text)]))
                self.sessions[chat_id] = history
            logger.info(f"تاریخچه‌ی سشن‌ها از دیسک بارگذاری شد: {len(self.sessions)} سشن")
        except Exception as e:
            logger.error(f"خطا در بارگذاری short_memory: {e}")

    def _save_sessions(self):
        try:
            os.makedirs(os.path.dirname(self.sessions_path), exist_ok=True)
            raw = {}
            for chat_id, history in self.sessions.items():
                messages = []
                for msg in history:
                    text = ""
                    if hasattr(msg, "parts") and msg.parts:
                        for part in msg.parts:
                            if hasattr(part, "text") and part.text:
                                text += part.text
                    if text:
                        messages.append({"role": msg.role, "text": text})
                raw[str(chat_id)] = messages
            with open(self.sessions_path, 'w', encoding='utf-8') as f:
                json.dump(raw, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"خطا در ذخیره short_memory: {e}")

    def get_history(self, chat_id: int):
        if chat_id not in self.sessions:
            self.sessions[chat_id] = list(self.guardrails)
        return self.sessions[chat_id]

    def add(self, chat_id: int, role: str, text: str):
        try:
            history = self.get_history(chat_id)
            history.append(types.Content(role=role, parts=[types.Part(text=text)]))
            if len(history) > 35:
                self.sessions[chat_id] = history[:8] + history[-25:]
                logger.debug(f"تاریخچه‌ی سشن {chat_id} محدود شد به 33 پیام")
            self._save_sessions()
        except Exception as e:
            logger.error(f"خطا در افزودن پیام به تاریخچه {chat_id}: {e}", exc_info=True)

    def clear(self, chat_id: int):
        try:
            if chat_id in self.sessions:
                self.sessions[chat_id] = list(self.guardrails)
                self._save_sessions()
                logger.info(f"تاریخچه‌ی سشن {chat_id} پاک شد")
        except Exception as e:
            logger.error(f"خطا در پاک کردن تاریخچه {chat_id}: {e}")

short_term_memory = ShortMemory()
