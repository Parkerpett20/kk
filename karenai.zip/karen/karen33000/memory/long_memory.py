# memory/long_memory.py
import os
import json
import logging

logger = logging.getLogger(__name__)

class LongMemory:
    """ثبت حقایق آموخته شده در مورد کاربر در دیسک محلی"""
    def __init__(self, filepath="data/memories.json"):
        self.filepath = filepath
        self._ensure_dir()
        self.data = self._load()

    def _ensure_dir(self):
        try:
            os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
        except Exception as e:
            logger.error(f"خطا در ایجاد دایرکتوری {self.filepath}: {e}")

    def _load(self):
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError as e:
                logger.warning(f"فایل memories.json خراب است: {e}. استفاده از دیتای خالی")
                return {}
            except Exception as e:
                logger.error(f"خطا در بارگذاری long memory: {e}")
                return {}
        return {}

    def save_fact(self, chat_id: str, key: str, value: str):
        try:
            chat_id = str(chat_id)
            if chat_id not in self.data:
                self.data[chat_id] = {}
            self.data[chat_id][key] = value
            with open(self.filepath, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, ensure_ascii=False, indent=4)
            logger.debug(f"حقیقت ذخیره شد برای کاربر {chat_id}: {key}={value}")
        except Exception as e:
            logger.error(f"خطا در ذخیره‌ی حقیقت: {e}")

    def get_user_facts(self, chat_id: int) -> str:
        try:
            chat_id = str(chat_id)
            facts = self.data.get(chat_id, {})
            if not facts:
                return ""
            return "\n".join([f"- {k}: {v}" for k, v in facts.items()])
        except Exception as e:
            logger.error(f"خطا در بازیابی حقایق کاربر {chat_id}: {e}")
            return ""

long_term_memory = LongMemory()
