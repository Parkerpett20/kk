# memory/vector_memory.py
import os
import json
import math
from memory.embeddings import EmbeddingGenerator

class VectorMemory:
    """پایگاه داده برداری سبک برای جستجوی معنایی و بازیابی اطلاعات گذشته"""
    def __init__(self, filepath="data/vectors/memory.json"):
        self.filepath = filepath
        self._ensure_dir()
        self.index = self._load()

    def _ensure_dir(self):
        os.makedirs(os.path.dirname(self.filepath), exist_ok=True)

    def _load(self) -> list:
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return []
        return []

    def _save(self):
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(self.index, f, ensure_ascii=False, indent=4)

    def add_memory(self, text: str, metadata: dict = None):
        """تولید بردار و ذخیره متن در پایگاه داده محلی"""
        if not text or not text.strip():
            return
        vector = EmbeddingGenerator.get_vector(text)
        if not vector:
            return

        self.index.append({
            "text": text,
            "vector": vector,
            "metadata": metadata or {}
        })
        self._save()

    @staticmethod
    def _cosine_similarity(v1: list, v2: list) -> float:
        """محاسبه شباهت کسینوسی دو بردار"""
        dot_product = sum(x * y for x, y in zip(v1, v2))
        magnitude_v1 = math.sqrt(sum(x * x for x in v1))
        magnitude_v2 = math.sqrt(sum(x * x for x in v2))
        
        if magnitude_v1 == 0 or magnitude_v2 == 0:
            return 0.0
        return dot_product / (magnitude_v1 * magnitude_v2)

    def query(self, query_text: str, top_k: int = 3) -> list:
        """یافتن مرتبط‌ترین کانتکست‌ها بر اساس شباهت معنایی"""
        query_vector = EmbeddingGenerator.get_vector(query_text)
        if not query_vector or not self.index:
            return []

        scored_results = []
        for item in self.index:
            similarity = self._cosine_similarity(query_vector, item["vector"])
            scored_results.append((similarity, item["text"], item["metadata"]))

        # مرتب‌سازی نتایج بر اساس بالاترین امتیاز شباهت
        scored_results.sort(key=lambda x: x[0], reverse=True)
        return scored_results[:top_k]

vector_memory = VectorMemory()