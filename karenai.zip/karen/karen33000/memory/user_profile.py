# memory/user_profile.py
import os
import json
import logging

try:
    import google.genai as genai
except Exception:
    genai = None

from config import GEMINI_API_KEY, MODELS

logger = logging.getLogger(__name__)

# Initialize client lazily; tests may patch `memory.user_profile.client`.
client = None
if genai is not None and GEMINI_API_KEY:
    try:
        client = genai.Client(api_key=GEMINI_API_KEY)
    except Exception:
        client = None


class UserProfileManager:
    """تحلیل و مدیریت ساختاریافته مشخصات، علایق و اطلاعات هویت کاربر"""
    def __init__(self, filepath="data/user_profile.json"):
        self.filepath = filepath
        self._ensure_dir()
        self.profile = self._load()

    def _ensure_dir(self):
        try:
            os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
        except Exception as e:
            logger.error(f"خطا در ایجاد دایرکتوری user_profile: {e}")

    def _load(self) -> dict:
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    logger.info(f"پروفایل کاربر بارگذاری شد با {len(data.get('extracted_facts', []))} حقیقت")
                    return data
            except json.JSONDecodeError as je:
                logger.warning(f"فایل user_profile.json خراب است: {je}")
            except Exception as e:
                logger.error(f"خطا در بارگذاری user_profile: {e}")
        return {
            "name": "Unknown",
            "interests": [],
            "extracted_facts": []
        }

    def save(self):
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(self.profile, f, ensure_ascii=False, indent=4)
            logger.debug(f"پروفایل کاربر ذخیره شد")
        except Exception as e:
            logger.error(f"خطا در ذخیره پروفایل کاربر: {e}")

    def extract_and_update(self, last_message: str):
        """تحلیل پیام کاربر برای یافتن و ثبت فکت‌های مهم هویتی"""
        if not last_message or len(last_message) < 8:
            return

        prompt = (
            f"Analyze this single user message and determine if it contains any persistent details about the user "
            f"(e.g., job, name, city, preference, programming language, hobbies).\n"
            f"User Message: \"{last_message}\"\n\n"
            f"If relevant facts are found, extract them as a single short English fact. Otherwise, return 'None'."
        )
        try:
            if client is None:
                logger.debug("No Gemini/GenAI client available for user profile extraction")
                return

            # Choose a model present in config; fall back to any available model
            model_name = MODELS.get("fast_or_search") or next(iter(MODELS.values()))
            response = client.models.generate_content(
                model=model_name,
                contents=prompt
            )
            extracted_fact = getattr(response, "text", "").strip()

            if extracted_fact and extracted_fact.lower() != "none":
                if extracted_fact not in self.profile["extracted_facts"]:
                    self.profile["extracted_facts"].append(extracted_fact)
                    self.save()
                    logger.info(f"حقیقت جدید استخراج شد: {extracted_fact}")
        except Exception as e:
            logger.error(f"❌ خطا در استخراج پروفایل کاربر: {e}", exc_info=True)

    def get_summary_context(self) -> str:
        try:
            facts = self.profile.get("extracted_facts", [])
            if not facts:
                return ""
            return "Persisted User Knowledge:\n" + "\n".join([f"- {f}" for f in facts])
        except Exception as e:
            logger.error(f"خطا در دریافت خلاصه پروفایل: {e}")
            return ""
        