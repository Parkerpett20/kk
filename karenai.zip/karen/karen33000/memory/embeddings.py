# memory/embeddings.py
import logging
from google import genai
from config import GEMINI_API_KEY

logger = logging.getLogger(__name__)
client = genai.Client(api_key=GEMINI_API_KEY)

class EmbeddingGenerator:
    """استخراج مستقیم بردار معنایی با استفاده از مدل استاندارد گوگل"""
    @staticmethod
    def get_vector(text: str) -> list:
        if not text or not text.strip():
            logger.debug("تلاش برای تولید embedding از متن خالی")
            return []
        try:
            response = client.models.embed_content(
                model="text-embedding-004",
                contents=text
            )
            if response.embeddings:
                logger.debug(f"Embedding برای متن {len(text)} کاراکتری تولید شد")
                return response.embeddings[0].values
        except ValueError as ve:
            logger.error(f"خطای مقدار در تولید embedding: {ve}")
        except Exception as e:
            logger.error(f"❌ خطا در تولید embedding: {e}", exc_info=True)
        return []