# memory/telegram_profile.py
import os
import json
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class TelegramProfileManager:
    """مدیریت و کش کردن پروفایل کاربران تلگرام - بی‌سروصدا"""
    
    def __init__(self, filepath="data/telegram_profiles.json"):
        self.filepath = filepath
        self._ensure_dir()
        self.profiles = self._load()
    
    def _ensure_dir(self):
        try:
            os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
        except Exception as e:
            logger.error(f"خطا در ایجاد دایرکتوری telegram_profiles: {e}")
    
    def _load(self) -> dict:
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
            except Exception as e:
                logger.error(f"خطا در بارگذاری telegram_profiles: {e}")
                return {}
        return {}
    
    def save(self):
        try:
            with open(self.filepath, 'w', encoding='utf-8') as f:
                json.dump(self.profiles, f, ensure_ascii=False, indent=4)
        except Exception as e:
            logger.error(f"خطا در ذخیره telegram_profiles: {e}")
    
    def update_profile(self, user_id: int, **kwargs):
        """بروزرسانی پروفایل کاربر با اطلاعات جدید"""
        user_id_str = str(user_id)
        if user_id_str not in self.profiles:
            self.profiles[user_id_str] = {
                "user_id": user_id,
                "first_seen": datetime.now().isoformat(),
                "message_count": 0
            }
        
        profile = self.profiles[user_id_str]
        
        # بروزرسانی فیلدها فقط اگر مقدار جدید خالی نباشد
        for key, value in kwargs.items():
            if value is not None and value != "":
                profile[key] = value
        
        profile["last_seen"] = datetime.now().isoformat()
        profile["message_count"] = profile.get("message_count", 0) + 1
        profile["last_updated"] = datetime.now().isoformat()
        
        self.save()
    
    def increment_message_count(self, user_id: int):
        """افزایش تعداد پیام‌های کاربر"""
        user_id_str = str(user_id)
        if user_id_str in self.profiles:
            self.profiles[user_id_str]["message_count"] = self.profiles[user_id_str].get("message_count", 0) + 1
            self.profiles[user_id_str]["last_seen"] = datetime.now().isoformat()
            self.save()
    
    def get_profile(self, user_id: int) -> dict:
        """دریافت پروفایل کاربر"""
        return self.profiles.get(str(user_id), {})
    
    def get_profile_summary(self, user_id: int) -> str:
        """ساخت خلاصه پروفایل برای تزریق به سیستم پرامپت"""
        profile = self.get_profile(user_id)
        if not profile:
            return ""
        
        parts = []
        
        if profile.get("first_name"):
            name = profile["first_name"]
            if profile.get("last_name"):
                name += f" {profile['last_name']}"
            parts.append(f"Name: {name}")
        
        if profile.get("username"):
            parts.append(f"Username: @{profile['username']}")
        
        if profile.get("language_code"):
            parts.append(f"Language: {profile['language_code']}")
        
        if profile.get("is_premium"):
            parts.append("Premium: Yes")
        
        if profile.get("bio"):
            parts.append(f"Bio: {profile['bio']}")
        
        if profile.get("message_count", 0) > 0:
            parts.append(f"Total messages: {profile['message_count']}")
        
        if profile.get("first_seen"):
            parts.append(f"First seen: {profile['first_seen'][:10]}")
        
        if profile.get("profile_photo_file_id"):
            parts.append("Has profile photo: Yes")
        
        if profile.get("extracted_facts"):
            facts = profile["extracted_facts"]
            if isinstance(facts, list) and facts:
                parts.append("Known facts: " + "; ".join(facts[-5:]))
        
        if parts:
            return "👤 Sender Profile:\n" + "\n".join([f"- {p}" for p in parts])
        return ""
    
    def extract_from_message(self, message):
        """استخراج اطلاعات پروفایل از پیام تلگرام - بی‌سروصدا"""
        try:
            user = message.from_user
            if not user:
                return
            
            self.update_profile(
                user.id,
                first_name=user.first_name,
                last_name=user.last_name,
                username=user.username,
                language_code=user.language_code,
                is_premium=user.is_premium,
                is_bot=user.is_bot,
                is_contact=getattr(user, 'is_contact', None),
                is_mutual_contact=getattr(user, 'is_mutual_contact', None),
                is_self=getattr(user, 'is_self', None),
            )
            
            logger.debug(f"پروفایل کاربر {user.id} بی‌سروصدا بروزرسانی شد")
        except Exception as e:
            logger.debug(f"خطا در استخراج پروفایل: {e}")
    
    def fetch_profile_photo(self, bot, user_id: int) -> str:
        """دریافت عکس پروفایل کاربر از تلگرام"""
        try:
            profile_photos = bot.get_user_profile_photos(user_id, limit=1)
            if profile_photos and profile_photos.photos:
                # گرفتن باکیفیت‌ترین عکس
                photo = profile_photos.photos[0][-1]  # آخرین سایز (بزرگ‌ترین)
                file_id = photo.file_id
                
                # دانلود فایل عکس
                photo_dir = "data/profile_photos"
                os.makedirs(photo_dir, exist_ok=True)
                file_path = os.path.join(photo_dir, f"{user_id}.jpg")
                
                try:
                    file_info = bot.get_file(file_id)
                    downloaded_file = bot.download_file(file_info.file_path)
                    with open(file_path, 'wb') as f:
                        f.write(downloaded_file)
                    
                    # ذخیره اطلاعات در پروفایل
                    user_id_str = str(user_id)
                    if user_id_str not in self.profiles:
                        self.profiles[user_id_str] = {
                            "user_id": user_id,
                            "first_seen": datetime.now().isoformat(),
                            "message_count": 0
                        }
                    
                    self.profiles[user_id_str]["profile_photo_file_id"] = file_id
                    self.profiles[user_id_str]["profile_photo_path"] = file_path
                    self.save()
                    
                    logger.debug(f"عکس پروفایل کاربر {user_id} دانلود شد: {file_path}")
                    return file_path
                except Exception as e:
                    logger.debug(f"خطا در دانلود عکس پروفایل: {e}")
        except Exception as e:
            logger.debug(f"خطا در دریافت عکس پروفایل کاربر {user_id}: {e}")
        return None
    
    def get_profile_photo_file_id(self, user_id: int) -> str:
        """دریافت file_id عکس پروفایل از کش"""
        profile = self.get_profile(user_id)
        return profile.get("profile_photo_file_id")
    
    def get_profile_photo_path(self, user_id: int) -> str:
        """دریافت مسیر فایل عکس پروفایل از کش"""
        profile = self.get_profile(user_id)
        return profile.get("profile_photo_path")
    
    def has_profile_photo(self, user_id: int) -> bool:
        """بررسی وجود عکس پروفایل"""
        return bool(self.get_profile_photo_file_id(user_id))
    
    def check_profile_photo_changed(self, bot, user_id: int) -> bool:
        """بررسی آیا عکس پروفایل کاربر تغییر کرده"""
        try:
            profile_photos = bot.get_user_profile_photos(user_id, limit=1)
            if not profile_photos or not profile_photos.photos:
                return False
            
            current_file_id = profile_photos.photos[0][-1].file_id
            cached_file_id = self.get_profile_photo_file_id(user_id)
            
            # اگر قبلاً عکسی نداشته یا file_id تغییر کرده
            if not cached_file_id or current_file_id != cached_file_id:
                return True
            
            return False
        except Exception as e:
            logger.debug(f"خطا در بررسی تغییر عکس پروفایل: {e}")
            return False
    
    def get_photo_change_info(self, user_id: int) -> dict:
        """دریافت اطلاعات آخرین تغییر عکس پروفایل"""
        profile = self.get_profile(user_id)
        return {
            "last_photo_change": profile.get("last_photo_change"),
            "previous_photo_existed": profile.get("previous_photo_existed", False)
        }
    
    def update_photo_change_timestamp(self, user_id: int, had_previous_photo: bool):
        """بروزرسانی زمان آخرین تغییر عکس پروفایل"""
        user_id_str = str(user_id)
        if user_id_str not in self.profiles:
            self.profiles[user_id_str] = {
                "user_id": user_id,
                "first_seen": datetime.now().isoformat(),
                "message_count": 0
            }
        
        self.profiles[user_id_str]["last_photo_change"] = datetime.now().isoformat()
        self.profiles[user_id_str]["previous_photo_existed"] = had_previous_photo
        self.save()
    
    def store_fact(self, user_id: int, fact: str):
        """ذخیره یک حقیقت جدید درباره کاربر"""
        user_id_str = str(user_id)
        if user_id_str not in self.profiles:
            self.profiles[user_id_str] = {
                "user_id": user_id,
                "first_seen": datetime.now().isoformat(),
                "message_count": 0
            }
        
        if "extracted_facts" not in self.profiles[user_id_str]:
            self.profiles[user_id_str]["extracted_facts"] = []
        
        facts = self.profiles[user_id_str]["extracted_facts"]
        if fact not in facts:
            facts.append(fact)
            # حفظ فقط 20 حقیقت آخر
            if len(facts) > 20:
                self.profiles[user_id_str]["extracted_facts"] = facts[-20:]
            self.save()


telegram_profile_manager = TelegramProfileManager()
