#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Quick test to verify YouTube routing works"""

from core.router import IntentRouter

# Test YouTube routing
test_queries = [
    'ویدیو بتمن رو سرچ کنه',
    'youtube batman',
    'ویدیو پیدا کن',
    'فیلم سرچ',
    'tutorial',
    'آموزش پایتون'
]

print("Testing YouTube Router:")
print("-" * 60)

for query in test_queries:
    plan = IntentRouter.route(query)
    print(f"Query: {query}")
    print(f"  ✓ youtube: {plan.get('youtube')}")
    print(f"  ✓ model: {plan.get('model')}")
    print()
