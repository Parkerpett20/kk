# utils/logger.py
import logging
import os
from datetime import datetime


class AtomicFileHandler(logging.Handler):
    """A file handler that opens and closes the file on each emit.

    This avoids keeping file handles open between test cases which can
    prevent temporary directories from being removed on Windows.
    """

    def __init__(self, filename, mode='a', encoding=None, level=logging.NOTSET):
        super().__init__(level)
        self.filename = filename
        self.mode = mode
        self.encoding = encoding

    def emit(self, record):
        try:
            msg = self.format(record)
            # Open, write, and close per emit to avoid persistent file locks
            with open(self.filename, self.mode, encoding=self.encoding) as f:
                f.write(msg + "\n")
        except Exception:
            self.handleError(record)


def setup_logger(name: str = "karen") -> logging.Logger:
    """تنظیم سیستم logging حرفه‌ای برای پروژه

    This function ensures any existing handlers on the named logger are
    closed and removed before adding new ones. File handlers are implemented
    to open/close per emit to avoid Windows file locking issues in tests.
    """

    # ایجاد پوشه‌ی logs اگر وجود ندارد
    os.makedirs("logs", exist_ok=True)

    logger = logging.getLogger(name)

    # Close and remove any existing handlers to ensure fresh config
    if logger.handlers:
        for h in list(logger.handlers):
            try:
                h.close()
            except Exception:
                pass
            try:
                logger.removeHandler(h)
            except Exception:
                pass

    logger.setLevel(logging.DEBUG)

    # Format برای لاگ‌ها
    log_format = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    date_suffix = datetime.now().strftime('%Y%m%d')
    log_path = f"logs/karen_{date_suffix}.log"
    err_path = f"logs/errors_{date_suffix}.log"

    # File Handler - open/close per emit
    file_handler = AtomicFileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(log_format)
    logger.addHandler(file_handler)

    # Error Handler - فقط خطاها
    error_handler = AtomicFileHandler(err_path, encoding='utf-8')
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(log_format)
    logger.addHandler(error_handler)

    # Console Handler - برای development
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter('%(levelname)s - %(funcName)s - %(message)s')
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)

    # Prevent propagation to root logger to avoid duplicate logs
    logger.propagate = False

    return logger


# یک نمونه global logger
logger = setup_logger()
