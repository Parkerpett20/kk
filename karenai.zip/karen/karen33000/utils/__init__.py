# utils/__init__.py
from utils.logger import logger, setup_logger

__all__ = ['logger', 'setup_logger']
