# utils/message_context.py
import logging
from memory.telegram_profile import telegram_profile_manager

logger = logging.getLogger(__name__)


def extract_replied_text(message) -> str:
    """استخراج متن پیام ریپلای‌شده یا فورواردشده"""
    context_parts = []

    # بررسی ریپلای
    if message.reply_to_message:
        replied = message.reply_to_message
        replied_text = ""

        if replied.text:
            replied_text = replied.text
        elif replied.caption:
            replied_text = replied.caption
        elif replied.photo:
            replied_text = "[عکس]"
        elif replied.voice or replied.audio:
            replied_text = "[صوت]"
        elif replied.video:
            replied_text = "[ویدیو]"
        elif replied.document:
            file_name = replied.document.file_name or "document"
            replied_text = f"[سند: {file_name}]"
        elif replied.sticker:
            replied_text = f"[استیکر: {replied.sticker.emoji or ''}]"
        elif replied.animation:
            replied_text = "[گیف]"
        elif replied.poll:
            replied_text = f"[نظرسنجی: {replied.poll.question}]"

        if replied_text:
            sender = ""
            if replied.from_user:
                name = replied.from_user.first_name or replied.from_user.username or ""
                sender = f" از {name}" if name else ""
            context_parts.append(f"📌 پیام ریپلای‌شده{sender}:\n{replied_text}")

    # بررسی فوروارد
    if message.forward_from or message.forward_from_chat:
        forward_info = ""
        if message.forward_from:
            name = message.forward_from.first_name or message.forward_from.username or ""
            forward_info = f"از {name}"
        elif message.forward_from_chat:
            title = message.forward_from_chat.title or ""
            forward_info = f"از کانال/گروه {title}"

        if forward_info:
            context_parts.append(f"🔄 این پیام فوروارد شده {forward_info}.")

    if context_parts:
        return "\n\n".join(context_parts)

    return ""


def build_user_text_with_context(message, default_text: str = None) -> str:
    """ساخت متن کاربر با در نظر گرفتن ریپلای و فوروارد و پروفایل فرستنده"""
    # بی‌سروصدا پروفایل فرستنده رو استخراج و کش کن
    telegram_profile_manager.extract_from_message(message)
    
    user_text = default_text or message.text or message.caption or ""
    context = extract_replied_text(message)

    if context:
        if user_text:
            return f"{context}\n\n💬 پیام کاربر:\n{user_text}"
        else:
            return context

    return user_text
