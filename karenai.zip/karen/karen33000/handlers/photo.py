# handlers/photo.py
import telebot
from google.genai import types
from core.executor import AgentExecutor
from core.streaming import handle_stream_delivery
from handlers.group import group_manager
from utils.message_context import build_user_text_with_context

def register_photo_handler(bot: telebot.TeleBot):
    @bot.message_handler(content_types=['photo'])
    def on_photo(message):
        # ذخیره عکس در تاریخچه گروه
        if message.chat.type in ['group', 'supergroup']:
            try:
                username = message.from_user.username or message.from_user.first_name or "نامشخص"
                caption = message.caption or "[عکس]"
                group_manager.save_message(
                    chat_id=message.chat.id,
                    user_id=message.from_user.id,
                    username=username,
                    text=caption,
                    msg_type="photo"
                )
            except Exception as e:
                pass
        
        sent_msg = bot.reply_to(message, "⏳ دارم به عکست نگاه می‌کنم...")
        try:
            # دریافت باکیفیت‌ترین فرمت عکس ارسالی
            file_id = message.photo[-1].file_id
            file_info = bot.get_file(file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            
            image_part = types.Part.from_bytes(
                data=downloaded_file,
                mime_type="image/jpeg"
            )
            
            caption = message.caption or "این تصویر رو تحلیل کن."
            user_text = build_user_text_with_context(message, caption)
            stream, plan = AgentExecutor.run_stream(
                chat_id=message.chat.id,
                user_text=user_text,
                attachments=[image_part],
                user_id=message.from_user.id
            )
            
            status = "👁️ پردازش بینایی تصویر"
            bot.edit_message_text(f"[{status}]\n✍️...", message.chat.id, sent_msg.message_id)
            
            handle_stream_delivery(bot, message.chat.id, sent_msg.message_id, stream, user_text)
            
        except Exception as e:
            bot.edit_message_text(f"❌ خطا در پردازش تصویر:\n{str(e)}", message.chat.id, sent_msg.message_id)