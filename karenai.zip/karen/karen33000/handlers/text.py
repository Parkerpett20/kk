# handlers/text.py
import telebot
import logging
import re
from datetime import datetime
from core.executor import AgentExecutor
from core.streaming import handle_stream_delivery
from handlers.group import group_manager
from utils.message_context import build_user_text_with_context
from core.languages import get_text, get_language
from memory.telegram_profile import telegram_profile_manager
from memory.user_profile import UserProfileManager

logger = logging.getLogger(__name__)

# الگوهای تشخیص سوالات مربوط به اعضای گروه
MEMBER_COUNT_PATTERNS = [
    r"چند\s*نفر",
    r"تعداد\s*اعضا",
    r"تعداد\s*اعضای\s*گروه",
    r"چند\s*تا\s*عضو",
    r"چند\s*نفر\s*هستن",
    r"چند\s*نفر\s*هستند",
    r"تعداد\s*کل",
    r"چقدر\s*عضو",
    r"member\s*count",
    r"how\s*many\s*members",
]

ADMIN_LIST_PATTERNS = [
    r"کیا?\s*ادمین",
    r"لیست\s*ادمین",
    r"ادمین\s*های\s*گروه",
    r"چه\s*کسانی\s*ادمین",
    r"کی\s*ادمین\s*هست",
    r"admin\s*list",
    r"who\s*are\s*admins",
]

MEMBER_LIST_PATTERNS = [
    r"لیست\s*اعضا",
    r"اعضای\s*گروه",
    r"چه\s*کسانی\s*عضو",
    r"کیا?\s*عضو",
    r"member\s*list",
    r"who\s*are\s*members",
]

def check_member_count_query(text: str) -> bool:
    """بررسی آیا متن سوال تعداد اعضا است"""
    text_lower = text.lower()
    for pattern in MEMBER_COUNT_PATTERNS:
        if re.search(pattern, text_lower):
            return True
    return False

def check_admin_list_query(text: str) -> bool:
    """بررسی آیا متن سوال لیست ادمین است"""
    text_lower = text.lower()
    for pattern in ADMIN_LIST_PATTERNS:
        if re.search(pattern, text_lower):
            return True
    return False

def check_member_list_query(text: str) -> bool:
    """بررسی آیا متن سوال لیست اعضا است"""
    text_lower = text.lower()
    for pattern in MEMBER_LIST_PATTERNS:
        if re.search(pattern, text_lower):
            return True
    return False

def get_member_count_response(bot, chat_id: int, user_id: int) -> str:
    """دریافت تعداد اعضا"""
    try:
        member_count = bot.get_chat_member_count(chat_id)
        return get_text(user_id, "member_count", count=member_count)
    except Exception as e:
        return get_text(user_id, "member_count_error")

def get_admin_list_response(bot, chat_id: int, user_id: int) -> str:
    """دریافت لیست ادمین‌ها"""
    try:
        admins = bot.get_chat_administrators(chat_id)
        if not admins:
            return get_text(user_id, "no_admins")
        
        admin_list = ""
        for i, admin in enumerate(admins, 1):
            name = admin.user.first_name or "نامشخص"
            username = admin.user.username
            status = get_text(user_id, "admin_status_creator") if admin.status == 'creator' else get_text(user_id, "admin_status_admin")
            if username:
                admin_list += f"{i}. [{name}](https://t.me/{username}) - {status}\n"
            else:
                no_username = get_text(user_id, "no_username")
                admin_list += f"{i}. {name} ({no_username}) - {status}\n"
        
        return get_text(user_id, "admin_list", count=len(admins), admins=admin_list)
    except Exception as e:
        return get_text(user_id, "admin_list_error")

def is_mentioned_in_group(message, bot_username, bot_id):
    """بررسی آیا ربات در گروه صدا زده شده است (هوشمند)"""
    text = message.text.lower()
    
    # نام‌هایی که با آن‌ها ربات صدا زده می‌شود
    # هم با @ و هم بدون @
    bot_username_clean = bot_username.lower().replace("@", "")
    bot_names = ["کارن", "karin", bot_username_clean, f"@{bot_username_clean}"]
    
    # بررسی اگر پاسخ به پیام ربات است
    if message.reply_to_message and message.reply_to_message.from_user.id == bot_id:
        return True
    
    # بررسی اگر نام ربات در متن آمده (هم با @ و هم بدون @)
    for name in bot_names:
        if name in text:
            return True
    
    # بررسی entities تلگرام (برای منشن‌های رسمی)
    if message.entities:
        for entity in message.entities:
            if entity.type == 'mention':  # منشن مثل @username
                # استفاده از متن اصلی (نه lowercased) برای offset صحیح
                mention_text = message.text[entity.offset:entity.offset + entity.length]
                if mention_text.lower() == f"@{bot_username_clean}":
                    return True
            elif entity.type == 'text_mention':  # منشن برای کاربران بدون یوزرنیم
                if entity.user and entity.user.id == bot_id:
                    return True
    
    # بررسی هوشمند: اگر پیام قبلی از کارن باشه و کسی جواب بده
    try:
        recent_messages = group_manager.get_messages(message.chat.id, limit=3)
        if recent_messages:
            last_msg = recent_messages[-1]
            # اگر آخرین پیام از کارن باشه (یوزرنیم ربات یا شناسه 0)
            if last_msg.get("username") == "کارن" or last_msg.get("user_id") == 0:
                return True
    except Exception as e:
        pass
    
    return False

def is_introduction_message(message, bot_id):
    """بررسی آیا پیام معرفی کاربر جدید است"""
    # اگر پاسخ به پیام خوش‌آمدگویی ربات باشد
    if not message.reply_to_message:
        return False
    
    if message.reply_to_message.from_user.id != bot_id:
        return False
    
    # بررسی اینکه آیا پیام ربات حاوی متن خوش‌آمدگویی بوده
    welcome_keywords = ["خوش اومدی", "معرفی کن", "آشنا بشیم"]
    reply_text = message.reply_to_message.text or ""
    
    for keyword in welcome_keywords:
        if keyword in reply_text:
            return True
    
    return False

def is_new_member_introduction(message, bot_id, chat_id):
    """بررسی آیا کاربر جدیدی که اخیراً وارد شده در حال معرفی خود است"""
    # بررسی اگر کاربر در 10 دقیقه اخیر وارد گروه شده باشد
    from handlers.group import group_manager
    import time
    
    group = group_manager._load_group(chat_id)
    current_time = time.time()
    
    for member in group.get("members", []):
        if member.get("user_id") == message.from_user.id:
            # بررسی اگر کاربر در 10 دقیقه اخیر وارد شده باشد
            joined_at = member.get("joined_at")
            if joined_at:
                try:
                    from datetime import datetime
                    joined_time = datetime.fromisoformat(joined_at).timestamp()
                    if current_time - joined_time < 600:  # 10 دقیقه
                        return True
                except:
                    pass
    return False

def save_user_introduction(chat_id: int, user_id: int, username: str, first_name: str, introduction: str):
    """ذخیره معرفی کاربر جدید"""
    from handlers.group import group_manager
    
    group = group_manager._load_group(chat_id)
    
    # پیدا کردن عضو و اضافه کردن معرفی
    for member in group.get("members", []):
        if member.get("user_id") == user_id:
            member["introduction"] = introduction
            member["last_seen"] = datetime.now().isoformat()
            group_manager._save_group(chat_id, group)
            logger.info(f"معرفی کاربر {username} ذخیره شد")
            return
    
    # اگر عضو پیدا نشد، اضافه کن
    if "members" not in group:
        group["members"] = []
    
    group["members"].append({
        "user_id": user_id,
        "username": username,
        "name": first_name,
        "introduction": introduction,
        "joined_at": datetime.now().isoformat(),
        "last_seen": datetime.now().isoformat()
    })
    group_manager._save_group(chat_id, group)
    logger.info(f"عضو جدید با معرفی ذخیره شد: {username}")

def register_text_handler(bot: telebot.TeleBot):
    _bot_info = {"username": None, "id": None}

    def get_bot_info():
        if _bot_info["username"] is None:
            info = bot.get_me()
            _bot_info["username"] = info.username
            _bot_info["id"] = info.id
        return _bot_info
    
    @bot.message_handler(content_types=['text'], func=lambda m: not m.text.startswith('/'))
    def on_text(message):
        
        # دریافت اطلاعات ربات (lazy)
        info = get_bot_info()
        bot_username = info["username"]
        bot_id = info["id"]
        
        # ذخیره پیام در تاریخچه گروه (فقط برای گروه‌ها)
        if message.chat.type in ['group', 'supergroup']:
            try:
                username = message.from_user.username or message.from_user.first_name or "نامشخص"
                group_manager.save_message(
                    chat_id=message.chat.id,
                    user_id=message.from_user.id,
                    username=username,
                    text=message.text,
                    msg_type="text"
                )
            except Exception as e:
                pass  # خطا در ذخیره پیام ربات را متوقف نمی‌کند
            
            # بررسی و ذخیره معرفی کاربر جدید (بی‌سروصدا)
            if is_introduction_message(message, bot_id) or is_new_member_introduction(message, bot_id, message.chat.id):
                try:
                    user = message.from_user
                    save_user_introduction(
                        chat_id=message.chat.id,
                        user_id=user.id,
                        username=user.username or "",
                        first_name=user.first_name or "",
                        introduction=message.text
                    )
                except Exception as e:
                    pass
        
        # بررسی اگر در گروه هستیم و ربات صدا زده نشده
        if message.chat.type in ['group', 'supergroup']:
            if not is_mentioned_in_group(message, bot_username, bot_id):
                return
            
            # بررسی سوالات مربوط به اعضا و ادمین‌ها (قبل از ارسال به هوش مصنوعی)
            text = message.text.strip()
            
            # سوال تعداد اعضا
            if check_member_count_query(text):
                response = get_member_count_response(bot, message.chat.id, message.from_user.id)
                bot.reply_to(message, response)
                return
            
            # سوال لیست ادمین‌ها
            if check_admin_list_query(text):
                response = get_admin_list_response(bot, message.chat.id, message.from_user.id)
                bot.reply_to(message, response)
                return
            
            # سوال لیست اعضا - پیشنهاد دستور
            if check_member_list_query(text):
                response = get_text(message.from_user.id, "member_list_help")
                bot.reply_to(message, response)
                return
        
        user_id = message.from_user.id
        processing_text = get_text(user_id, "processing")
        sent_msg = bot.reply_to(message, processing_text)
        
        try:
            user_text = build_user_text_with_context(message)
            stream, plan = AgentExecutor.run_stream(message.chat.id, user_text, chat_type=message.chat.type, user_id=user_id)
            
            # نشان دادن وضعیت مدل انتخابی به کاربر
            if plan["thinking"] == "HIGH":
                status = get_text(user_id, "thinking_deep")
            else:
                status = get_text(user_id, "quick_response")
            bot.edit_message_text(f"{status}...\n✍️...", message.chat.id, sent_msg.message_id)
            
            handle_stream_delivery(bot, message.chat.id, sent_msg.message_id, stream, user_text)
            
            # بی‌سروصدا استخراج حقایق از پیام کاربر
            try:
                user_profile = UserProfileManager()
                user_profile.extract_and_update(message.text or "")
                # ذخیره حقایق استخراج شده در پروفایل تلگرام هم
                if user_profile.profile.get("extracted_facts"):
                    for fact in user_profile.profile["extracted_facts"][-3:]:
                        telegram_profile_manager.store_fact(user_id, fact)
                
                # بررسی تغییر عکس پروفایل
                had_previous_photo = telegram_profile_manager.has_profile_photo(user_id)
                
                if telegram_profile_manager.check_profile_photo_changed(bot, user_id):
                    # عکس پروفایل تغییر کرده!
                    new_photo_path = telegram_profile_manager.fetch_profile_photo(bot, user_id)
                    
                    if had_previous_photo:
                        # کاربر قبلاً عکس داشته و الان عوضش کرده
                        compliments = [
                            "وای! عکس پروفایلتو عوض کردی، خیلی قشنگ شده! 😍",
                            "عکس جدیدت عالیه! حسابی بهت میاد! ✨",
                            "چه تغییر خوبی! عکست خیلی باحال شده! 🔥",
                            "عکس پروفایل جدیدت حرف نداره! خیلی شیک شده! 💫",
                            "عکستو عوض کردی؟ خیلی بهتر شده! آفرین! 👏"
                        ]
                    else:
                        # کاربر اولین بار عکس گذاشته
                        compliments = [
                            "بالاخره عکس پروفایل گذاشتی! خیلی قشنگه! 😊",
                            "عکس پروفایل داری! حسابی بهت میاد! ✨",
                            "خوشگله! عکس پروفایلت عالیه! 💫"
                        ]
                    
                    import random
                    compliment = random.choice(compliments)
                    
                    # ارسال پیام تبریک با عکس
                    if new_photo_path and os.path.exists(new_photo_path):
                        try:
                            with open(new_photo_path, 'rb') as photo:
                                bot.send_photo(message.chat.id, photo, caption=compliment)
                        except Exception:
                            bot.reply_to(message, compliment)
                    else:
                        bot.reply_to(message, compliment)
                    
                    # بروزرسانی زمان تغییر عکس
                    telegram_profile_manager.update_photo_change_timestamp(user_id, had_previous_photo)
                else:
                    # اگر عکس نداشته، دریافت کن
                    if not had_previous_photo:
                        telegram_profile_manager.fetch_profile_photo(bot, user_id)
            except Exception:
                pass
                
        except Exception as e:
            error_text = get_text(user_id, "error")
            bot.edit_message_text(f"{error_text}\n{str(e)}", message.chat.id, sent_msg.message_id)