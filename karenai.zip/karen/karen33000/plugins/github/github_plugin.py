# plugins/github/github_plugin.py
import urllib.request
import json

def fetch_github_user_profile(username: str) -> str:
    """Gets public profile information of a GitHub user.
    Args:
        username: The exact GitHub username (e.g., 'aimahdix').
    """
    url = f"https://api.github.com/users/{username}"
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as res:
            data = json.loads(res.read().decode('utf-8'))
            return (
                f"GitHub User: {data.get('login')}\n"
                f"Name: {data.get('name', 'N/A')}\n"
                f"Bio: {data.get('bio', 'N/A')}\n"
                f"Public Repos: {data.get('public_repos')} | Followers: {data.get('followers')}"
            )
    except Exception as e:
        return f"Failed to fetch GitHub profile: {str(e)}"