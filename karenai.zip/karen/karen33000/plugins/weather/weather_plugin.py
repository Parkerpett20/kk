# plugins/weather/weather_plugin.py
import urllib.request
import urllib.parse
import json

def fetch_weather(city: str) -> str:
    """Gets the current, real-time weather temperature and wind speed for a given city.
    Args:
        city: The name of the city (e.g., 'Tehran', 'London').
    """
    try:
        # ۱. تبدیل نام شهر به مختصات جغرافیایی (عرض و طول جغرافیایی)
        geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={urllib.parse.quote(city)}&count=1&format=json"
        req = urllib.request.Request(geo_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as geo_res:
            geo_data = json.loads(geo_res.read().decode('utf-8'))
            results = geo_data.get("results")
            if not results:
                return f"Could not find coordinates for city: {city}"
            lat = results[0]["latitude"]
            lon = results[0]["longitude"]
            name = results[0]["name"]
            country = results[0].get("country", "")

        # ۲. دریافت مستقیم اطلاعات آب و هوا از Open-Meteo
        weather_url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"
        with urllib.request.urlopen(weather_url, timeout=10) as weather_res:
            weather_data = json.loads(weather_res.read().decode('utf-8'))
            current = weather_data.get("current_weather", {})
            temp = current.get("temperature")
            wind = current.get("windspeed")
            return f"Weather in {name}, {country}: Temperature: {temp}°C, Wind Speed: {wind} km/h."
    except Exception as e:
        return f"Failed to fetch weather for {city}: {str(e)}"