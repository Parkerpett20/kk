# plugins/calendar/calendar_plugin.py
import datetime

def get_gregorian_calendar_details() -> str:
    """Returns the current Gregorian date, day of the week, day of the year, and if it is a leap year."""
    now = datetime.datetime.now()
    weekday = now.strftime("%A")
    day_of_year = now.timetuple().tm_yday
    
    # ارزیابی سال کبیسه میلادی
    year = now.year
    is_leap = (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)
    leap_str = "Yes" if is_leap else "No"
    
    return (
        f"Gregorian Date: {now.strftime('%Y-%m-%d')}\n"
        f"Day of Week: {weekday}\n"
        f"Day of Year: {day_of_year}/365\n"
        f"Is Leap Year: {leap_str}"
    )