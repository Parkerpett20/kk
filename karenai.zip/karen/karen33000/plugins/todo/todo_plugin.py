# plugins/todo/todo_plugin.py
import os
import json

TODO_FILE = "data/todos.json"

def _ensure_todo_dir():
    os.makedirs(os.path.dirname(TODO_FILE), exist_ok=True)

def add_todo_item(task: str) -> str:
    """Adds a new task to the user's TODO list.
    Args:
        task: The task description.
    """
    _ensure_todo_dir()
    todos = []
    if os.path.exists(TODO_FILE):
        try:
            with open(TODO_FILE, "r", encoding="utf-8") as f:
                todos = json.load(f)
        except Exception:
            pass
    
    todos.append({"task": task, "completed": False})
    with open(TODO_FILE, "w", encoding="utf-8") as f:
        json.dump(todos, f, ensure_ascii=False, indent=4)
    return f"Added task: '{task}' to your TODO list."

def list_todo_items() -> str:
    """Lists all tasks currently on the TODO list, indicating if they are completed."""
    _ensure_todo_dir()
    if not os.path.exists(TODO_FILE):
        return "Your TODO list is currently empty."
    try:
        with open(TODO_FILE, "r", encoding="utf-8") as f:
            todos = json.load(f)
        if not todos:
            return "Your TODO list is empty."
        
        output = []
        for idx, item in enumerate(todos, 1):
            status = "✅" if item["completed"] else "❌"
            output.append(f"{idx}. {item['task']} [{status}]")
        return "Your TODO list:\n" + "\n".join(output)
    except Exception as e:
        return f"Error reading TODO list: {str(e)}"

def complete_todo_item(index: int) -> str:
    """Marks a specific task on the TODO list as completed by its list index (1-based index).
    Args:
        index: The 1-based index of the task to complete (e.g. 1).
    """
    _ensure_todo_dir()
    if not os.path.exists(TODO_FILE):
        return "Your TODO list is empty."
    try:
        with open(TODO_FILE, "r", encoding="utf-8") as f:
            todos = json.load(f)
        
        idx = index - 1
        if 0 <= idx < len(todos):
            todos[idx]["completed"] = True
            with open(TODO_FILE, "w", encoding="utf-8") as f:
                json.dump(todos, f, ensure_ascii=False, indent=4)
            return f"Task '{todos[idx]['task']}' marked as completed."
        return "Invalid task index."
    except Exception as e:
        return f"Error updating TODO list: {str(e)}"