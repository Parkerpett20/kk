# plugins/notes/notes_plugin.py
import os
import json

NOTES_FILE = "data/notes.json"

def _ensure_notes_dir():
    os.makedirs(os.path.dirname(NOTES_FILE), exist_ok=True)

def save_note(title: str, content: str) -> str:
    """Saves or appends a note with a given title and content.
    Args:
        title: Title of the note.
        content: Content/body of the note.
    """
    _ensure_notes_dir()
    notes = {}
    if os.path.exists(NOTES_FILE):
        try:
            with open(NOTES_FILE, "r", encoding="utf-8") as f:
                notes = json.load(f)
        except Exception:
            pass
    
    notes[title] = content
    with open(NOTES_FILE, "w", encoding="utf-8") as f:
        json.dump(notes, f, ensure_ascii=False, indent=4)
    return f"Note titled '{title}' successfully saved."

def read_note(title: str) -> str:
    """Retrieves the content of a specific note by its title.
    Args:
        title: The title of the note to retrieve.
    """
    _ensure_notes_dir()
    if not os.path.exists(NOTES_FILE):
        return "No notes have been created yet."
    try:
        with open(NOTES_FILE, "r", encoding="utf-8") as f:
            notes = json.load(f)
        if title in notes:
            return f"--- Note: {title} ---\n{notes[title]}"
        return f"Note titled '{title}' not found."
    except Exception as e:
        return f"Error reading notes: {str(e)}"