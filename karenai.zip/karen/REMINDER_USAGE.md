# REMINDER_USAGE.md
# 📅 راهنمای سیستم یادآوری هوشمند

## 🎯 ویژگی‌ها

✅ **برنامه‌ریزی خودکار یادآوری‌ها** - در ساعت مشخص پیام ارسال کند
✅ **اطلاع پیشگی** - 1 ساعت قبل از یادآوری اطلاع بده
✅ **ذخیره‌سازی دائمی** - یادآوری‌ها در فایل JSON ذخیره می‌شوند
✅ **لیست و مدیریت** - نمایش و حذف یادآوری‌ها
✅ **پشتیبانی فارسی** - دستورات به فارسی

---

## 📝 دستورات دستی

### 1️⃣ **ثبت یادآوری**

فرمت‌های مختلف:

```
یادآوری کن که دارو بخور در ساعت 08:00
یادآوری جلسه مهم ساعت 14:30
برایم یادآوری کن که میتینگ مدیریت در ساعت 10:30
```

✨ **مثال‌های عملی:**
- `یادآوری کن که صبحانه بخور در ساعت 07:30`
- `یادآوری تمام‌کردن پروژه ساعت 18:00`
- `یادآوری برای زنگ دادن مامان در ساعت 16:45`

**نتیجه:**
```
✅ یادآوری ثبت شد!
📝 متن: دارو بخور
⏰ زمان: 2026-06-22 08:00
🔔 اطلاع: 1 ساعت قبل

🆔 ID: 123456789_1687432800
```

---

### 2️⃣ **مشاهده یادآوری‌های بعدی**

```
یادآوری‌های من
یادآوری‌های خود
لیست یادآوری‌ها
```

**نتیجه:**
```
📋 یادآوری‌های شما:

1️⃣ دارو بخور
⏰ 2026-06-22 08:00
🆔 ID: reminder_id_123

2️⃣ صبحانه بخور
⏰ 2026-06-22 07:30
🆔 ID: reminder_id_124
```

---

### 3️⃣ **حذف یادآوری**

```
/delete_reminder reminder_id_123
```

**نتیجه:**
```
✅ یادآوری reminder_id_123 حذف شد
```

---

## 🔧 کوریستاج برنامه‌نویسی

### استفاده در کد:

```python
from core.scheduler import reminder_scheduler
from datetime import datetime, timedelta
import pytz

# ایجاد یادآوری
tz = pytz.timezone('Asia/Tehran')
tomorrow = datetime.now(tz) + timedelta(days=1)
reminder_time = tomorrow.replace(hour=9, minute=0)

reminder_id = reminder_scheduler.add_reminder(
    user_id=123456789,
    message="تمام‌کردن گزارش",
    run_time=reminder_time,
    notify_before_minutes=60  # اطلاع 1 ساعت قبل
)

print(f"✅ یادآوری ثبت شد: {reminder_id}")

# فعال‌سازی scheduler
reminder_scheduler.start()

# مشاهده یادآوری‌های آینده
pending = reminder_scheduler.get_pending_reminders(user_id=123456789)
for reminder in pending:
    print(f"⏰ {reminder.message} - {reminder.run_time}")

# حذف یادآوری
reminder_scheduler.delete_reminder(reminder_id)
```

---

## 📊 ذخیره‌سازی

یادآوری‌ها در فایل `data/reminders.json` ذخیره می‌شوند:

```json
{
  "123456789_1687432800": {
    "user_id": 123456789,
    "message": "دارو بخور",
    "run_time": "2026-06-22T08:00:00+03:30",
    "reminder_id": "123456789_1687432800",
    "enabled": true,
    "created_at": "2026-06-22T10:30:00"
  }
}
```

---

## ⚙️ تنظیمات پیشرفته

### تغییر منطقه زمانی:

```python
from core.scheduler import ReminderScheduler
import pytz

scheduler = ReminderScheduler()
# تنظیم منطقه‌ی زمانی برای Tehran
# (از پیش تنظیم شده است)
```

### Callback سفارشی:

```python
def my_reminder_callback(user_id, message):
    print(f"📬 یادآوری برای {user_id}: {message}")

reminder_scheduler.set_callback(my_reminder_callback)
```

---

## 🐛 عیب‌یابی

### مشکل: یادآوری ارسال نمی‌شود
- ✅ مطمئن شوید scheduler فعال است: `reminder_scheduler.start()`
- ✅ callback تنظیم شده است
- ✅ زمان سیستم درست باشد

### مشکل: خطای "timezone"
- ✅ از `pytz.timezone('Asia/Tehran')` استفاده کنید
- ✅ مطمئن شوید تمام تاریخ‌ها timezone-aware هستند

---

## 📦 فایل‌های مرتبط

- `core/scheduler.py` - منطق اصلی scheduler
- `handlers/reminder.py` - handler تلگرام
- `data/reminders.json` - ذخیره‌سازی یادآوری‌ها
- `main.py` - یکپارچگی با ربات اصلی

---

✨ **حالا می‌تونی هر ساعتی برات یادآوری ارسال کن!**
