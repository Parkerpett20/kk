import sqlite3
import json
import sys
import io
from datetime import datetime

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

conn = sqlite3.connect(r'C:\Users\ASUS\.local\share\mimocode\mimocode.db')
c = conn.cursor()

# Get detailed write operations from recent sessions
recent_sessions = [
    'ses_0c432f80bffeorUeGzaLweBpbj',
    'ses_0ce35f620ffeFJuoapZnDNI2BW', 
    'ses_0ce3895d8ffenwfnAqRYD2azVa'
]

for sid in recent_sessions:
    print(f"\n{'='*80}")
    print(f"SESSION: {sid}")
    print('='*80)
    
    # Get all parts with tool calls
    c.execute("""
        SELECT p.id, json_extract(p.data, '$.type') as part_type, 
               json_extract(p.data, '$.tool') as tool,
               json_extract(p.data, '$.state.input') as input_data,
               json_extract(p.data, '$.state.output') as output_data
        FROM part p 
        WHERE p.session_id = ? 
          AND json_extract(p.data, '$.type') = 'tool'
        ORDER BY p.time_created
    """, (sid,))
    
    for part in c.fetchall():
        part_id, part_type, tool, input_data, output_data = part
        
        if tool in ('write', 'edit'):
            print(f"\n--- TOOL: {tool.upper()} ---")
            try:
                if input_data:
                    inp = json.loads(input_data)
                    if 'filePath' in inp:
                        print(f"  File: {inp['filePath']}")
                    if 'content' in inp:
                        content = inp['content'][:300] if inp['content'] else ''
                        print(f"  Content preview: {content}...")
                    if 'oldString' in inp:
                        print(f"  Edit - oldString: {inp['oldString'][:100]}...")
                        print(f"  Edit - newString: {inp.get('newString', '')[:100]}...")
            except Exception as e:
                print(f"  Error parsing: {e}")
        
        elif tool == 'bash':
            print(f"\n--- TOOL: BASH ---")
            try:
                if input_data:
                    inp = json.loads(input_data)
                    if 'command' in inp:
                        print(f"  Command: {inp['command'][:200]}")
                if output_data:
                    out = json.loads(output_data)
                    if 'stdout' in out:
                        stdout = out['stdout'][:200] if out['stdout'] else ''
                        print(f"  Output: {stdout}")
            except Exception as e:
                print(f"  Error parsing: {e}")
        
        elif tool == 'read':
            print(f"\n--- TOOL: READ ---")
            try:
                if input_data:
                    inp = json.loads(input_data)
                    if 'filePath' in inp:
                        print(f"  File: {inp['filePath']}")
            except Exception as e:
                print(f"  Error parsing: {e}")

conn.close()
