import os
import asyncio
import threading
import logging
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

load_dotenv()

_api_id = os.getenv("TELETHON_API_ID")
_api_hash = os.getenv("TELETHON_API_HASH")

_loop = None
_loop_thread = None
_clients = {}  # user_id -> TelegramClient
_pending = {}  # user_id -> {'client': client, 'phone': phone}
_sessions_dir = "data/user_sessions"


def _get_or_create_loop():
    global _loop, _loop_thread
    if _loop is not None and _loop.is_running():
        return _loop
    _loop = asyncio.new_event_loop()
    _loop_thread = threading.Thread(target=_loop.run_forever, daemon=True)
    _loop_thread.start()
    return _loop


def _run_async(coro, timeout=60):
    loop = _get_or_create_loop()
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result(timeout=timeout)


def is_available() -> bool:
    return bool(_api_id and _api_hash)


def _get_session_path(user_id: int) -> str:
    os.makedirs(_sessions_dir, exist_ok=True)
    return f"{_sessions_dir}/session_{user_id}"


def _session_exists(user_id: int) -> bool:
    """بررسی آیا فایل سشن برای کاربر وجود دارد"""
    session_path = _get_session_path(user_id)
    # Telethon session files have .session extension
    return os.path.exists(session_path + ".session")


def normalize_phone(phone_number: str) -> str:
    """نرمالایز شماره تلفن به فرمت بین‌المللی"""
    phone = phone_number.strip().replace(" ", "").replace("-", "").replace("(", "").replace(")", "")

    if phone.startswith("00"):
        phone = "+" + phone[2:]
    elif phone.startswith("0") and not phone.startswith("00"):
        phone = "+98" + phone[1:]
    elif not phone.startswith("+"):
        phone = "+98" + phone

    return phone


def start_sign_in(user_id: int, phone: str) -> tuple:
    """Start sign-in flow for a given user phone. Sends code to phone.

    Returns:
        tuple: (success: bool, error_message: str or None)
    """
    if not is_available():
        logger.warning("Telethon API credentials not configured")
        return (False, "Telethon پیکربندی نشده است. لطفاً با ادمین تماس بگیرید.")

    # نرمالایز شماره تلفن
    phone = normalize_phone(phone)
    logger.info(f"Normalized phone for user {user_id}: {phone}")

    async def _start():
        try:
            from telethon import TelegramClient

            # پاکسازی pending قبلی اگر وجود دارد (جلوگیری از نشت منابع)
            if user_id in _pending:
                old_client = _pending[user_id].get('client')
                if old_client:
                    try:
                        await old_client.disconnect()
                    except Exception:
                        pass
                del _pending[user_id]

            session = _get_session_path(user_id)
            client = TelegramClient(session, int(_api_id), _api_hash)
            await client.connect()
            # send code request
            await client.send_code_request(phone)
            _pending[user_id] = {'client': client, 'phone': phone}
            logger.info(f"Sent sign-in code request for user {user_id} -> {phone}")
            return (True, None)
        except Exception as e:
            error_str = str(e)
            logger.error(f"Error sending code request for user {user_id}: {e}")
            # قطع اتصال کلاینت در صورت خطا برای جلوگیری از نشت منابع
            try:
                if 'client' in dir():
                    await client.disconnect()
            except Exception:
                pass
            # پیام‌های خطای رایج Telethon
            if "PhoneNumberBannedError" in error_str or "banned" in error_str.lower():
                return (False, "این شماره توسط تلگرام مسدود شده است.")
            elif "FloodWait" in error_str:
                # استخراج زمان انتظار
                import re
                match = re.search(r'(\d+)', error_str)
                wait_time = match.group(1) if match else "?"
                return (False, f"تلگرام محدودیت گذاشته است. لطفاً {wait_time} ثانیه صبر کنید و دوباره تلاش کنید.")
            elif "PhoneNumberUnoccupiedError" in error_str:
                return (False, "این شماره در تلگرام ثبت نشده است.")
            elif "ApiIdInvalidError" in error_str or "api_id" in error_str.lower():
                return (False, "API ID یا API Hash نامعتبر است. لطفاً با ادمین تماس بگیرید.")
            elif "PhoneNumberInvalidError" in error_str:
                return (False, "فرمت شماره تلفن نامعتبر است.")
            else:
                return (False, f"خطا در ارسال کد: {error_str}")

    try:
        return _run_async(_start())
    except Exception as e:
        logger.error(f"start_sign_in error: {e}")
        return (False, f"خطای غیرمنتظره: {str(e)}")


def _is_code_previously_shared_error(error_str: str) -> bool:
    """بررسی آیا خطا مربوط به اشتراک‌گذاری قبلی کد توسط اکانت است.

    تلگرام وقتی کاربر کد ورود را در یک پیام تلگرامی ارسال کند (مثلاً به ربات)،
    این کد را 'قبلاً اشتراک‌گذاری شده' در نظر می‌گیرد و ورود را مسدود می‌کند.
    """
    error_lower = error_str.lower()
    indicators = [
        "previously shared",
        "code was previously shared",
        "FreshResetAuthorisationForbidden",
        "AUTH_KEY_UNREGISTERED",
        "sign in was not allowed",
        "the code was entered correctly, but sign in was not allowed",
    ]
    return any(ind.lower() in error_lower for ind in indicators)


def resend_code_sms(user_id: int) -> tuple:
    """درخواست مجدد کد تایید از طریق SMS (force_sms=True).

    این تابع وقتی استفاده می‌شود که کد قبلی توسط سیستم امنیتی تلگرام مسدود شده
    باشد (چون کاربر کد را در چت تلگرام تایپ کرده بود). با force_sms=True کد جدید
    از طریق پیامک ارسال می‌شود، نه از طریق اپ تلگرام، تا مشکل 'previously shared'
    پیش نیاید.

    Returns:
        tuple: (success: bool, error_message: str or None)
    """
    if user_id not in _pending:
        logger.warning(f"No pending sign-in for user {user_id} (resend_code_sms)")
        return (False, "درخواست ورود یافت نشد. لطفاً دوباره شماره تلفن وارد کنید.")

    pending = _pending[user_id]
    client = pending['client']
    phone = pending['phone']

    async def _resend():
        try:
            # درخواست کد جدید با force_sms=True برای ارسال از طریق پیامک
            await client.send_code_request(phone, force_sms=True)
            logger.info(f"Resent sign-in code via SMS for user {user_id} -> {phone}")
            return (True, None)
        except Exception as e:
            error_str = str(e)
            logger.error(f"Error resending code via SMS for user {user_id}: {e}")
            if "FloodWait" in error_str:
                import re
                match = re.search(r'(\d+)', error_str)
                wait_time = match.group(1) if match else "?"
                return (False, f"تلگرام محدودیت گذاشته است. لطفاً {wait_time} ثانیه صبر کنید.")
            elif "PhoneNumberBannedError" in error_str or "banned" in error_str.lower():
                return (False, "این شماره توسط تلگرام مسدود شده است.")
            else:
                return (False, f"خطا در ارسال مجدد کد: {error_str}")

    try:
        return _run_async(_resend())
    except Exception as e:
        logger.error(f"resend_code_sms error: {e}")
        return (False, f"خطای غیرمنتظره: {str(e)}")


def complete_sign_in(user_id: int, code: str) -> tuple:
    """Complete sign-in with the code received by the phone.

    Returns:
        tuple: (success: bool, error_message: str or None)

    Note: error_message can be the special string "NEED_2FA_PASSWORD" or
    "NEED_RESEND_SMS" to signal the caller to take a specific action.
    """
    if user_id not in _pending:
        logger.warning(f"No pending sign-in for user {user_id}")
        return (False, "درخواست ورود یافت نشد. لطفاً دوباره شماره تلفن وارد کنید.")

    pending = _pending[user_id]
    client = pending['client']

    # پاکسازی کد (حذف فاصله، خط تیره و کاراکترهای اضافی)
    code = code.strip().replace(" ", "").replace("-", "").replace("_", "")

    async def _complete():
        try:
            await client.sign_in(code=code)

            # ⚠️ بررسی حیاتی: حتی اگر sign_in بدون خطا برگشت، ممکن است
            # تلگرام ورود را مسدود کرده باشد (مثلاً "code was previously shared")
            # بدون اینکه exception پرتاب کند. پس باید واقعاً بررسی کنیم.
            is_auth = await client.is_user_authorized()
            if not is_auth:
                logger.warning(f"sign_in returned but user {user_id} is NOT authorized - Telegram blocked the login")
                # کلاینت را نگه می‌داریم برای احتمال ارسال مجدد کد
                return (False, "NEED_RESEND_SMS")

            # keep client running / authorized
            _clients[user_id] = client
            del _pending[user_id]
            logger.info(f"Userbot signed in for user {user_id}")
            return (True, None)
        except Exception as e:
            error_str = str(e)
            logger.error(f"Error completing sign-in for user {user_id}: {e}")

            # خطای "کد قبلاً اشتراک‌گذاری شده" - تلگرام ورود را مسدود کرده
            if _is_code_previously_shared_error(error_str):
                logger.warning(f"Code was previously shared for user {user_id}, need SMS resend")
                return (False, "NEED_RESEND_SMS")

            # خطاهای رایج
            if "PhoneCodeInvalidError" in error_str or ("phone code" in error_str.lower() and "invalid" in error_str.lower()):
                return (False, "کد وارد شده نامعتبر است. لطفاً کد صحیح را از تلگرام وارد کنید.")
            elif "PhoneCodeExpiredError" in error_str or "expired" in error_str.lower():
                return (False, "کد منقضی شده است. لطفاً دوباره شماره تلفن وارد کنید تا کد جدید ارسال شود.")
            elif "SessionPasswordNeededError" in error_str or ("password" in error_str.lower() and "needed" in error_str.lower()):
                # نیاز به رمز عبور 2FA - کلاینت را نگه می‌داریم
                return (False, "NEED_2FA_PASSWORD")
            elif "FloodWait" in error_str:
                import re
                match = re.search(r'(\d+)', error_str)
                wait_time = match.group(1) if match else "?"
                return (False, f"تلگرام محدودیت گذاشته است. لطفاً {wait_time} ثانیه صبر کنید.")
            else:
                return (False, f"خطا در ورود: {error_str}")

    try:
        return _run_async(_complete())
    except Exception as e:
        logger.error(f"complete_sign_in error: {e}")
        return (False, f"خطای غیرمنتظره: {str(e)}")


def complete_2fa_sign_in(user_id: int, password: str) -> tuple:
    """Complete sign-in with 2FA password.

    Returns:
        tuple: (success: bool, error_message: str or None)
    """
    if user_id not in _pending:
        return (False, "درخواست ورود یافت نشد. لطفاً دوباره شماره تلفن وارد کنید.")

    pending = _pending[user_id]
    client = pending['client']

    async def _complete_2fa():
        try:
            await client.sign_in(password=password)

            # بررسی واقعی بودن ورود (مانند complete_sign_in)
            is_auth = await client.is_user_authorized()
            if not is_auth:
                logger.warning(f"2FA sign_in returned but user {user_id} is NOT authorized")
                return (False, "ورود ناموفق بود. لطفاً دوباره شماره تلفن وارد کنید.")

            _clients[user_id] = client
            del _pending[user_id]
            logger.info(f"Userbot signed in with 2FA for user {user_id}")
            return (True, None)
        except Exception as e:
            error_str = str(e)
            logger.error(f"Error completing 2FA sign-in for user {user_id}: {e}")

            if "PasswordHashInvalidError" in error_str or ("password" in error_str.lower() and "invalid" in error_str.lower()):
                return (False, "رمز عبور اشتباه است. لطفاً رمز صحیح را وارد کنید.")
            elif "FloodWait" in error_str:
                import re
                match = re.search(r'(\d+)', error_str)
                wait_time = match.group(1) if match else "?"
                return (False, f"تلگرام محدودیت گذاشته است. لطفاً {wait_time} ثانیه صبر کنید.")
            else:
                return (False, f"خطا در ورود: {error_str}")

    try:
        return _run_async(_complete_2fa())
    except Exception as e:
        logger.error(f"complete_2fa_sign_in error: {e}")
        return (False, f"خطای غیرمنتظره: {str(e)}")


def get_client_for_user(user_id: int):
    return _clients.get(user_id)


def is_authorized(user_id: int) -> bool:
    """بررسی آیا کاربر قبلاً وارد شده و سشن معتبر دارد.

    توجه: فقط وجود فایل سشن کافی نیست - باید واقعاً بررسی کنیم که سشن
    authorized هست یا نه. یک فایل سشن ممکن است وجود داشته باشد ولی
    ورود هرگز کامل نشده باشد (مثلاً کد اشتباه وارد شده یا مسدود شده).
    """
    if user_id in _clients:
        client = _clients[user_id]
        try:
            async def _check():
                return await client.is_user_authorized()
            return _run_async(_check())
        except Exception:
            return False

    # اگر فایل سشن وجود دارد، تلاش می‌کنیم متصل شویم و واقعاً بررسی کنیم
    if not _session_exists(user_id):
        return False

    # تلاش برای اتصال مجدد و بررسی واقعی
    return reconnect_user(user_id)


async def async_reconnect_user(user_id: int) -> bool:
    """اتصال مجدد کاربر با استفاده از سشن ذخیره شده (نسخه async).

    این تابع باید داخل همان event loop استفاده شود که کلاینت به آن متصل است.
    برخلاف reconnect_user که از _run_async استفاده می‌کند، این نسخه باعث
    deadlock نمی‌شود چون همه کارها را مستقیم با await انجام می‌دهد.
    """
    if not is_available():
        logger.error(f"Cannot reconnect user {user_id}: Telethon API credentials not configured (TELETHON_API_ID/TELETHON_API_HASH missing)")
        return False

    if not _session_exists(user_id):
        logger.warning(f"Cannot reconnect user {user_id}: session file does not exist at {_get_session_path(user_id)}.session")
        return False

    if user_id in _clients:
        return True  # قبلاً متصل است

    try:
        from telethon import TelegramClient
        session = _get_session_path(user_id)
        client = TelegramClient(session, int(_api_id), _api_hash)
        await client.connect()
        if await client.is_user_authorized():
            _clients[user_id] = client
            logger.info(f"Reconnected userbot for user {user_id}")
            return True
        else:
            await client.disconnect()
            logger.warning(f"Session not authorized for user {user_id} - user needs to re-login via /settings")
            return False
    except Exception as e:
        logger.error(f"Error reconnecting user {user_id}: {e}", exc_info=True)
        return False


def reconnect_user(user_id: int) -> bool:
    """اتصال مجدد کاربر با استفاده از سشن ذخیره شده (نسخه sync)"""
    if not is_available():
        return False

    if not _session_exists(user_id):
        return False

    if user_id in _clients:
        return True  # قبلاً متصل است

    async def _reconnect():
        return await async_reconnect_user(user_id)

    try:
        return _run_async(_reconnect())
    except Exception as e:
        logger.error(f"reconnect_user error: {e}")
        return False


def load_existing_sessions(user_ids: list) -> dict:
    """بارگذاری سشن‌های ذخیره شده برای لیست کاربران

    Returns:
        دیکشنری user_id -> bool (موفقیت اتصال)
    """
    results = {}
    for user_id in user_ids:
        if _session_exists(user_id):
            results[user_id] = reconnect_user(user_id)
        else:
            results[user_id] = False
    return results


def is_user_online(user_id: int) -> bool:
    """بررسی آیا کاربر آنلاین است (نسخه sync - برای استفاده خارج از event loop)"""
    client = _clients.get(user_id)
    if not client:
        return False

    try:
        return _run_async(async_is_user_online(user_id), timeout=15)
    except Exception:
        return False


async def async_is_user_online(user_id: int) -> bool:
    """بررسی آیا کاربر آنلاین است (نسخه async - برای استفاده داخل event loop).

    این تابع باید داخل همان event loopی استفاده شود که کلاینت به آن متصل است،
    تا از deadlock جلوگیری شود.
    """
    client = _clients.get(user_id)
    if not client:
        return False

    try:
        me = await client.get_me()
        if me and hasattr(me, 'status'):
            from telethon.tl.types import UserStatusOnline, UserStatusRecently
            if isinstance(me.status, UserStatusOnline):
                return True
            # اگر اخیراً فعال بوده، احتمالاً آنلاین است
            if isinstance(me.status, UserStatusRecently):
                return True
        return False
    except Exception as e:
        logger.error(f"Error checking online status for user {user_id}: {e}")
        return False


def get_user_info(user_id: int) -> dict:
    """دریافت اطلاعات کاربر از userbot"""
    client = _clients.get(user_id)
    if not client:
        return {}

    async def _get_info():
        try:
            me = await client.get_me()
            # استفاده از async_is_user_online به جای is_user_online برای جلوگیری از deadlock
            # (is_user_online از _run_async استفاده می‌کند که داخل _run_async دیگر deadlock می‌شود)
            online = await async_is_user_online(user_id)
            return {
                "id": me.id,
                "first_name": me.first_name or "",
                "last_name": me.last_name or "",
                "username": me.username or "",
                "phone": me.phone or "",
                "is_online": online
            }
        except Exception as e:
            logger.error(f"Error getting user info for {user_id}: {e}")
            return {}

    try:
        return _run_async(_get_info(), timeout=15)
    except Exception:
        return {}


def stop_userbot(user_id: int):
    """قطع اتصال userbot کاربر"""
    client = _clients.pop(user_id, None)
    if client:
        try:
            _run_async(client.disconnect())
        except Exception:
            pass
    logger.info(f"Stopped userbot for user {user_id}")


def delete_session(user_id: int) -> bool:
    """حذف فایل سشن کاربر"""
    stop_userbot(user_id)
    session_path = _get_session_path(user_id)
    try:
        if os.path.exists(session_path + ".session"):
            os.remove(session_path + ".session")
            logger.info(f"Deleted session for user {user_id}")
            return True
    except Exception as e:
        logger.error(f"Error deleting session for user {user_id}: {e}")
    return False


def delete_dialog_with_bot(user_id: int, bot_peer_id: int) -> bool:
    """حذف کامل گفتگو با ربات از داخل خود تلگرام به کمک سشن منشی شخصی.

    وقتی کاربر روی «پاک‌کردن» تأیید بدهد، این تابع کل گفتگوی او با ربات را
    از اکانت خودش حذف می‌کند تا هیچ پیامی (از کاربر یا ربات) باقی نماند.

    Args:
        user_id: آیدی عددی کاربر (همان صاحب سشن منشی شخصی)
        bot_peer_id: آیدی عددی ربات (نمونه‌ی ربات کارن)

    Returns:
        bool: آیا گفتگو با موفقیت حذف شد
    """
    client = _clients.get(user_id)
    if client is None:
        if not reconnect_user(user_id):
            return False
        client = _clients.get(user_id)
    if client is None:
        return False

    async def _delete():
        try:
            # یافتن entity ربات از میان گفتگوهای کاربر
            entity = None
            async for dialog in client.iter_dialogs():
                if dialog.entity and getattr(dialog.entity, 'id', None) == bot_peer_id:
                    entity = dialog.entity
                    break
            if entity is None:
                try:
                    entity = await client.get_entity(bot_peer_id)
                except Exception:
                    logger.warning(f"entity ربات برای کاربر {user_id} پیدا نشد")
                    return False
            await client.delete_dialog(entity, revoke=True)
            logger.info(f"🗑️ گفتگو با ربات برای کاربر {user_id} از تلگرام حذف شد")
            return True
        except Exception as e:
            logger.error(f"خطا در حذف گفتگو برای کاربر {user_id}: {e}")
            return False

    try:
        return _run_async(_delete(), timeout=45)
    except Exception as e:
        logger.error(f"delete_dialog_with_bot error: {e}")
        return False