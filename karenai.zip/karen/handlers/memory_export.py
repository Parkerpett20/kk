# handlers/memory_export.py
import json
import os
import logging
import telebot
from datetime import datetime

from memory.long_memory import long_term_memory
from memory.short_memory import short_term_memory
from handlers.commands import _match_cmd

logger = logging.getLogger(__name__)

EXPORT_VERSION = "1.0"


def _collect_user_data(chat_id: int) -> dict:
    """جمع‌آوری تمام اطلاعات حافظه یک کاربر"""
    chat_id_str = str(chat_id)

    facts = long_term_memory.data.get(chat_id_str, {})

    profile_path = "data/user_profile.json"
    profile = {}
    if os.path.exists(profile_path):
        try:
            with open(profile_path, "r", encoding="utf-8") as f:
                profile = json.load(f)
        except Exception:
            pass

    history = []
    if chat_id in short_term_memory.sessions:
        for msg in short_term_memory.sessions[chat_id]:
            role = msg.role if hasattr(msg, "role") else str(getattr(msg, "role", ""))
            text = ""
            if hasattr(msg, "parts") and msg.parts:
                for part in msg.parts:
                    if hasattr(part, "text") and part.text:
                        text += part.text
            if text:
                history.append({"role": role, "text": text})

    all_sessions = {}
    sessions_path = "data/short_memory.json"
    if os.path.exists(sessions_path):
        try:
            with open(sessions_path, "r", encoding="utf-8") as f:
                all_sessions = json.load(f)
        except Exception:
            pass

    return {
        "version": EXPORT_VERSION,
        "exported_at": datetime.now().isoformat(),
        "chat_id": chat_id,
        "long_memory": facts,
        "user_profile": profile,
        "session_history": history,
        "all_sessions": all_sessions
    }


def _apply_user_data(chat_id: int, data: dict):
    """بازیابی اطلاعات حافظه از فایل JSON"""
    chat_id_str = str(chat_id)

    if "long_memory" in data and isinstance(data["long_memory"], dict):
        for key, value in data["long_memory"].items():
            long_term_memory.save_fact(chat_id_str, key, value)

    if "user_profile" in data and isinstance(data["user_profile"], dict):
        profile_path = "data/user_profile.json"
        try:
            os.makedirs(os.path.dirname(profile_path), exist_ok=True)
            with open(profile_path, "w", encoding="utf-8") as f:
                json.dump(data["user_profile"], f, ensure_ascii=False, indent=4)
        except Exception as e:
            logger.error(f"خطا در ذخیره user_profile: {e}")

    if "session_history" in data and isinstance(data["session_history"], list):
        from google.genai import types
        history = short_term_memory.get_history(chat_id)
        for msg in data["session_history"]:
            role = msg.get("role", "user")
            text = msg.get("text", "")
            if text:
                history.append(types.Content(role=role, parts=[types.Part(text=text)]))

    if "all_sessions" in data and isinstance(data["all_sessions"], dict):
        from google.genai import types
        for sid_str, messages in data["all_sessions"].items():
            sid = int(sid_str)
            history = short_term_memory.get_history(sid)
            for msg in messages:
                role = msg.get("role", "user")
                text = msg.get("text", "")
                if text:
                    history.append(types.Content(role=role, parts=[types.Part(text=text)]))
        short_term_memory._save_sessions()


def register_memory_export_handler(bot: telebot.TeleBot):
    @bot.message_handler(func=lambda m: _match_cmd(m, 'export', emoji='📦 خروجی'))
    def on_export(message):
        chat_id = message.chat.id
        data = _collect_user_data(chat_id)

        file_path = f"data/export_{chat_id}.json"
        os.makedirs("data", exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

        facts_count = len(data.get("long_memory", {}))
        history_count = len(data.get("session_history", []))
        profile_facts = len(data.get("user_profile", {}).get("extracted_facts", []))
        all_sessions_count = len(data.get("all_sessions", {}))

        caption = (
            f"📦 خروجی حافظه کارن\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"✅ حقایق بلندمدت: {facts_count} مورد\n"
            f"✅ اطلاعات پروفایل: {profile_facts} مورد\n"
            f"✅ تاریخچه مکالمه: {history_count} پیام\n"
            f"✅ سشن‌های ذخیره شده: {all_sessions_count} سشن\n"
            f"📅 تاریخ خروج: {data['exported_at']}\n\n"
            f"💡 این فایل را نگه دارید! با /import می‌توانید آن را بازیابی کنید."
        )

        try:
            with open(file_path, "rb") as f:
                bot.send_document(chat_id, f, caption=caption)
        except Exception as e:
            bot.reply_to(message, f"❌ خطا در ارسال فایل: {e}")
            return

        try:
            os.remove(file_path)
        except Exception:
            pass

    @bot.message_handler(func=lambda m: _match_cmd(m, 'import', emoji='📥 بازیابی'), content_types=['document'])
    def on_import_with_doc(message):
        _handle_import(bot, message)

    @bot.message_handler(func=lambda m: _match_cmd(m, 'import', emoji='📥 بازیابی'))
    def on_import_prompt(message):
        bot.reply_to(message, (
            "📥 برای بازیابی حافظه:\n"
            "فایل JSON خروجی (/export) را همراه با دستور /import ارسال کنید.\n\n"
            "مثلاً فایل را بفرستید و در کپشن بنویسید: /import"
        ))

    @bot.message_handler(func=lambda m: m.document and m.document.file_name and m.document.file_name.endswith('.json') and m.caption and '/import' in m.caption)
    def on_import_as_reply(message):
        _handle_import(bot, message)


def _handle_import(bot: telebot.TeleBot, message):
    try:
        if not message.document:
            bot.reply_to(message, "❌ فایل JSON را ضمیمه کنید.")
            return

        file_id = message.document.file_id
        file_info = bot.get_file(file_id)
        downloaded = bot.download_file(file_info.file_path)
        content = downloaded.decode("utf-8")
        data = json.loads(content)

        if "version" not in data:
            bot.reply_to(message, "❌ فایل نامعتبر است. فایل خروجی کارن (/export) را ارسال کنید.")
            return

        exported_chat_id = data.get("chat_id")
        current_chat_id = message.chat.id

        if exported_chat_id and exported_chat_id != current_chat_id:
            bot.reply_to(message, (
                f"⚠️ این فایل متعلق به کاربر دیگری است (ID: {exported_chat_id}).\n"
                f"آیا مطمئنید که می‌خواهید داده‌ها را بازیابی کنید؟\n"
                f"برای تأیید دوباره /import را همراه فایل بفرستید."
            ))
            _pending_imports[current_chat_id] = data
            return

        _apply_user_data(current_chat_id, data)

        facts_count = len(data.get("long_memory", {}))
        history_count = len(data.get("session_history", []))
        profile_facts = len(data.get("user_profile", {}).get("extracted_facts", []))
        all_sessions_count = len(data.get("all_sessions", {}))

        bot.reply_to(message, (
            f"✅ حافظه بازیابی شد!\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"📝 حقایق بلندمدت: {facts_count} مورد\n"
            f"📝 اطلاعات پروفایل: {profile_facts} مورد\n"
            f"📝 تاریخچه مکالمه: {history_count} پیام\n"
            f"📝 سشن‌های بازیابی شده: {all_sessions_count} سشن\n\n"
            f"🔄 اکنون من تمام اطلاعات قبلی شما را به یاد دارم!"
        ))

    except json.JSONDecodeError:
        bot.reply_to(message, "❌ فایل JSON نامعتبر است. لطفاً فایل صحیح را ارسال کنید.")
    except Exception as e:
        bot.reply_to(message, f"❌ خطا در بازیابی حافظه: {e}")


_pending_imports = {}
