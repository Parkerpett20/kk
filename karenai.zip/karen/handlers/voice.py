# handlers/voice.py
import logging
import telebot
from google.genai import types
from core.errors import get_friendly_error_message
from core.executor import AgentExecutor
from core.streaming import handle_stream_delivery
from handlers.group import group_manager
from utils.message_context import build_user_text_with_context

def register_voice_handler(bot: telebot.TeleBot):
    @bot.message_handler(content_types=['voice'])
    def on_voice(message):
        # ذخیره ویس در تاریخچه گروه
        if message.chat.type in ['group', 'supergroup']:
            try:
                username = message.from_user.username or message.from_user.first_name or "نامشخص"
                caption = message.caption or "[ویس]"
                group_manager.save_message(
                    chat_id=message.chat.id,
                    user_id=message.from_user.id,
                    username=username,
                    text=caption,
                    msg_type="voice"
                )
            except Exception as e:
                pass
        
        sent_msg = bot.reply_to(message, "⏳ دارم به صدات گوش میدم...")
        try:
            file_id = message.voice.file_id
            file_info = bot.get_file(file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            
            # تلگرام ویس‌ها را در بستر فایل‌های صوتی ogg ارسال می‌کند
            voice_part = types.Part.from_bytes(
                data=downloaded_file,
                mime_type="audio/ogg"
            )
            
            caption = message.caption or "محتوای این صوت رو گوش بده و جواب منو صمیمانه بده."
            user_text = build_user_text_with_context(message, caption)
            stream, plan = AgentExecutor.run_stream(
                chat_id=message.chat.id,
                user_text=user_text,
                attachments=[voice_part],
                user_id=message.from_user.id
            )
            
            status = "🎙️ پردازش شنیداری صوت"
            bot.edit_message_text(f"[{status}]\n✍️...", message.chat.id, sent_msg.message_id)
            
            handle_stream_delivery(bot, message.chat.id, sent_msg.message_id, stream, user_text)
            
        except Exception as e:
            logging.getLogger(__name__).error(f"Error processing voice: {e}", exc_info=True)
            friendly = get_friendly_error_message(message.from_user.id, e)
            bot.edit_message_text(friendly, message.chat.id, sent_msg.message_id)