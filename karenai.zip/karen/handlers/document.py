# handlers/document.py
import os
import logging
import telebot
from google.genai import types
from core.errors import get_friendly_error_message
from core.executor import AgentExecutor
from core.streaming import handle_stream_delivery
from handlers.group import group_manager
from utils.message_context import build_user_text_with_context

# Office file extensions that can be processed by OfficeCLI
OFFICE_EXTENSIONS = ('.docx', '.xlsx', '.pptx')

def register_document_handler(bot: telebot.TeleBot):
    @bot.message_handler(content_types=['document'])
    def on_document(message):
        # ذخیره سند در تاریخچه گروه
        if message.chat.type in ['group', 'supergroup']:
            try:
                username = message.from_user.username or message.from_user.first_name or "نامشخص"
                file_name = message.document.file_name or "document"
                caption = message.caption or f"[سند: {file_name}]"
                group_manager.save_message(
                    chat_id=message.chat.id,
                    user_id=message.from_user.id,
                    username=username,
                    text=caption,
                    msg_type="document"
                )
            except Exception as e:
                pass
        
        sent_msg = bot.reply_to(message, "⏳ دارم فایلت رو بازخوانی و بررسی می‌کنم...")
        try:
            file_id = message.document.file_id
            file_name = message.document.file_name or "document"
            mime_type = message.document.mime_type or "application/octet-stream"
            
            file_info = bot.get_file(file_id)
            downloaded_file = bot.download_file(file_info.file_path)

            # بررسی آیا فایل آفیس است - اگر هست، با OfficeCLI متن آن را استخراج کن
            file_ext = os.path.splitext(file_name)[1].lower()
            office_text_content = None
            if file_ext in OFFICE_EXTENSIONS:
                try:
                    from tools.office import _ensure_office_dir, OFFICE_DIR
                    _ensure_office_dir()
                    # ذخیره فایل در workspace موقت
                    temp_path = os.path.join(OFFICE_DIR, f"received_{file_name}")
                    with open(temp_path, 'wb') as f:
                        f.write(downloaded_file)
                    # استخراج متن با OfficeCLI
                    from tools.office import view_office_document
                    office_text_content = view_office_document(f"received_{file_name}", mode="text")
                    # پاک کردن فایل موقت
                    try:
                        os.remove(temp_path)
                    except Exception:
                        pass
                except Exception as e:
                    import logging
                    logging.getLogger(__name__).warning(f"OfficeCLI text extraction failed: {e}")
            
            document_part = types.Part.from_bytes(
                data=downloaded_file,
                mime_type=mime_type
            )
            
            # اگر متن استخراج شده از OfficeCLI داریم، آن را به متن کاربر اضافه کن
            caption = message.caption or f"محتوای سند '{file_name}' رو دقیق مطالعه کن و بهم بازخورد بده."
            if office_text_content and not office_text_content.startswith("❌"):
                caption = (
                    f"محتوای سند '{file_name}' رو دقیق مطالعه کن و بهم بازخورد بده.\n\n"
                    f"📄 متن استخراج‌شده از سند:\n{office_text_content[:3000]}"
                )
            user_text = build_user_text_with_context(message, caption)
            stream, plan = AgentExecutor.run_stream(
                chat_id=message.chat.id,
                user_text=user_text,
                attachments=[document_part],
                user_id=message.from_user.id
            )
            
            status = f"📄 تحلیل سند ({file_name})"
            bot.edit_message_text(f"[{status}]\n✍️...", message.chat.id, sent_msg.message_id)
            
            handle_stream_delivery(bot, message.chat.id, sent_msg.message_id, stream, user_text)
            
        except Exception as e:
            logging.getLogger(__name__).error(f"Error reading document: {e}", exc_info=True)
            friendly = get_friendly_error_message(message.from_user.id, e)
            bot.edit_message_text(friendly, message.chat.id, sent_msg.message_id)
