# handlers/commands.py
import telebot
import os
import json
import logging
from memory.short_memory import short_term_memory
from memory.long_memory import long_term_memory
from memory.user_settings import user_settings
from memory.telegram_profile import telegram_profile_manager
from core.languages import get_text, get_welcome_message, get_language_keyboard, get_language, LANGUAGES

logger = logging.getLogger(__name__)


def _match_cmd(message, *commands, emoji=None, lang_keys=None):
    """Check if message matches any of the slash commands or emoji button text."""
    text = message.text or getattr(message, 'caption', None) or ''
    if not text:
        return False
    parts = text.split()
    if parts:
        cmd = parts[0].lower()
        # Remove @botname suffix if present (e.g. /setting@mybot -> /setting)
        if '@' in cmd:
            cmd = cmd.split('@')[0]
        if cmd in ['/' + c for c in commands]:
            return True
    if emoji and text.strip() == emoji:
        return True
    # Check if text matches any localized button text
    if lang_keys:
        user_id = message.from_user.id if message.from_user else None
        for key in lang_keys:
            localized = get_text(user_id, key)
            if text.strip() == localized:
                return True
    return False


def get_current_lang_name(user_id: int) -> str:
    lang_code = user_settings.get_language(user_id)
    return LANGUAGES.get(lang_code, {}).get("name", "English")

def get_current_lang_flag(user_id: int) -> str:
    lang_code = user_settings.get_language(user_id)
    return LANGUAGES.get(lang_code, {}).get("flag", "🇬🇧")

def get_settings_text(user_id: int) -> str:
    current_lang = get_current_lang_name(user_id)
    current_flag = get_current_lang_flag(user_id)
    user_name = user_settings.get_setting(user_id, 'profile_name')
    user_birthday = user_settings.get_setting(user_id, 'profile_birthday')
    user_bio = user_settings.get_setting(user_id, 'profile_bio')

    if not user_name:
        user_name = "Not set"
    if not user_birthday or user_birthday == 'تنظیم نشده':
        user_birthday = "Not set"
    if not user_bio or user_bio == 'تنظیم نشده':
        user_bio = "Not set"

    return (
        f"{get_text(user_id, 'settings_title')}\n"
        f"━━━━━━━━━━━━━━━━━━━\n\n"
        f"{get_text(user_id, 'settings_lang_label', flag=current_flag, lang=current_lang)}\n"
        f"━━━━━━━━━━━━━━━━━━━\n\n"
        f"{get_text(user_id, 'settings_profile_title')}\n"
        f"  {get_text(user_id, 'settings_name_label', name=user_name)}\n"
        f"  {get_text(user_id, 'settings_birthday_label', birthday=user_birthday)}\n"
        f"  {get_text(user_id, 'settings_bio_label', bio=user_bio)}\n"
        f"━━━━━━━━━━━━━━━━━━━\n\n"
        f"{get_text(user_id, 'settings_hint')}"
    )

def get_settings_keyboard(user_id: int):
    from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
    markup = InlineKeyboardMarkup(row_width=1)
    markup.add(InlineKeyboardButton(get_text(user_id, "settings_lang_btn"), callback_data="settings_lang"))
    markup.add(InlineKeyboardButton(get_text(user_id, "settings_profile_btn"), callback_data="settings_profile"))
    markup.add(InlineKeyboardButton(get_text(user_id, "settings_secretary_btn"), callback_data="settings_secretary"))
    return markup

def get_clear_confirm_keyboard(user_id: int):
    """کیبورد تأیید پاک‌سازی کامل (آری / انصراف)"""
    from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
    markup = InlineKeyboardMarkup(row_width=1)
    markup.add(InlineKeyboardButton(get_text(user_id, "clear_confirm_yes"), callback_data="clear_confirm_yes"))
    markup.add(InlineKeyboardButton(get_text(user_id, "clear_confirm_no"), callback_data="clear_confirm_no"))
    return markup


def wipe_user_data(chat_id: int, user_id: int):
    """پاک‌سازی کامل تمام داده‌های محلی کاربر"""
    user_key = str(user_id)

    # 1. حافظه کوتاه‌مدت (تمامی مکالمات)
    try:
        short_term_memory.clear(chat_id)
    except Exception as e:
        logger.error(f"خطا در پاک‌کردن short_memory: {e}")

    # 2. حافظه بلندمدت (حقایق آموخته شده)
    try:
        if user_key in long_term_memory.data:
            del long_term_memory.data[user_key]
            with open(long_term_memory.filepath, 'w', encoding='utf-8') as f:
                json.dump(long_term_memory.data, f, ensure_ascii=False, indent=4)
    except Exception as e:
        logger.error(f"خطا در پاک‌کردن long_memory: {e}")

    # 3. تنظیمات کاربر (بازگشت به حالت کاربر جدید)
    try:
        if user_key in user_settings.settings:
            del user_settings.settings[user_key]
            user_settings.save()
    except Exception as e:
        logger.error(f"خطا در پاک‌کردن user_settings: {e}")

    # 4. پروفایل تلگرام
    try:
        if user_key in telegram_profile_manager.profiles:
            del telegram_profile_manager.profiles[user_key]
            telegram_profile_manager.save()
    except Exception as e:
        logger.error(f"خطا در پاک‌کردن telegram_profile: {e}")

    # 5. منشی شخصی: توقف مانیتورینگ و حذف سشن تلگرام کاربر
    try:
        from tools.userbot_manager import delete_session
        from tools.secretary_service import stop_monitoring
        try:
            stop_monitoring(user_id)
        except Exception:
            pass
        delete_session(user_id)
    except Exception as e:
        logger.error(f"خطا در حذف سشن منشی شخصی: {e}")

    # 6. حذف یادآوری‌های کاربر
    try:
        from core.scheduler import reminder_scheduler
        for rid in list(reminder_scheduler.reminders.keys()):
            if reminder_scheduler.reminders[rid].user_id == user_id:
                reminder_scheduler.delete_reminder(rid)
    except Exception as e:
        logger.error(f"خطا در حذف یادآوری‌ها: {e}")


def delete_telegram_dialog(bot, user_id: int) -> bool:
    """حذف کامل گفتگو با ربات از داخل خود تلگرام تا چیزی باقی نماند.

    اگر کاربر سشن منشی شخصی (telethon) داشته باشد، کل گفتگوی او با ربات
    از اکانت خودش حذف می‌شود (هم پیام‌های خودش هم پیام‌های ربات).
    """
    try:
        bot_me = bot.get_me()
        bot_id = bot_me.id if bot_me else None
    except Exception:
        bot_id = None
    if not bot_id:
        return False

    try:
        from tools.userbot_manager import delete_dialog_with_bot
        return delete_dialog_with_bot(user_id, bot_id)
    except Exception as e:
        logger.error(f"خطا در حذف گفتگو از تلگرام: {e}")
        return False


def get_profile_edit_keyboard(user_id: int = None):
    """کیبورد ویرایش پروفایل"""
    from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
    markup = InlineKeyboardMarkup(row_width=1)
    markup.add(InlineKeyboardButton(get_text(user_id, "profile_edit_name_btn"), callback_data="profile_edit_name"))
    markup.add(InlineKeyboardButton(get_text(user_id, "profile_edit_birthday_btn"), callback_data="profile_edit_birthday"))
    markup.add(InlineKeyboardButton(get_text(user_id, "profile_edit_bio_btn"), callback_data="profile_edit_bio"))
    markup.add(InlineKeyboardButton(get_text(user_id, "settings_back_btn"), callback_data="settings_back"))
    return markup

def get_welcome_keyboard(user_id: int):
    from telebot.types import ReplyKeyboardMarkup, KeyboardButton
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False, row_width=2)
    markup.add(
        KeyboardButton(get_text(user_id, "btn_settings")),
        KeyboardButton(get_text(user_id, "btn_profile")),
    )
    markup.add(
        KeyboardButton(get_text(user_id, "btn_lang")),
        KeyboardButton(get_text(user_id, "btn_secretary")),
    )
    markup.add(
        KeyboardButton(get_text(user_id, "btn_clear")),
        KeyboardButton(get_text(user_id, "btn_developer")),
    )
    return markup

def register_commands(bot: telebot.TeleBot):
    @bot.message_handler(commands=['start'])
    def on_start(message):
        user_id = message.from_user.id
        
        # Check if user is new (no language set yet)
        if user_settings.is_new_user(user_id):
            # Show language selection
            choose_text = get_text(user_id, "choose_language")
            bot.reply_to(message, choose_text, reply_markup=get_language_keyboard())
            bot.send_message(message.chat.id, get_text(user_id, "setup_welcome"), reply_markup=get_welcome_keyboard(user_id))
        else:
            # Show welcome message in user's language
            welcome = get_welcome_message(user_id)
            bot.reply_to(message, welcome, reply_markup=get_welcome_keyboard(user_id))
    
    @bot.message_handler(func=lambda m: _match_cmd(m, 'settings', 'setting', 'ستینگ', 'تنظیمات', lang_keys=['btn_settings']))
    def on_settings(message):
        user_id = message.from_user.id
        settings_text = get_settings_text(user_id)
        bot.reply_to(message, settings_text, reply_markup=get_settings_keyboard(user_id))
    
    @bot.callback_query_handler(func=lambda call: call.data == "settings_lang")
    def on_settings_lang_callback(call):
        user_id = call.from_user.id
        choose_text = get_text(user_id, "choose_language")
        bot.edit_message_text(choose_text, call.message.chat.id, call.message.message_id, reply_markup=get_language_keyboard())
        bot.answer_callback_query(call.id)
    
    @bot.callback_query_handler(func=lambda call: call.data.startswith('lang_'))
    def on_language_selected(call):
        user_id = call.from_user.id
        lang_code = call.data.replace('lang_', '')
        
        if lang_code in LANGUAGES:
            user_settings.set_language(user_id, lang_code)
            selected_text = get_text(user_id, "language_selected")
            bot.answer_callback_query(call.id, selected_text)

            # بررسی آیا کاربر پروفایل خود را تنظیم کرده است
            profile_name = user_settings.get_setting(user_id, 'profile_name')
            if not profile_name:
                # کاربر جدید - شروع ستاپ پروفایل
                bot.send_message(
                    call.message.chat.id,
                    get_text(user_id, "setup_lang_selected"),
                    reply_markup=telebot.types.ForceReply()
                )
            else:
                # کاربر قدیمی - نمایش تنظیمات
                settings_text = get_settings_text(user_id)
                bot.edit_message_text(settings_text, call.message.chat.id, call.message.message_id, reply_markup=get_settings_keyboard(user_id))

    # هندلر دریافت نام در ستاپ اولیه
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and ('نام خود را وارد کنید' in m.reply_to_message.text or 'enter your name' in m.reply_to_message.text.lower()))
    def on_setup_name(message):
        """دریافت نام در ستاپ اولیه"""
        user_id = message.from_user.id
        name = message.text.strip()

        if len(name) < 2:
            bot.reply_to(message, get_text(user_id, "setup_name_short"))
            return

        user_settings.set_setting(user_id, 'profile_name', name)
        user_settings.save()

        bot.send_message(
            message.chat.id,
            get_text(user_id, "setup_name_received", name=name),
            reply_markup=telebot.types.ForceReply()
        )

    # هندلر دریافت تاریخ تولد در ستاپ اولیه
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and ('تاریخ تولد خود را وارد کنید' in m.reply_to_message.text or 'enter your birthday' in m.reply_to_message.text.lower()))
    def on_setup_birthday(message):
        """دریافت تاریخ تولد در ستاپ اولیه"""
        user_id = message.from_user.id
        birthday = message.text.strip()

        if birthday.lower() in ['رد', 'skip', 'نه', 'no', 'skip', 'geç', 'تخطي']:
            birthday = 'Not set'

        user_settings.set_setting(user_id, 'profile_birthday', birthday)
        user_settings.save()

        bot.send_message(
            message.chat.id,
            get_text(user_id, "setup_birthday_received"),
            reply_markup=telebot.types.ForceReply()
        )

    # هندلر دریافت درباره من در ستاپ اولیه
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and ('کمی درباره خودت بنویس' in m.reply_to_message.text or 'tell me a bit about yourself' in m.reply_to_message.text.lower()))
    def on_setup_bio(message):
        """دریافت درباره من در ستاپ اولیه"""
        user_id = message.from_user.id
        bio = message.text.strip()

        if bio.lower() in ['رد', 'skip', 'نه', 'no', 'skip', 'geç', 'تخطي']:
            bio = 'Not set'

        user_settings.set_setting(user_id, 'profile_bio', bio)
        user_settings.save()

        # نمایش پیام خوش‌آمدگویی با نام کاربر
        user_name = user_settings.get_setting(user_id, 'profile_name', 'friend')
        welcome = get_welcome_message(user_id)
        welcome_text = get_text(user_id, "setup_complete", welcome=welcome, name=user_name)

        bot.send_message(message.chat.id, welcome_text, reply_markup=get_welcome_keyboard(user_id))

    # هندلر ویرایش پروفایل از تنظیمات
    @bot.callback_query_handler(func=lambda call: call.data == "settings_profile")
    def on_settings_profile(call):
        """نمایش منوی ویرایش پروفایل"""
        user_id = call.from_user.id
        text = get_text(user_id, "settings_profile_menu")
        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=get_profile_edit_keyboard(user_id))
        except Exception:
            bot.send_message(call.message.chat.id, text, reply_markup=get_profile_edit_keyboard(user_id))
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "profile_edit_name")
    def on_profile_edit_name(call):
        """درخواست تغییر نام"""
        user_id = call.from_user.id
        bot.send_message(
            call.message.chat.id,
            get_text(user_id, "settings_name_prompt"),
            reply_markup=telebot.types.ForceReply()
        )
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "profile_edit_birthday")
    def on_profile_edit_birthday(call):
        """درخواست تغییر تاریخ تولد"""
        user_id = call.from_user.id
        bot.send_message(
            call.message.chat.id,
            get_text(user_id, "settings_birthday_prompt"),
            reply_markup=telebot.types.ForceReply()
        )
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "profile_edit_bio")
    def on_profile_edit_bio(call):
        """درخواست تغییر درباره من"""
        user_id = call.from_user.id
        bot.send_message(
            call.message.chat.id,
            get_text(user_id, "settings_bio_prompt"),
            reply_markup=telebot.types.ForceReply()
        )
        bot.answer_callback_query(call.id)

    # هندلر دریافت نام جدید (ویرایش)
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and ('نام جدید خود را وارد کنید' in m.reply_to_message.text or 'enter your new name' in m.reply_to_message.text.lower()))
    def on_edit_name(message):
        """دریافت نام جدید"""
        user_id = message.from_user.id
        name = message.text.strip()

        if len(name) < 2:
            bot.reply_to(message, get_text(user_id, "setup_name_short"))
            return

        user_settings.set_setting(user_id, 'profile_name', name)
        user_settings.save()
        bot.reply_to(message, get_text(user_id, "settings_name_updated", name=name))

    # هندلر دریافت تاریخ تولد جدید (ویرایش)
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and ('تاریخ تولد جدید را وارد کنید' in m.reply_to_message.text or 'enter your new birthday' in m.reply_to_message.text.lower()))
    def on_edit_birthday(message):
        """دریافت تاریخ تولد جدید"""
        user_id = message.from_user.id
        birthday = message.text.strip()

        if birthday.lower() in ['رد', 'skip', 'نه', 'no', 'skip', 'geç', 'تخطي']:
            birthday = 'Not set'

        user_settings.set_setting(user_id, 'profile_birthday', birthday)
        user_settings.save()
        bot.reply_to(message, get_text(user_id, "settings_birthday_updated", birthday=birthday))

    # هندلر دریافت درباره من جدید (ویرایش)
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and ('درباره خودت بنویس' in m.reply_to_message.text or 'tell me about yourself' in m.reply_to_message.text.lower()))
    def on_edit_bio(message):
        """دریافت درباره من جدید"""
        user_id = message.from_user.id
        bio = message.text.strip()

        if bio.lower() in ['رد', 'skip', 'نه', 'no', 'skip', 'geç', 'تخطي']:
            bio = 'Not set'

        user_settings.set_setting(user_id, 'profile_bio', bio)
        user_settings.save()
        bot.reply_to(message, get_text(user_id, "settings_bio_updated"))
    
    @bot.message_handler(func=lambda m: _match_cmd(m, 'lang', lang_keys=['btn_lang']))
    def on_lang_command(message):
        user_id = message.from_user.id
        choose_text = get_text(user_id, "choose_language")
        bot.reply_to(message, choose_text, reply_markup=get_language_keyboard())

    @bot.message_handler(func=lambda m: _match_cmd(m, 'secretary', lang_keys=['btn_secretary']))
    def on_secretary_command(message):
        """باز کردن منوی منشی شخصی از دکمه اصلی"""
        user_id = message.from_user.id
        from handlers.secretary import _get_secretary_status_text, _get_secretary_keyboard
        text = _get_secretary_status_text(user_id)
        markup = _get_secretary_keyboard(user_id)
        bot.reply_to(message, text, reply_markup=markup)
    
    @bot.message_handler(func=lambda m: _match_cmd(m, 'developer', 'توسعه‌دهنده', 'توسعه دهنده', lang_keys=['btn_developer']))
    def on_developer(message):
        """نمایش اطلاعات توسعه دهنده"""
        user_id = message.from_user.id
        bot.reply_to(message, get_text(user_id, "developer_info"))
    
    @bot.message_handler(func=lambda m: _match_cmd(m, 'clear', lang_keys=['btn_clear']))
    def on_clear(message):
        user_id = message.from_user.id
        # نمایش پیام هشدار و درخواست تأیید قبل از هر گونه پاک‌سازی
        confirm_text = get_text(user_id, "clear_confirm_title")
        bot.reply_to(message, confirm_text, reply_markup=get_clear_confirm_keyboard(user_id))

    @bot.callback_query_handler(func=lambda call: call.data == "clear_confirm_no")
    def on_clear_cancel(call):
        user_id = call.from_user.id
        try:
            bot.edit_message_text(
                get_text(user_id, "clear_cancelled"),
                call.message.chat.id,
                call.message.message_id,
                reply_markup=None
            )
        except Exception as e:
            logger.debug(f"خطا در ویرایش پیام لغو: {e}")
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "clear_confirm_yes")
    def on_clear_confirm(call):
        user_id = call.from_user.id
        chat_id = call.message.chat.id
        bot.answer_callback_query(call.id)

        # ذخیره متن تأیید و زبان قبل از پاک‌سازی (چون بعد از حذف تنظیمات، زبان پیش‌فرض می‌شود)
        done_text = get_text(user_id, "clear_all_data")
        lang_keyboard = get_language_keyboard()

        # 1. حذف کامل گفتگو از داخل خود تلگرام تا چیزی باقی نماند
        #    (باید قبل از پاک‌کردن سشن انجام شود چون به سشن منشی شخصی نیاز دارد)
        dialog_deleted = delete_telegram_dialog(bot, user_id)

        # 2. پاک‌سازی کامل داده‌های محلی کاربر (شامل حذف سشن منشی شخصی)
        wipe_user_data(chat_id, user_id)
        logger.info(f"پاک‌سازی کامل برای کاربر {user_id} انجام شد. حذف گفتگو از تلگرام: {dialog_deleted}")

        # 3. ارسال پیام تأیید نهایی + انتخاب زبان جدید (چت جدید)
        try:
            bot.send_message(chat_id, done_text, reply_markup=lang_keyboard)
        except Exception as e:
            logger.error(f"خطا در ارسال پیام تأیید پاک‌سازی: {e}")
    
    @bot.message_handler(func=lambda m: _match_cmd(m, 'profile', 'پروفایل', lang_keys=['btn_profile']))
    def on_profile(message):
        """نمایش پروفایل کاربر با عکس"""
        user_id = message.from_user.id
        
        # دریافت اطلاعات پروفایل
        profile = telegram_profile_manager.get_profile(user_id)
        
        # ساخت متن پروفایل
        profile_text = "👤 پروفایل شما:\n\n"
        
        if profile.get("first_name"):
            name = profile["first_name"]
            if profile.get("last_name"):
                name += f" {profile['last_name']}"
            profile_text += f"📝 نام: {name}\n"
        
        if profile.get("username"):
            profile_text += f"🔗 یوزرنیم: @{profile['username']}\n"
        
        if profile.get("language_code"):
            profile_text += f"🌍 زبان: {profile['language_code']}\n"
        
        if profile.get("is_premium"):
            profile_text += f"⭐ پریموم: بله\n"
        
        if profile.get("bio"):
            profile_text += f"📖 بیو: {profile['bio']}\n"
        
        if profile.get("message_count", 0) > 0:
            profile_text += f"💬 تعداد پیام‌ها: {profile['message_count']}\n"
        
        if profile.get("first_seen"):
            profile_text += f"📅 اولین حضور: {profile['first_seen'][:10]}\n"
        
        if profile.get("extracted_facts"):
            facts = profile["extracted_facts"]
            if isinstance(facts, list) and facts:
                profile_text += f"\n🧠 حقایق شناخته شده:\n"
                for fact in facts[-5:]:
                    profile_text += f"  • {fact}\n"
        
        # ارسال عکس پروفایل اگر وجود داشته باشه
        photo_path = telegram_profile_manager.get_profile_photo_path(user_id)
        if photo_path and os.path.exists(photo_path):
            try:
                with open(photo_path, 'rb') as photo:
                    bot.send_photo(message.chat.id, photo, caption=profile_text)
                return
            except Exception as e:
                pass
        
        # اگر عکس نبود، فقط متن رو بفرست
        # اول سعی کن عکس رو دریافت کنی
        try:
            fetched_path = telegram_profile_manager.fetch_profile_photo(bot, user_id)
            if fetched_path and os.path.exists(fetched_path):
                with open(fetched_path, 'rb') as photo:
                    bot.send_photo(message.chat.id, photo, caption=profile_text)
                return
        except Exception:
            pass
        
        bot.reply_to(message, profile_text)
    
    @bot.message_handler(func=lambda m: _match_cmd(m, 'checkprofile', 'چک پروفایل', emoji='🔍 بررسی پروفایل'))
    def on_check_profile(message):
        """بررسی پروفایل کاربر دیگر (با ریپلای)"""
        if not message.reply_to_message:
            bot.reply_to(message, "⚠️ لطفاً روی پیام کاربر مورد نظر ریپلای کنید.\n\nنحوه استفاده: /checkprofile (روی پیام کاربر ریپلای کنید)")
            return
        
        target_user = message.reply_to_message.from_user
        target_id = target_user.id
        
        # دریافت یا ساخت پروفایل برای کاربر هدف
        profile = telegram_profile_manager.get_profile(target_id)
        if not profile:
            # ساخت پروفایل جدید از اطلاعات پیام
            telegram_profile_manager.update_profile(
                target_id,
                first_name=target_user.first_name,
                last_name=target_user.last_name,
                username=target_user.username,
                is_bot=target_user.is_bot
            )
            profile = telegram_profile_manager.get_profile(target_id)
        
        # ساخت متن پروفایل
        profile_text = f"👤 پروفایل {target_user.first_name}:\n\n"
        
        if profile.get("first_name"):
            name = profile["first_name"]
            if profile.get("last_name"):
                name += f" {profile['last_name']}"
            profile_text += f"📝 نام: {name}\n"
        
        if profile.get("username"):
            profile_text += f"🔗 یوزرنیم: @{profile['username']}\n"
        
        if profile.get("is_bot"):
            profile_text += f"🤖 ربات: بله\n"
        
        if profile.get("language_code"):
            profile_text += f"🌍 زبان: {profile['language_code']}\n"
        
        if profile.get("is_premium"):
            profile_text += f"⭐ پریموم: بله\n"
        
        if profile.get("message_count", 0) > 0:
            profile_text += f"💬 تعداد پیام‌ها: {profile['message_count']}\n"
        
        if profile.get("first_seen"):
            profile_text += f"📅 اولین حضور: {profile['first_seen'][:10]}\n"
        
        if profile.get("extracted_facts"):
            facts = profile["extracted_facts"]
            if isinstance(facts, list) and facts:
                profile_text += f"\n🧠 حقایق شناخته شده:\n"
                for fact in facts[-5:]:
                    profile_text += f"  • {fact}\n"
        
        # ارسال عکس پروفایل اگر وجود داشته باشه
        photo_path = telegram_profile_manager.get_profile_photo_path(target_id)
        if photo_path and os.path.exists(photo_path):
            try:
                with open(photo_path, 'rb') as photo:
                    bot.send_photo(message.chat.id, photo, caption=profile_text)
                return
            except Exception as e:
                pass
        
        # اگر عکس نبود، سعی کن دریافت کنی
        try:
            fetched_path = telegram_profile_manager.fetch_profile_photo(bot, target_id)
            if fetched_path and os.path.exists(fetched_path):
                with open(fetched_path, 'rb') as photo:
                    bot.send_photo(message.chat.id, photo, caption=profile_text)
                return
        except Exception:
            pass
        
        bot.reply_to(message, profile_text)
    
    @bot.message_handler(func=lambda m: _match_cmd(m, 'photofeedback', 'نظر عکس', 'عکسم چطوره', 'نظرت درباره عکسم', emoji='📸 نظر عکس'))
    def on_photo_feedback(message):
        """نظر کارن درباره عکس پروفایل کاربر"""
        user_id = message.from_user.id
        
        # دریافت عکس پروفایل
        photo_path = telegram_profile_manager.get_profile_photo_path(user_id)
        
        if not photo_path or not os.path.exists(photo_path):
            # سعی کن دریافت کنی
            photo_path = telegram_profile_manager.fetch_profile_photo(bot, user_id)
        
        if not photo_path or not os.path.exists(photo_path):
            bot.reply_to(message, "🤔 هنوز عکس پروفایلی نداری! اول یه عکس پروفایل بذار تا نظر بدم.")
            return
        
        # ارسال عکس با درخواست نظر
        try:
            feedback_prompts = [
                "بیا عکس پروفایلمو ببین، نظرت چیه؟",
                "این عکس پروفایلمه، خوبه به نظرت؟",
                "میخوام نظرت رو درباره عکس پروفایلم بدونم",
                "عکس پروفایلم چطوره؟ راهنماییم کن"
            ]
            import random
            feedback_request = random.choice(feedback_prompts)
            
            with open(photo_path, 'rb') as photo:
                bot.send_photo(message.chat.id, photo, caption=feedback_request)
        except Exception:
            bot.reply_to(message, "مشکلی پیش اومد. لطفاً دوباره امتحان کن.")
    
    @bot.message_handler(func=lambda m: _match_cmd(m, 'phototip', 'پیشنهاد عکس', 'چطور عکس بهتر بشه', emoji='💡 پیشنهاد عکس'))
    def on_photo_tip(message):
        """پیشنهاد بهبود عکس پروفایل"""
        user_id = message.from_user.id
        
        # دریافت عکس پروفایل
        photo_path = telegram_profile_manager.get_profile_photo_path(user_id)
        
        if not photo_path or not os.path.exists(photo_path):
            photo_path = telegram_profile_manager.fetch_profile_photo(bot, user_id)
        
        if not photo_path or not os.path.exists(photo_path):
            bot.reply_to(message, "🤔 هنوز عکس پروفایلی نداری! اول یه عکس پروفایل بذار تا پیشنهاد بدم.")
            return
        
        # ارسال عکس با درخواست پیشنهاد
        try:
            tips = [
                "میخوام بدونم چطوری عکس پروفایلمو بهتر کنم. راهنماییم کن!",
                "نظرت درباره بهبود عکس پروفایلم چیه؟",
                "چطور میتونم عکس پروفایلم رو جذاب‌تر کنم؟",
                "پیشنهادی برای بهتر شدن عکس پروفایلم داری؟"
            ]
            import random
            tip_request = random.choice(tips)
            
            with open(photo_path, 'rb') as photo:
                bot.send_photo(message.chat.id, photo, caption=tip_request)
        except Exception:
            bot.reply_to(message, "مشکلی پیش اومد. لطفاً دوباره امتحان کن.")