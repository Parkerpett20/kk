# handlers/group.py
import telebot
import json
import os
import logging
from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup
from datetime import datetime

logger = logging.getLogger(__name__)

class GroupManager:
    """مدیریت اطلاعات گروه و اعضا"""
    def __init__(self, data_dir="data/groups"):
        self.data_dir = data_dir
        self._ensure_dir()
    
    def _ensure_dir(self):
        os.makedirs(self.data_dir, exist_ok=True)
    
    def _get_group_file(self, chat_id: int) -> str:
        return os.path.join(self.data_dir, f"{chat_id}.json")
    
    def _load_group(self, chat_id: int) -> dict:
        filepath = self._get_group_file(chat_id)
        if os.path.exists(filepath):
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"خطا در بارگذاری اطلاعات گروه {chat_id}: {e}")
        return {"chat_id": chat_id, "members": [], "messages": [], "info": {}}
    
    def _save_group(self, chat_id: int, data: dict):
        filepath = self._get_group_file(chat_id)
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"خطا در ذخیره اطلاعات گروه {chat_id}: {e}")
    
    def save_message(self, chat_id: int, user_id: int, username: str, text: str, timestamp: str = None, msg_type: str = "text"):
        """ذخیره پیام در تاریخچه گروه"""
        group = self._load_group(chat_id)
        if timestamp is None:
            timestamp = datetime.now().isoformat()
        
        message = {
            "user_id": user_id,
            "username": username,
            "text": text,
            "timestamp": timestamp,
            "type": msg_type
        }
        group["messages"].append(message)
        
        # محدود کردن تاریخچه به 1000 پیام آخر
        if len(group["messages"]) > 1000:
            group["messages"] = group["messages"][-1000:]
        
        self._save_group(chat_id, group)
    
    def update_members(self, chat_id: int, members: list):
        """بروزرسانی لیست اعضا"""
        group = self._load_group(chat_id)
        group["members"] = members
        self._save_group(chat_id, group)
    
    def update_info(self, chat_id: int, info: dict):
        """بروزرسانی اطلاعات گروه"""
        group = self._load_group(chat_id)
        group["info"] = info
        self._save_group(chat_id, group)
    
    def get_members(self, chat_id: int) -> list:
        """دریافت لیست اعضا"""
        group = self._load_group(chat_id)
        return group.get("members", [])
    
    def get_messages(self, chat_id: int, limit: int = 50) -> list:
        """دریافت تاریخچه پیام‌ها"""
        group = self._load_group(chat_id)
        return group.get("messages", [])[-limit:]
    
    def get_info(self, chat_id: int) -> dict:
        """دریافت اطلاعات گروه"""
        group = self._load_group(chat_id)
        return group.get("info", {})

group_manager = GroupManager()

def _is_admin_or_creator(bot: telebot.TeleBot, chat_id: int, user_id: int) -> bool:
    """Check if user is admin or creator of the group."""
    try:
        member = bot.get_chat_member(chat_id, user_id)
        return member.status in ['administrator', 'creator']
    except Exception:
        return False

def register_group_handler(bot: telebot.TeleBot):
    """ثبت هندلرهای مدیریت گروه"""
    
    # دریافت اطلاعات ربات برای پشتیبانی از دستورات با @botname
    _bot_info = {"username": None, "id": None}
    def get_bot_info():
        if _bot_info["username"] is None:
            info = bot.get_me()
            _bot_info["username"] = info.username.lower()
            _bot_info["id"] = info.id
        return _bot_info
    
    def strip_bot_mention(text: str) -> str:
        """حذف @botname از انتهای دستور"""
        bot_username = get_bot_info()["username"]
        if text and text.lower().endswith(f"@{bot_username}"):
            return text[:-len(f"@{bot_username}")].rstrip()
        return text
    
    # Import admin functions
    from tools.group_management import (
        warn_user, get_warnings, reset_warnings,
        ban_user, unban_user, mute_user, unmute_user, kick_user,
        set_rules, get_rules, clear_rules,
        set_note, get_note, list_notes, delete_note,
        set_filter, get_filter_response, list_filters, delete_filter,
        add_to_blacklist, remove_from_blacklist, get_blacklist, is_blacklisted,
        set_welcome_message, set_goodbye_message, toggle_welcome, get_welcome_message, get_goodbye_message,
        check_flood, check_blacklist_violation,
        generate_captcha, get_user_status, get_group_stats,
        _load_group_config, _save_group_config,
        get_full_members_list, get_full_admins_list, get_group_info_full
    )
    
    # ذخیره اطلاعات پروفایل اعضا
    def save_member_profile(chat_id: int, user_id: int, username: str, first_name: str, info: str):
        """ذخیره اطلاعات معرفی عضو جدید"""
        group = group_manager._load_group(chat_id)
        
        # پیدا کردن یا ایجاد پروفایل عضو
        member_found = False
        for member in group.get("members", []):
            if member.get("user_id") == user_id:
                member["introduction"] = info
                member["last_seen"] = datetime.now().isoformat()
                member_found = True
                break
        
        if not member_found:
            if "members" not in group:
                group["members"] = []
            group["members"].append({
                "user_id": user_id,
                "username": username,
                "name": first_name,
                "introduction": info,
                "joined_at": datetime.now().isoformat(),
                "last_seen": datetime.now().isoformat()
            })
        
        group_manager._save_group(chat_id, group)
    
    @bot.my_chat_member_handler()
    def on_my_chat_member(update):
        """وقتی ربات به گروه اضافه یا حذف می‌شود"""
        try:
            chat = update.chat
            new_status = update.new_chat_member.status
            old_status = update.old_chat_member.status
            
            # وقتی ربات به گروه اضافه می‌شود
            if new_status in ['member', 'administrator', 'creator'] and old_status in ['left', 'kicked']:
                bot.send_message(
                    chat.id,
                    "سلام! 👋 من «کارن» هستم، ربات هوشمند این گروه.\n"
                    "خوشحالم که اینجام! اگه سوالی دارید یا کمکی نیاز دارید، "
                    "فقط کافیه صدام کنید. ❤️"
                )
        except Exception as e:
            logger.error(f"خطا در هندلر عضویت ربات: {e}")
    
    @bot.chat_member_handler()
    def on_chat_member(update):
        """وقتی عضو جدیدی به گروه اضافه می‌شود"""
        try:
            chat = update.chat
            new_member = update.new_chat_member.user
            old_status = update.old_chat_member.status
            new_status = update.new_chat_member.status
            
            logger.info(f"chat_member update: chat={chat.id}, user={new_member.id}, old={old_status}, new={new_status}")
            
            # فقط وقتی عضو جدید اضافه می‌شود (نه وقتی حذف می‌شود یا وضعیتش تغییر می‌کند)
            if new_status in ['member', 'administrator'] and old_status in ['left', 'kicked']:
                # جلوگیری از پیام دادن برای خود ربات
                if new_member.id == get_bot_info()["id"]:
                    return
                
                # Check custom welcome message
                welcome_msg = get_welcome_message(chat.id)
                if not welcome_msg:
                    # نام کاربری یا نام نمایشی
                    display_name = new_member.first_name or "دوست عزیز"
                    username_text = f"@{new_member.username}" if new_member.username else ""
                    
                    # ارسال پیام خوش‌آمدگویی
                    welcome_msg = (
                        f"سلام {display_name} عزیز! 👋\n"
                        f"خوش اومدی به گروه! ❤️\n\n"
                        f"اگه دوست داشتی خودتو معرفی کن تا بیشتر باهات آشنا بشیم.\n"
                        f"مثلا بگو چه کاری انجام میدی، از چه چیزهایی خوشت میاد و..."
                    )
                else:
                    # Replace placeholders
                    display_name = new_member.first_name or "دوست عزیز"
                    username_text = f"@{new_member.username}" if new_member.username else ""
                    welcome_msg = welcome_msg.replace("{name}", display_name).replace("{username}", username_text)
                
                bot.send_message(chat.id, welcome_msg)
                
                # ذخیره اطلاعات عضو جدید
                group = group_manager._load_group(chat.id)
                if "members" not in group:
                    group["members"] = []
                
                # بررسی تکراری نبودن
                member_exists = any(m.get("user_id") == new_member.id for m in group["members"])
                if not member_exists:
                    group["members"].append({
                        "user_id": new_member.id,
                        "username": new_member.username or "",
                        "name": display_name,
                        "joined_at": datetime.now().isoformat(),
                        "last_seen": datetime.now().isoformat()
                    })
                    group_manager._save_group(chat.id, group)
                
                logger.info(f"عضو جدید به گروه {chat.id} اضافه شد: {display_name}")
            else:
                logger.info(f"chat_member update ignored: old={old_status}, new={new_status}")
                
        except Exception as e:
            logger.error(f"خطا در هندلر عضو جدید: {e}", exc_info=True)
    
    @bot.message_handler(commands=['members'])
    def get_members(message):
        """دریافت لیست اعضا"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        try:
            # بررسی ادمین بودن ربات
            bot_member = bot.get_chat_member(message.chat.id, get_bot_info()["id"])
            if bot_member.status not in ['administrator', 'creator']:
                bot.reply_to(message, "⚠️ ربات باید ادمین باشد تا بتواند لیست اعضا را دریافت کند.")
                return
            
            # دریافت تعداد اعضا
            member_count = bot.get_chat_member_count(message.chat.id)
            
            # دریافت اطلاعات اعضا (محدود به 50 نفر اول)
            members = []
            try:
                # استفاده از getChatMemberCount برای تعداد
                # برای لیست کامل نیاز به روش دیگری است
                members_info = group_manager.get_members(message.chat.id)
                
                response = f"👥 تعداد اعضا: {member_count}\n\n"
                
                if members_info:
                    response += "📋 لیست اعضا:\n"
                    for i, member in enumerate(members_info[:50], 1):
                        name = member.get('name', 'نامشخص')
                        username = member.get('username', '')
                        status = member.get('status', '')
                        if username:
                            response += f"{i}. [{name}](https://t.me/{username}) - {status}\n"
                        else:
                            response += f"{i}. {name} (فاقد یوزرنیم) - {status}\n"
                    
                    if len(members_info) > 50:
                        response += f"\n... و {len(members_info) - 50} نفر دیگر"
                else:
                    response += "💡 برای دریافت لیست کامل اعضا، از دستور /refresh_members استفاده کنید."
                
                bot.reply_to(message, response)
            except Exception as e:
                bot.reply_to(message, f"❌ خطا در دریافت لیست اعضا: {str(e)}")
                
        except Exception as e:
            bot.reply_to(message, f"❌ خطا: {str(e)}")
    
    @bot.message_handler(commands=['refresh_members'])
    def refresh_members(message):
        """بروزرسانی لیست اعضا"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        try:
            # بررسی ادمین بودن ربات
            bot_member = bot.get_chat_member(message.chat.id, get_bot_info()["id"])
            if bot_member.status not in ['administrator', 'creator']:
                bot.reply_to(message, "⚠️ ربات باید ادمین باشد تا بتواند لیست اعضا را بروزرسانی کند.")
                return
            
            # دریافت اطلاعات گروه
            chat_info = bot.get_chat(message.chat.id)
            
            # ذخیره اطلاعات گروه
            group_info = {
                "title": chat_info.title,
                "description": chat_info.description if hasattr(chat_info, 'description') else "",
                "member_count": bot.get_chat_member_count(message.chat.id),
                "last_updated": datetime.now().isoformat()
            }
            group_manager.update_info(message.chat.id, group_info)
            
            bot.reply_to(message, f"✅ اطلاعات گروه بروزرسانی شد.\n👥 تعداد اعضا: {group_info['member_count']}")
                
        except Exception as e:
            bot.reply_to(message, f"❌ خطا در بروزرسانی اعضا: {str(e)}")
    
    @bot.message_handler(commands=['chat_history'])
    def get_chat_history(message):
        """دریافت تاریخچه چت"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        try:
            # بررسی ادمین بودن ربات
            bot_member = bot.get_chat_member(message.chat.id, get_bot_info()["id"])
            if bot_member.status not in ['administrator', 'creator']:
                bot.reply_to(message, "⚠️ ربات باید ادمین باشد تا بتواند تاریخچه را مشاهده کند.")
                return
            
            # دریافت تاریخچه
            messages = group_manager.get_messages(message.chat.id, limit=20)
            
            if not messages:
                bot.reply_to(message, "📭 تاریخچه‌ای ذخیره نشده است.")
                return
            
            response = "📜 آخرین پیام‌ها:\n\n"
            for msg in messages:
                username = msg.get('username', 'نامشخص')
                text = msg.get('text', '')
                timestamp = msg.get('timestamp', '')
                response += f"👤 {username}: {text[:100]}\n"
            
            bot.reply_to(message, response)
                
        except Exception as e:
            bot.reply_to(message, f"❌ خطا: {str(e)}")
    
    @bot.message_handler(commands=['group_info'])
    def get_group_info(message):
        """دریافت اطلاعات گروه"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        try:
            # دریافت اطلاعات گروه
            info = group_manager.get_info(message.chat.id)
            
            if not info:
                bot.reply_to(message, "💡 اطلاعات گروه ذخیره نشده است. از /refresh_members استفاده کنید.")
                return
            
            response = f"ℹ️ اطلاعات گروه:\n\n"
            response += f"📝 نام: {info.get('title', 'نامشخص')}\n"
            response += f"👥 تعداد اعضا: {info.get('member_count', 'نامشخص')}\n"
            response += f"📅 آخرین بروزرسانی: {info.get('last_updated', 'نامشخص')}\n"
            
            if info.get('description'):
                response += f"📄 توضیحات: {info['description']}\n"
            
            bot.reply_to(message, response)
                
        except Exception as e:
            bot.reply_to(message, f"❌ خطا: {str(e)}")

    # =====================================================
    # Admin Command Handlers
    # =====================================================
    
    @bot.message_handler(commands=['warn'])
    def handle_warn(message):
        """Warn a user: /warn @username reason"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        if not message.reply_to_message:
            bot.reply_to(message, "⚠️ لطفاً روی پیام کاربر مورد نظر ریپلای کنید.\n\nنحوه استفاده: /warn @username دلیل")
            return
        
        target_user = message.reply_to_message.from_user
        parts = message.text.split(maxsplit=2)
        reason = parts[2] if len(parts) > 2 else "دلیل ذکر نشده"
        
        result = warn_user(message.chat.id, target_user.id, reason)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['unwarn'])
    def handle_unwarn(message):
        """Reset warnings: /unwarn @username"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        if not message.reply_to_message:
            bot.reply_to(message, "⚠️ لطفاً روی پیام کاربر مورد نظر ریپلای کنید.\n\nنحوه استفاده: /unwarn @username")
            return
        
        target_user = message.reply_to_message.from_user
        result = reset_warnings(message.chat.id, target_user.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['warnings'])
    def handle_warnings(message):
        """Get warnings for a user: /warnings @username"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not message.reply_to_message:
            bot.reply_to(message, "⚠️ لطفاً روی پیام کاربر مورد نظر ریپلای کنید.\n\nنحوه استفاده: /warnings @username")
            return
        
        target_user = message.reply_to_message.from_user
        result = get_warnings(message.chat.id, target_user.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['ban'])
    def handle_ban(message):
        """Ban a user: /ban @username reason"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        if not message.reply_to_message:
            bot.reply_to(message, "⚠️ لطفاً روی پیام کاربر مورد نظر ریپلای کنید.\n\nنحوه استفاده: /ban @username دلیل")
            return
        
        target_user = message.reply_to_message.from_user
        parts = message.text.split(maxsplit=2)
        reason = parts[2] if len(parts) > 2 else ""
        
        result = ban_user(message.chat.id, target_user.id, reason)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['unban'])
    def handle_unban(message):
        """Unban a user: /unban @username"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        if not message.reply_to_message:
            bot.reply_to(message, "⚠️ لطفاً روی پیام کاربر مورد نظر ریپلای کنید.\n\nنحوه استفاده: /unban @username")
            return
        
        target_user = message.reply_to_message.from_user
        result = unban_user(message.chat.id, target_user.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['mute'])
    def handle_mute(message):
        """Mute a user: /mute @username [minutes] [reason]"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        if not message.reply_to_message:
            bot.reply_to(message, "⚠️ لطفاً روی پیام کاربر مورد نظر ریپلای کنید.\n\nنحوه استفاده: /mute @username [دقیقه] [دلیل]")
            return
        
        target_user = message.reply_to_message.from_user
        parts = message.text.split(maxsplit=3)
        
        duration = 0
        reason = ""
        if len(parts) >= 3:
            try:
                duration = int(parts[2])
            except ValueError:
                reason = parts[2]
        if len(parts) >= 4:
            reason = parts[3]
        
        result = mute_user(message.chat.id, target_user.id, duration, reason)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['unmute'])
    def handle_unmute(message):
        """Unmute a user: /unmute @username"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        if not message.reply_to_message:
            bot.reply_to(message, "⚠️ لطفاً روی پیام کاربر مورد نظر ریپلای کنید.\n\nنحوه استفاده: /unmute @username")
            return
        
        target_user = message.reply_to_message.from_user
        result = unmute_user(message.chat.id, target_user.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['kick'])
    def handle_kick(message):
        """Kick a user: /kick @username"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        if not message.reply_to_message:
            bot.reply_to(message, "⚠️ لطفاً روی پیام کاربر مورد نظر ریپلای کنید.\n\nنحوه استفاده: /kick @username")
            return
        
        target_user = message.reply_to_message.from_user
        result = kick_user(message.chat.id, target_user.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['setrules'])
    def handle_setrules(message):
        """Set group rules: /setrules rules text"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        rules_text = message.text.replace('/setrules', '', 1).strip()
        if not rules_text:
            bot.reply_to(message, "⚠️ لطفاً متن قوانین را وارد کنید.\n\nنحوه استفاده: /setrules قوانین گروه...")
            return
        
        result = set_rules(message.chat.id, rules_text)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['rules'])
    def handle_rules(message):
        """Get group rules"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        result = get_rules(message.chat.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['clearrules'])
    def handle_clearrules(message):
        """Clear group rules"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        result = clear_rules(message.chat.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['setnote'])
    def handle_setnote(message):
        """Set a note: /setnote name content"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        parts = message.text.split(maxsplit=2)
        if len(parts) < 3:
            bot.reply_to(message, "⚠️ فرمت نادرست.\n\nنحوه استفاده: /setnote نام محتوا")
            return
        
        name = parts[1]
        content = parts[2]
        result = set_note(message.chat.id, name, content)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['note_'])
    def handle_getnote(message):
        """Get a note: /note_name"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        note_name = message.text.replace('/note_', '', 1).strip()
        if not note_name:
            bot.reply_to(message, "⚠️ لطفاً نام نوت را وارد کنید.")
            return
        
        content = get_note(message.chat.id, note_name)
        if content:
            bot.reply_to(message, content)
        else:
            bot.reply_to(message, f"❌ نوت '{note_name}' یافت نشد.")
    
    @bot.message_handler(commands=['notes'])
    def handle_notes(message):
        """List all notes"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        result = list_notes(message.chat.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['delnote'])
    def handle_delnote(message):
        """Delete a note: /delnote name"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            bot.reply_to(message, "⚠️ لطفاً نام نوت را وارد کنید.\n\nنحوه استفاده: /delnote نام")
            return
        
        name = parts[1].strip()
        result = delete_note(message.chat.id, name)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['setfilter'])
    def handle_setfilter(message):
        """Set a filter: /setfilter trigger response"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        parts = message.text.split(maxsplit=2)
        if len(parts) < 3:
            bot.reply_to(message, "⚠️ فرمت نادرست.\n\nنحوه استفاده: /setfilter کلمه پاسخ")
            return
        
        trigger = parts[1]
        response_text = parts[2]
        result = set_filter(message.chat.id, trigger, response_text)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['filters'])
    def handle_filters(message):
        """List all filters"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        result = list_filters(message.chat.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['delfilter'])
    def handle_delfilter(message):
        """Delete a filter: /delfilter trigger"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            bot.reply_to(message, "⚠️ لطفاً تریگر فیلتر را وارد کنید.\n\nنحوه استفاده: /delfilter کلمه")
            return
        
        trigger = parts[1].strip()
        result = delete_filter(message.chat.id, trigger)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['blacklist'])
    def handle_blacklist(message):
        """Get blacklist"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        result = get_blacklist(message.chat.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['addblacklist'])
    def handle_addblacklist(message):
        """Add word to blacklist: /addblacklist word"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            bot.reply_to(message, "⚠️ لطفاً کلمه مورد نظر را وارد کنید.\n\nنحوه استفاده: /addblacklist کلمه")
            return
        
        word = parts[1].strip()
        result = add_to_blacklist(message.chat.id, word)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['rmbblacklist'])
    def handle_rmbblacklist(message):
        """Remove word from blacklist: /rmbblacklist word"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            bot.reply_to(message, "⚠️ لطفاً کلمه مورد نظر را وارد کنید.\n\nنحوه استفاده: /rmbblacklist کلمه")
            return
        
        word = parts[1].strip()
        result = remove_from_blacklist(message.chat.id, word)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['setwelcome'])
    def handle_setwelcome(message):
        """Set welcome message: /setwelcome message"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        welcome_text = message.text.replace('/setwelcome', '', 1).strip()
        if not welcome_text:
            bot.reply_to(message, "⚠️ لطفاً متن پیام خوش‌آمدگویی را وارد کنید.\n\nمتغیرها: {name} - نام کاربر، {username} - یوزرنیم\n\nنحوه استفاده: /setwelcome سلام {name} عزیز!")
            return
        
        result = set_welcome_message(message.chat.id, welcome_text)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['setgoodbye'])
    def handle_setgoodbye(message):
        """Set goodbye message: /setgoodbye message"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        goodbye_text = message.text.replace('/setgoodbye', '', 1).strip()
        if not goodbye_text:
            bot.reply_to(message, "⚠️ لطفاً متن پیام خداحافظی را وارد کنید.\n\nمتغیرها: {name} - نام کاربر، {username} - یوزرنیم\n\nنحوه استفاده: /setgoodbye خداحافظ {name}!")
            return
        
        result = set_goodbye_message(message.chat.id, goodbye_text)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['togglewelcome'])
    def handle_togglewelcome(message):
        """Toggle welcome messages on/off"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        config = _load_group_config(message.chat.id)
        current = config.get("welcome_enabled", True)
        result = toggle_welcome(message.chat.id, not current)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['userstatus'])
    def handle_userstatus(message):
        """Get user status: /userstatus (reply to user)"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not message.reply_to_message:
            bot.reply_to(message, "⚠️ لطفاً روی پیام کاربر مورد نظر ریپلای کنید.\n\nنحوه استفاده: /userstatus")
            return
        
        target_user = message.reply_to_message.from_user
        result = get_user_status(message.chat.id, target_user.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['groupstats'])
    def handle_groupstats(message):
        """Get group statistics"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        result = get_group_stats(message.chat.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['adminhelp'])
    def handle_adminhelp(message):
        """Show admin help"""
        help_text = """
👑 راهنمای دستورات ادمین:

📋 مدیریت کاربران:
/warn - ارسال هشدار به کاربر (ریپلای کنید)
/unwarn - ریست هشدارهای کاربر (ریپلای کنید)
/warnings - مشاهده هشدارهای کاربر (ریپلای کنید)
/ban - بن کردن کاربر (ریپلای کنید)
/unban - خارج کردن از بن (ریپلای کنید)
/mute - موت کردن کاربر (ریپلای کنید)
/unmute - خارج کردن از موت (ریپلای کنید)
/kick - اخراج کاربر (ریپلای کنید)

📜 مدیریت قوانین:
/setrules - تنظیم قوانین گروه
/rules - مشاهده قوانین
/clearrules - پاک کردن قوانین

📝 مدیریت نوت‌ها:
/setnote - ذخیره نوت جدید
/notes - لیست نوت‌ها
/note_name - دریافت نوت
/delnote - حذف نوت

🔍 مدیریت فیلترها:
/setfilter - تنظیم فیلتر
/filters - لیست فیلترها
/delfilter - حذف فیلتر

🚫 مدیریت لیست سیاه:
/addblacklist - اضافه کردن به لیست سیاه
/rmbblacklist - حذف از لیست سیاه
/blacklist - مشاهده لیست سیاه

👋 مدیریت پیام‌ها:
/setwelcome - تنظیم پیام خوش‌آمدگویی
/setgoodbye - تنظیم پیام خداحافظی
/togglewelcome - فعال/غیرفعال کردن خوش‌آمدگویی

👥 لیست اعبا (با Telethon):
/allmembers - لیست کامل اعضای گروه
/alladmins - لیست کامل ادمین‌ها
/groupinfo - اطلاعات کامل گروه
/findmember نام - جستجوی عضو خاص

📊 اطلاعات:
/userstatus - وضعیت کاربر (ریپلای کنید)
/groupstats - آمار گروه
/adminhelp - نمایش این راهنما
        """
        bot.reply_to(message, help_text)
    
    # =====================================================
    # Full Member List Commands (via Telethon or Bot API)
    # =====================================================
    @bot.message_handler(commands=['allmembers', 'all_members'])
    def handle_allmembers(message):
        """دریافت لیست کامل اعضای گروه"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        # بررسی ادمین بودن ربات
        bot_member = bot.get_chat_member(message.chat.id, get_bot_info()["id"])
        if bot_member.status not in ['administrator', 'creator']:
            bot.reply_to(message, "⚠️ ربات باید ادمین گروه باشد تا بتواند لیست اعضا رو دریافت کنه.")
            return
        
        try:
            result, file_path, members = get_full_members_list(message.chat.id, bot)
            
            if not members:
                bot.reply_to(message, result)
                return
            
            # ساخت لیست متنی + دکمه‌های inline در یک پیام
            text = f"👥 لیست کامل اعضای گروه ({len(members)} نفر):\n\n"
            text += "روی دکمه زیر هر عضو کلیک کنید:\n"
            text += "─────────────────\n"
            
            markup = InlineKeyboardMarkup(row_width=1)
            
            for i, member in enumerate(members, 1):
                name = member.get('first_name', '') or member.get('username', '') or 'نامشخص'
                username = member.get('username', '')
                is_bot = "🤖" if member.get('is_bot') else ""
                
                # اضافه کردن نام عضو به متن
                if username:
                    text += f"{i}. {name} {is_bot}\n"
                    # دکمه ارسال پیام
                    markup.add(InlineKeyboardButton(
                        f"📩 ارسال پیام به {name}",
                        url=f"https://t.me/{username}"
                    ))
                else:
                    text += f"{i}. {name} (فاقد یوزرنیم) {is_bot}\n"
            
            # ارسال یک پیام با تمام دکمه‌ها
            bot.send_message(message.chat.id, text, reply_markup=markup)
            
            # ارسال فایل اگر لیست طولانی بود
            if file_path and os.path.exists(file_path):
                try:
                    with open(file_path, 'rb') as f:
                        bot.send_document(message.chat.id, f, caption="📋 لیست کامل اعضای گروه")
                    os.remove(file_path)
                except Exception as e:
                    logger.error(f"Error sending members file: {e}")
        except Exception as e:
            # اگر get_full_members_list خطا داد، از Bot API استفاده کن
            try:
                member_count = bot.get_chat_member_count(message.chat.id)
                bot.reply_to(message, f"👥 تعداد اعضای گروه: {member_count} نفر\n\n💡 برای دریافت لیست کامل، ربات باید ادمین باشد و Telethon پیکربندی شده باشد.")
            except Exception as e2:
                bot.reply_to(message, f"❌ خطا در دریافت لیست اعضا: {str(e)}")
    
    @bot.message_handler(commands=['alladmins', 'all_admins'])
    def handle_alladmins(message):
        """دریافت لیست کامل ادمین‌های گروه"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        # بررسی ادمین بودن ربات
        bot_member = bot.get_chat_member(message.chat.id, get_bot_info()["id"])
        if bot_member.status not in ['administrator', 'creator']:
            bot.reply_to(message, "⚠️ ربات باید ادمین گروه باشد تا بتواند لیست ادمین‌ها رو دریافت کنه.")
            return
        
        try:
            result, file_path, admins = get_full_admins_list(message.chat.id, bot)
            
            if not admins:
                bot.reply_to(message, result)
                return
            
            # ساخت لیست متنی + دکمه‌های inline در یک پیام
            text = f"👑 لیست کامل ادمین‌های گروه ({len(admins)} نفر):\n\n"
            text += "روی دکمه زیر هر ادمین کلیک کنید:\n"
            text += "─────────────────\n"
            
            markup = InlineKeyboardMarkup(row_width=1)
            
            for i, admin in enumerate(admins, 1):
                name = admin.get('first_name', '') or admin.get('username', '') or 'نامشخص'
                username = admin.get('username', '')
                is_bot = "🤖" if admin.get('is_bot') else ""
                status = admin.get('status', '')
                
                status_text = ""
                if status == 'creator':
                    status_text = " 👑مالک"
                elif status == 'administrator':
                    status_text = " ⚡ادمین"
                
                # اضافه کردن نام ادمین به متن
                if username:
                    text += f"{i}. {name} {is_bot}{status_text}\n"
                    # دکمه ارسال پیام
                    markup.add(InlineKeyboardButton(
                        f"📩 ارسال پیام به {name}",
                        url=f"https://t.me/{username}"
                    ))
                else:
                    text += f"{i}. {name} (فاقد یوزرنیم) {is_bot}{status_text}\n"
            
            # ارسال یک پیام با تمام دکمه‌ها
            bot.send_message(message.chat.id, text, reply_markup=markup)
            
            # ارسال فایل اگر لیست طولانی بود
            if file_path and os.path.exists(file_path):
                try:
                    with open(file_path, 'rb') as f:
                        bot.send_document(message.chat.id, f, caption="👑 لیست کامل ادمین‌های گروه")
                    os.remove(file_path)
                except Exception as e:
                    logger.error(f"Error sending admins file: {e}")
        except Exception as e:
            bot.reply_to(message, f"❌ خطا در دریافت لیست ادمین‌ها: {str(e)}")
    
    @bot.message_handler(commands=['groupinfo', 'group_info_full'])
    def handle_groupinfo(message):
        """دریافت اطلاعات کامل گروه"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        result = get_group_info_full(message.chat.id)
        bot.reply_to(message, result)
    
    @bot.message_handler(commands=['findmember'])
    def handle_findmember(message):
        """جستجوی عضو خاص"""
        if message.chat.type not in ['group', 'supergroup']:
            bot.reply_to(message, "⚠️ این دستور فقط در گروه‌ها کار می‌کند.")
            return
        
        if not _is_admin_or_creator(bot, message.chat.id, message.from_user.id):
            bot.reply_to(message, "⚠️ فقط ادمین‌ها می‌توانند از این دستور استفاده کنند.")
            return
        
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            bot.reply_to(message, "⚠️ لطفاً نام یا یوزرنیم کاربر را وارد کنید.\n\nنحوه استفاده: /findmember نام")
            return
        
        search_term = parts[1].strip().lower()
        
        from tools.telethon_client import is_available as telethon_available, get_chat_members
        
        if not telethon_available():
            bot.reply_to(message, "❌ برای جستجو، باید Telethon پیکربندی شده باشد.")
            return
        
        try:
            members = get_chat_members(message.chat.id)
            
            if not members:
                bot.reply_to(message, "❌ نتونستم لیست اعضا رو دریافت کنم.")
                return
            
            found_members = []
            for member in members:
                first_name = (member.get('first_name') or '').lower()
                last_name = (member.get('last_name') or '').lower()
                username = (member.get('username') or '').lower()
                
                if (search_term in first_name or 
                    search_term in last_name or 
                    search_term in username):
                    found_members.append(member)
            
            if not found_members:
                bot.reply_to(message, f"❌ کاربری با نام '{parts[1].strip()}' یافت نشد.")
                return
            
            response = f"🔍 نتایج جستجو برای '{parts[1].strip()}' ({len(found_members)} نفر):\n\n"
            
            for member in found_members[:10]:  # محدود به 10 نفر
                name = member.get('first_name', '') or member.get('username', '') or 'نامشخص'
                username = member.get('username', '')
                is_bot = "🤖" if member.get('is_bot') else ""
                
                if username:
                    response += f"• [{name}](https://t.me/{username}) {is_bot}\n"
                else:
                    response += f"• {name} (فاقد یوزرنیم) {is_bot}\n"
            
            if len(found_members) > 10:
                response += f"\n... و {len(found_members) - 10} نفر دیگر"
            
            bot.reply_to(message, response)
            
        except Exception as e:
            bot.reply_to(message, f"❌ خطا در جستجو: {str(e)}")
    
    # =====================================================
    # Message Monitor for Flood & Blacklist
    # =====================================================
    @bot.message_handler(func=lambda message: message.chat.type in ['group', 'supergroup'] and message.text and not message.text.startswith('/'))
    def monitor_messages(message):
        """Monitor messages for flood and blacklist violations"""
        try:
            chat_id = message.chat.id
            user_id = message.from_user.id
            text = message.text
            
            # Skip admin messages
            if _is_admin_or_creator(bot, chat_id, user_id):
                return
            
            # Check flood
            if check_flood(chat_id, user_id):
                try:
                    mute_user(chat_id, user_id, duration_minutes=5, reason="ارسال پیام زیاد (فلاود)")
                    bot.delete_message(chat_id, message.message_id)
                    bot.send_message(chat_id, f"🔇 کاربر {user_id} به مدت 5 دقیقه موت شد به دلیل ارسال پیام زیاد.")
                except Exception as e:
                    logger.error(f"Error in flood control: {e}")
                return
            
            # Check blacklist
            if check_blacklist_violation(chat_id, text):
                try:
                    bot.delete_message(chat_id, message.message_id)
                    warn_result = warn_user(chat_id, user_id, "ارسال پیام غیرمجاز (لیست سیاه)")
                    bot.send_message(chat_id, f"🚫 پیام حذف شد.\n{warn_result}")
                except Exception as e:
                    logger.error(f"Error in blacklist control: {e}")
                return
            
            # Check filters
            filter_response = get_filter_response(chat_id, text)
            if filter_response:
                bot.reply_to(message, filter_response)
                
        except Exception as e:
            logger.error(f"Error in message monitor: {e}")
