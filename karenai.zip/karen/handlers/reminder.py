# handlers/reminder.py
"""
هندلر دستورات یادآوری
"""

import logging
import re
from datetime import datetime, timedelta
import pytz
from core.scheduler import reminder_scheduler
from handlers.commands import _match_cmd

logger = logging.getLogger(__name__)

# الگوهای پذیرفتن دستور
REMINDER_PATTERNS = [
    # "یادآوری کن که ... در ساعت 15:30"
    r'یادآوری\s+کن\s+(?:که\s+)?(.+?)\s+در\s+ساعت\s+(\d{1,2}):(\d{2})',
    
    # "یادآوری ... ساعت 15:30"
    r'یادآوری\s+(.+?)\s+ساعت\s+(\d{1,2}):(\d{2})',
    
    # "برایم یادآوری کن ... در ساعت 15:30"
    r'برایم\s+یادآوری\s+کن\s+(?:که\s+)?(.+?)\s+در\s+ساعت\s+(\d{1,2}):(\d{2})',
]

# الگوهای زمان نسبی
RELATIVE_TIME_PATTERNS = [
    # دقیقه + بعد
    r'(\d+)\s*دقیقه\s*بعد\s*یادم\s*بنداز\s+(.+)',
    r'(\d+)\s*دقیقه\s*بعد\s*یام\s*بنداز\s+(.+)',
    r'(\d+)\s*دقیقه\s*بعد\s*یادآوری\s+کن\s+(?:که\s+)?(.+)',
    # دقیقه + دیگه
    r'(\d+)\s*دقیقه\s*دیگه\s*یادم\s*بنداز\s+(.+)',
    r'(\d+)\s*دقیقه\s*دیگه\s*یام\s*بنداز\s+(.+)',
    r'(\d+)\s*دقیقه\s*دیگه\s*یادآوری\s+کن\s+(?:که\s+)?(.+)',
    r'(\d+)\s*دقیقه\s*دیگه\s*یادآوری\s+کن\s+(.+)',
    # ساعت + بعد
    r'(\d+)\s*ساعت\s*بعد\s*یادم\s*بنداز\s+(.+)',
    r'(\d+)\s*ساعت\s*بعد\s*یام\s*بنداز\s+(.+)',
    r'(\d+)\s*ساعت\s*بعد\s*یادآوری\s+کن\s+(?:که\s+)?(.+)',
    # ساعت + دیگه
    r'(\d+)\s*ساعت\s*دیگه\s*یادم\s*بنداز\s+(.+)',
    r'(\d+)\s*ساعت\s*دیگه\s*یام\s*بنداز\s+(.+)',
    r'(\d+)\s*ساعت\s*دیگه\s*یادآوری\s+کن\s+(?:که\s+)?(.+)',
    r'(\d+)\s*ساعت\s*دیگه\s*یادآوری\s+کن\s+(.+)',
]

TOMORROW_PATTERNS = [
    r'فردا\s+ساعت\s+(\d{1,2}):(\d{2})',
    r'فردا\s+در\s+ساعت\s+(\d{1,2}):(\d{2})',
]

LIST_PATTERNS = [
    r'یادآوری\s*های\s*(من|خود)',
    r'لیست\s+یادآوری\s*ها',
    r'یادآوری\s*های\s+بعدی',
]


def parse_reminder_time(hour: int, minute: int, for_tomorrow: bool = False) -> datetime:
    """تبدیل ساعت و دقیقه به datetime"""
    tz = pytz.timezone('Asia/Tehran')
    now = datetime.now(tz)
    
    reminder_datetime = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    
    # اگر زمان گذشته‌ای است، برای فردا برنامه‌ریزی کن
    if reminder_datetime <= now or for_tomorrow:
        reminder_datetime += timedelta(days=1)
    
    return reminder_datetime


def extract_reminder_info(text: str):
    """استخراج اطلاعات یادآوری از متن"""
    
    # ابتدا بررسی الگوهای زمان نسبی
    for pattern in RELATIVE_TIME_PATTERNS:
        match = re.search(pattern, text)
        if match:
            amount = int(match.group(1))
            message = match.group(2).strip()
            
            # تشخیص دقیقه یا ساعت
            if 'دقیقه' in pattern:
                run_time = datetime.now(pytz.timezone('Asia/Tehran')) + timedelta(minutes=amount)
            else:
                run_time = datetime.now(pytz.timezone('Asia/Tehran')) + timedelta(hours=amount)
            
            return message, run_time
    
    # ابتدا بررسی کنید که آیا برای فردا است یا نه
    for_tomorrow = 'فردا' in text
    
    # بررسی الگوهای یادآوری
    for pattern in REMINDER_PATTERNS:
        match = re.search(pattern, text)
        if match:
            message = match.group(1).strip()
            hour = int(match.group(2))
            minute = int(match.group(3))
            
            if 0 <= hour <= 23 and 0 <= minute <= 59:
                run_time = parse_reminder_time(hour, minute, for_tomorrow)
                return message, run_time
    
    return None, None


def is_reminder_command(text: str) -> bool:
    """بررسی اینکه آیا متن حاوی دستور یادآوری است"""
    return any(re.search(pattern, text) for pattern in REMINDER_PATTERNS + RELATIVE_TIME_PATTERNS + LIST_PATTERNS)


def register_reminder_handler(bot):
    """ثبت هندلر یادآوری"""
    
    @bot.message_handler(
        func=lambda message: is_reminder_command(message.text)
    )
    def handle_reminder(message):
        user_id = message.from_user.id
        text = message.text
        
        # بررسی دستور لیست کردن
        if any(re.search(pattern, text) for pattern in LIST_PATTERNS):
            handle_list_reminders(bot, message)
            return
        
        # استخراج اطلاعات یادآوری
        reminder_message, run_time = extract_reminder_info(text)
        
        if reminder_message and run_time:
            # محاسبه زمان باقی‌مانده برای نمایش بهتر
            now = datetime.now(pytz.timezone('Asia/Tehran'))
            time_diff = run_time - now
            
            if time_diff.total_seconds() < 3600:
                minutes = int(time_diff.total_seconds() / 60)
                time_display = f"{minutes} دقیقه دیگر"
            else:
                hours = int(time_diff.total_seconds() / 3600)
                minutes = int((time_diff.total_seconds() % 3600) / 60)
                time_display = f"{hours} ساعت و {minutes} دقیقه دیگر"
            
            # اضافه کردن یادآوری
            reminder_id = reminder_scheduler.add_reminder(
                user_id=user_id,
                message=reminder_message,
                run_time=run_time
            )
            
            # ارسال تایید
            response = (
                f"✅ یادآوری ثبت شد!\n"
                f"📝 متن: {reminder_message}\n"
                f"⏰ زمان: {time_display}\n\n"
                f"🆔 ID: {reminder_id}"
            )
            bot.reply_to(message, response)
            logger.info(f"✅ یادآوری ثبت شد برای {user_id}: {reminder_message}")
        else:
            bot.reply_to(
                message,
                "❌ متوجه نشدم!\n"
                "لطفاً این فرمت‌ها را استفاده کنید:\n\n"
                "🔹 زمان مشخص:\n"
                "  یادآوری کن که [کار] در ساعت HH:MM\n"
                "  یادآوری [کار] ساعت HH:MM\n\n"
                "🔹 زمان نسبی:\n"
                "  5 دقیقه بعد یادم بنداز [کار]\n"
                "  2 ساعت دیگه یادآوری کن [کار]\n\n"
                "مثال:\n"
                "یادآوری کن که دارو بخور در ساعت 08:00\n"
                "5 دقیقه بعد یادم بنداز آب بخورم"
            )
    
    
    def handle_list_reminders(bot, message):
        """نمایش لیست یادآوری‌ها"""
        user_id = message.from_user.id
        reminders = reminder_scheduler.get_pending_reminders(user_id)
        
        if not reminders:
            bot.reply_to(message, "📭 هیچ یادآوری آینده‌ای وجود ندارد")
            return
        
        tz = pytz.timezone('Asia/Tehran')
        response = "📋 یادآوری‌های شما:\n\n"
        
        for i, reminder in enumerate(reminders, 1):
            formatted_time = reminder.run_time.astimezone(tz).strftime("%Y-%m-%d %H:%M")
            response += (
                f"{i}️⃣ {reminder.message}\n"
                f"⏰ {formatted_time}\n"
                f"🆔 ID: {reminder.reminder_id}\n\n"
            )
        
        bot.reply_to(message, response)
    
    
    @bot.message_handler(
        func=lambda m: _match_cmd(m, 'delete_reminder', 'remove_reminder', 'حذف_یادآوری', emoji='🗑️ حذف یادآوری')
    )
    def handle_delete_reminder(message):
        """حذف یادآوری"""
        args = message.text.split()
        if len(args) < 2:
            bot.reply_to(
                message,
                "❌ ID یادآوری را مشخص کنید\n"
                "مثال: /delete_reminder reminder_id_here"
            )
            return
        
        reminder_id = args[1]
        if reminder_scheduler.delete_reminder(reminder_id):
            bot.reply_to(message, f"✅ یادآوری {reminder_id} حذف شد")
        else:
            bot.reply_to(message, f"❌ یادآوری {reminder_id} پیدا نشد")


def send_reminder_callback(user_id: int, message: str, bot):
    """Callback برای ارسال یادآوری از طریق تلگرام"""
    try:
        reminder_text = (
            f"🔔 **یادآوری شما**\n\n"
            f"📝 {message}\n\n"
            f"⏰ زمان: {datetime.now().strftime('%H:%M')}"
        )
        bot.send_message(user_id, reminder_text)
        logger.info(f"📬 یادآوری ارسال شد برای {user_id}")
    except Exception as e:
        logger.error(f"❌ خطا در ارسال یادآوری: {e}")
