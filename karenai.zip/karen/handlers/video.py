# handlers/video.py
import logging
import telebot
from google.genai import types
from core.errors import get_friendly_error_message
from core.executor import AgentExecutor
from core.streaming import handle_stream_delivery
from handlers.group import group_manager
from utils.message_context import build_user_text_with_context

def register_video_handler(bot: telebot.TeleBot):
    @bot.message_handler(content_types=['video'])
    def on_video(message):
        # ذخیره ویدیو در تاریخچه گروه
        if message.chat.type in ['group', 'supergroup']:
            try:
                username = message.from_user.username or message.from_user.first_name or "نامشخص"
                caption = message.caption or "[ویدیو]"
                group_manager.save_message(
                    chat_id=message.chat.id,
                    user_id=message.from_user.id,
                    username=username,
                    text=caption,
                    msg_type="video"
                )
            except Exception as e:
                pass
        
        sent_msg = bot.reply_to(message, "⏳ دارم ویدیوت رو بررسی می‌کنم (پردازش ویدیو ممکن است چند ثانیه بیشتر طول بکشد)...")
        try:
            file_id = message.video.file_id
            mime_type = message.video.mime_type or "video/mp4"
            
            file_info = bot.get_file(file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            
            video_part = types.Part.from_bytes(
                data=downloaded_file,
                mime_type=mime_type
            )
            
            caption = message.caption or "این ویدیو رو نگاه کن و رخدادهاش رو توضیح بده."
            user_text = build_user_text_with_context(message, caption)
            stream, plan = AgentExecutor.run_stream(
                chat_id=message.chat.id,
                user_text=user_text,
                attachments=[video_part],
                user_id=message.from_user.id
            )
            
            status = "🎬 تحلیل چندرسانه‌ای ویدیو"
            bot.edit_message_text(f"[{status}]\n✍️...", message.chat.id, sent_msg.message_id)
            
            handle_stream_delivery(bot, message.chat.id, sent_msg.message_id, stream, user_text)
            
        except Exception as e:
            logging.getLogger(__name__).error(f"Error processing video: {e}", exc_info=True)
            friendly = get_friendly_error_message(message.from_user.id, e)
            bot.edit_message_text(friendly, message.chat.id, sent_msg.message_id)