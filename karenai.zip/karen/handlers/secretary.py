import logging
import telebot
from telebot.types import ForceReply
from memory.user_settings import user_settings
from core.errors import get_friendly_error_message
from tools.userbot_manager import (
    is_available as userbot_available,
    start_sign_in,
    complete_sign_in,
    complete_2fa_sign_in,
    resend_code_sms,
    is_authorized,
    reconnect_user,
    get_user_info,
    delete_session,
)
from tools.secretary_service import (
    get_secretary_mode,
    set_secretary_mode,
    is_secretary_enabled,
    start_monitoring,
    stop_monitoring,
    is_monitoring,
    send_reply,
)


def _get_secretary_status_text(user_id: int) -> str:
    """ساخت متن وضعیت منشی"""
    enabled = is_secretary_enabled(user_id)
    mode = get_secretary_mode(user_id)
    monitoring = is_monitoring(user_id)
    authorized = is_authorized(user_id)

    mode_names = {
        "always": "همیشه جواب بده 🔔",
        "offline": "فقط وقتی آفلاینم 🌙",
        "manual": "فقط فوروارد کن (دستی) 📨"
    }

    if enabled and authorized:
        status_icon = "✅"
        status_text = "فعال"
    elif enabled and not authorized:
        status_icon = "⚠️"
        status_text = "نیاز به ورود مجدد"
    else:
        status_icon = "🔕"
        status_text = "غیرفعال"

    text = f"🔔 منشی شخصی کارن\n\n"
    text += f"{status_icon} وضعیت: {status_text}\n"
    text += f"🎯 حالت: {mode_names.get(mode, mode)}\n"

    if monitoring:
        text += f"👁️ مانیتورینگ: فعال\n"
    else:
        text += f"👁️ مانیتورینگ: غیرفعال\n"

    return text


def _get_secretary_keyboard(user_id: int):
    """ساخت کیبورد منشی"""
    markup = telebot.types.InlineKeyboardMarkup(row_width=1)

    enabled = is_secretary_enabled(user_id)
    authorized = is_authorized(user_id)

    if not authorized:
        if userbot_available():
            markup.add(telebot.types.InlineKeyboardButton(
                "📱 ورود با شماره تلفن",
                callback_data="secretary_phone"
            ))
        else:
            markup.add(telebot.types.InlineKeyboardButton(
                "⚠️ Telethon پیکربندی نشده",
                callback_data="secretary_noop"
            ))
    else:
        if enabled:
            markup.add(telebot.types.InlineKeyboardButton(
                "🔕 غیرفعال‌سازی منشی",
                callback_data="secretary_disable"
            ))
        else:
            markup.add(telebot.types.InlineKeyboardButton(
                "✅ فعال‌سازی منشی",
                callback_data="secretary_enable"
            ))

        mode = get_secretary_mode(user_id)
        markup.add(telebot.types.InlineKeyboardButton(
            f"🎯 تغییر حالت (فعلی: {mode})",
            callback_data="secretary_mode_menu"
        ))

        markup.add(telebot.types.InlineKeyboardButton(
            "👤 اطلاعات اکانت متصل",
            callback_data="secretary_info"
        ))

        markup.add(telebot.types.InlineKeyboardButton(
            "🔌 قطع اتصال و حذف سشن",
            callback_data="secretary_disconnect"
        ))

    markup.add(telebot.types.InlineKeyboardButton(
        "🔙 بازگشت به تنظیمات",
        callback_data="settings_back"
    ))

    return markup


def _get_mode_keyboard():
    """کیبورد انتخاب حالت منشی"""
    markup = telebot.types.InlineKeyboardMarkup(row_width=1)
    markup.add(telebot.types.InlineKeyboardButton(
        "🔔 همیشه جواب بده",
        callback_data="secretary_mode_always"
    ))
    markup.add(telebot.types.InlineKeyboardButton(
        "🌙 فقط وقتی آفلاینم",
        callback_data="secretary_mode_offline"
    ))
    markup.add(telebot.types.InlineKeyboardButton(
        "📨 فقط فوروارد کن (دستی)",
        callback_data="secretary_mode_manual"
    ))
    markup.add(telebot.types.InlineKeyboardButton(
        "🔙 بازگشت",
        callback_data="settings_secretary"
    ))
    return markup


def register_secretary_handlers(bot: telebot.TeleBot):
    """ثبت تمام هندلرهای منشی شخصی"""

    @bot.callback_query_handler(func=lambda call: call.data == 'settings_secretary')
    def on_secretary_settings(call):
        user_id = call.from_user.id
        text = _get_secretary_status_text(user_id)
        markup = _get_secretary_keyboard(user_id)
        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)
        except Exception:
            bot.send_message(call.message.chat.id, text, reply_markup=markup)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == 'settings_back')
    def on_settings_back(call):
        """بازگشت به منوی تنظیمات اصلی"""
        from handlers.commands import get_settings_text, get_settings_keyboard
        user_id = call.from_user.id
        text = get_settings_text(user_id)
        markup = get_settings_keyboard(user_id)
        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)
        except Exception:
            bot.send_message(call.message.chat.id, text, reply_markup=markup)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == 'secretary_noop')
    def on_secretary_noop(call):
        bot.answer_callback_query(call.id, "Telethon پیکربندی نشده است", show_alert=True)

    @bot.callback_query_handler(func=lambda call: call.data == 'secretary_phone')
    def on_secretary_phone(call):
        """درخواست شماره تلفن"""
        try:
            bot.send_message(
                call.message.chat.id,
                "📱 برای فعال‌سازی منشی، شماره تلفن تلگرام خود را وارد کنید.\n\n"
                "مثال: +989121234567 یا 09121234567\n\n"
                "⚠️ این شماره باید به اکانت تلگرام شما متصل باشد.",
                reply_markup=ForceReply()
            )
        except Exception:
            bot.send_message(call.message.chat.id, "📱 لطفاً شماره تلفن خود را وارد کنید:")
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == 'secretary_enable')
    def on_secretary_enable(call):
        """فعال‌سازی منشی"""
        user_id = call.from_user.id

        if not is_authorized(user_id):
            bot.answer_callback_query(call.id, "ابتدا باید وارد شوید", show_alert=True)
            return

        user_settings.set_setting(user_id, 'secretary_enabled', True)
        user_settings.save()

        if start_monitoring(user_id, bot, user_id):
            bot.answer_callback_query(call.id, "منشی فعال شد ✅")
        else:
            bot.answer_callback_query(call.id, "خطا در شروع مانیتورینگ", show_alert=True)

        text = _get_secretary_status_text(user_id)
        markup = _get_secretary_keyboard(user_id)
        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)
        except Exception:
            bot.send_message(call.message.chat.id, text, reply_markup=markup)

    @bot.callback_query_handler(func=lambda call: call.data == 'secretary_disable')
    def on_secretary_disable(call):
        """غیرفعال‌سازی منشی"""
        user_id = call.from_user.id
        user_settings.set_setting(user_id, 'secretary_enabled', False)
        user_settings.save()
        stop_monitoring(user_id)
        bot.answer_callback_query(call.id, "منشی غیرفعال شد")

        text = _get_secretary_status_text(user_id)
        markup = _get_secretary_keyboard(user_id)
        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)
        except Exception:
            bot.send_message(call.message.chat.id, text, reply_markup=markup)

    @bot.callback_query_handler(func=lambda call: call.data == 'secretary_mode_menu')
    def on_secretary_mode_menu(call):
        """نمایش منوی انتخاب حالت"""
        text = (
            "🎯 انتخاب حالت منشی\n\n"
            "🔔 همیشه: به تمام پیام‌ها جواب بده\n"
            "🌙 آفلاین: فقط وقتی آنلاین نیستی جواب بده\n"
            "📨 دستی: فقط پیام‌ها را فوروارد کن"
        )
        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=_get_mode_keyboard())
        except Exception:
            bot.send_message(call.message.chat.id, text, reply_markup=_get_mode_keyboard())
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data.startswith('secretary_mode_'))
    def on_secretary_mode_select(call):
        """انتخاب حالت منشی"""
        user_id = call.from_user.id
        mode = call.data.replace('secretary_mode_', '')

        if mode in ['always', 'offline', 'manual']:
            set_secretary_mode(user_id, mode)
            mode_names = {
                "always": "همیشه جواب بده",
                "offline": "فقط وقتی آفلاینم",
                "manual": "فقط فوروارد کن"
            }
            bot.answer_callback_query(call.id, f"حالت تغییر کرد: {mode_names[mode]}")

            text = _get_secretary_status_text(user_id)
            markup = _get_secretary_keyboard(user_id)
            try:
                bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)
            except Exception:
                bot.send_message(call.message.chat.id, text, reply_markup=markup)

    @bot.callback_query_handler(func=lambda call: call.data == 'secretary_info')
    def on_secretary_info(call):
        """نمایش اطلاعات اکانت متصل"""
        user_id = call.from_user.id
        info = get_user_info(user_id)

        if info:
            text = "👤 اطلاعات اکانت متصل:\n\n"
            text += f"📝 نام: {info.get('first_name', '')} {info.get('last_name', '')}\n"
            text += f"🔗 یوزرنیم: @{info.get('username', 'ندارد')}\n"
            text += f"📱 شماره: {info.get('phone', 'ندارد')}\n"
            text += f"🟢 آنلاین: {'بله' if info.get('is_online') else 'خیر'}\n"
        else:
            text = "❌ اطلاعاتی یافت نشد. ممکن است نیاز به ورود مجدد داشته باشید."

        markup = _get_secretary_keyboard(user_id)
        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)
        except Exception:
            bot.send_message(call.message.chat.id, text, reply_markup=markup)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == 'secretary_disconnect')
    def on_secretary_disconnect(call):
        """قطع اتصال و حذف سشن"""
        user_id = call.from_user.id
        stop_monitoring(user_id)
        user_settings.set_setting(user_id, 'secretary_enabled', False)
        user_settings.save()
        delete_session(user_id)
        bot.answer_callback_query(call.id, "اتصال قطع و سشن حذف شد")

        text = _get_secretary_status_text(user_id)
        markup = _get_secretary_keyboard(user_id)
        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)
        except Exception:
            bot.send_message(call.message.chat.id, text, reply_markup=markup)

    # هندلر دریافت شماره تلفن
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and 'شماره تلفن' in m.reply_to_message.text and ' ForceReply' not in str(m.reply_to_message.text))
    def on_phone_received(message):
        """دریافت شماره تلفن و شروع فرآیند ورود"""
        user_id = message.from_user.id
        phone = message.text.strip()

        if not userbot_available():
            bot.reply_to(message, "❌ Telethon پیکربندی نشده است. لطفاً با ادمین تماس بگیرید.")
            return

        user_settings.set_setting(user_id, 'secretary_phone', phone)
        user_settings.save()

        ok, error_msg = start_sign_in(user_id, phone)
        if ok:
            bot.send_message(
                message.chat.id,
                "✅ کد تایید ارسال شد!\n\n"
                "📱 لطفاً کد دریافتی در تلگرام را وارد کنید.\n\n"
                "⚠️ نکته مهم: برای جلوگیری از مسدود شدن ورود توسط تلگرام،\n"
                "کد را با فاصله بین اعداد وارد کنید. مثال:\n"
                "❌ 12345\n"
                "✅ 1 2 3 4 5\n\n"
                "یا می‌توانید با خط تیره وارد کنید: 1-2-3-4-5",
                reply_markup=ForceReply()
            )
        else:
            bot.reply_to(message, f"❌ {error_msg or 'خطا در ارسال کد. شماره را بررسی کنید و دوباره تلاش کنید.'}")

    # هندلر دریافت کد تایید
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and 'کد تایید' in m.reply_to_message.text)
    def on_code_received(message):
        """دریافت کد تایید و تکمیل ورود"""
        user_id = message.from_user.id
        code = message.text.strip()

        if not userbot_available():
            bot.reply_to(message, "❌ Telethon پیکربندی نشده است.")
            return

        # ⚠️ نکته مهم: complete_sign_in یک tuple برمی‌گرداند (success, error_msg)
        # قبلاً به صورت boolean استفاده می‌شد که باعث می‌شد حتی خطاها هم همیشه
        # truthy در نظر گرفته شوند (چون tuple غیرخالی همیشه truthy است).
        ok, error_msg = complete_sign_in(user_id, code)

        if ok:
            user_settings.set_setting(user_id, 'secretary_enabled', True)
            user_settings.set_setting(user_id, 'secretary_mode', 'manual')
            user_settings.save()

            start_monitoring(user_id, bot, user_id)

            text = (
                "🎉 ورود موفق بود!\n\n"
                "✅ منشی شخصی شما فعال شد.\n"
                "🎯 حالت پیش‌فرض: فقط فوروارد کن (دستی)\n\n"
                "می‌توانید از منوی تنظیمات حالت را تغییر دهید:\n"
                "🔔 همیشه جواب بده\n"
                "🌙 فقط وقتی آفلاینم\n"
                "📨 فقط فوروارد کن"
            )
            markup = _get_secretary_keyboard(user_id)
            bot.reply_to(message, text, reply_markup=markup)
        else:
            # مدیریت پیام‌های خطای خاص
            if error_msg == "NEED_RESEND_SMS":
                # تلگرام کد را "قبلاً اشتراک‌گذاری شده" تشخیص داده و ورود را مسدود کرده.
                # کد جدید از طریق SMS ارسال می‌شود تا مشکل پیش نیاید.
                sms_ok, sms_error = resend_code_sms(user_id)
                if sms_ok:
                    bot.send_message(
                        message.chat.id,
                        "⚠️ تلگرام ورود با کد قبلی را مسدود کرد، چون کد در یک پیام "
                        "تلگرامی ارسال شده بود (سیستم امنیتی تلگرام).\n\n"
                        "📱 یک کد جدید از طریق پیامک (SMS) ارسال شد.\n"
                        "لطفاً کد جدید دریافتی در پیامک را وارد کنید:\n\n"
                        "⚠️ برای جلوگیری از تکرار مشکل، کد را با فاصله وارد کنید: 1 2 3 4 5",
                        reply_markup=ForceReply()
                    )
                else:
                    bot.reply_to(
                        message,
                        f"❌ خطا در ارسال مجدد کد از طریق پیامک: {sms_error}\n"
                        "لطفاً دوباره شماره تلفن خود را وارد کنید."
                    )
            elif error_msg == "NEED_2FA_PASSWORD":
                # اکانت دارای رمز عبور دو مرحله‌ای (2FA) است
                bot.send_message(
                    message.chat.id,
                    "🔐 اکانت شما دارای رمز عبور دو مرحله‌ای (2FA) است.\n\n"
                    "لطفاً رمز عبور ابری تلگرام خود را وارد کنید:",
                    reply_markup=ForceReply()
                )
            else:
                bot.reply_to(
                    message,
                    f"❌ {error_msg or 'کد نادرست است یا خطایی رخ داد. دوباره تلاش کنید.'}"
                )

    # هندلر دریافت کد تایید SMS (بعد از ارسال مجدد کد)
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and 'کد جدید دریافتی در پیامک' in m.reply_to_message.text)
    def on_sms_code_received(message):
        """دریافت کد تایید SMS و تکمیل ورود"""
        user_id = message.from_user.id
        code = message.text.strip()

        if not userbot_available():
            bot.reply_to(message, "❌ Telethon پیکربندی نشده است.")
            return

        ok, error_msg = complete_sign_in(user_id, code)

        if ok:
            user_settings.set_setting(user_id, 'secretary_enabled', True)
            user_settings.set_setting(user_id, 'secretary_mode', 'manual')
            user_settings.save()

            start_monitoring(user_id, bot, user_id)

            text = (
                "🎉 ورود موفق بود!\n\n"
                "✅ منشی شخصی شما فعال شد.\n"
                "🎯 حالت پیش‌فرض: فقط فوروارد کن (دستی)\n\n"
                "می‌توانید از منوی تنظیمات حالت را تغییر دهید:\n"
                "🔔 همیشه جواب بده\n"
                "🌙 فقط وقتی آفلاینم\n"
                "📨 فقط فوروارد کن"
            )
            markup = _get_secretary_keyboard(user_id)
            bot.reply_to(message, text, reply_markup=markup)
        else:
            if error_msg == "NEED_2FA_PASSWORD":
                bot.send_message(
                    message.chat.id,
                    "🔐 اکانت شما دارای رمز عبور دو مرحله‌ای (2FA) است.\n\n"
                    "لطفاً رمز عبور ابری تلگرام خود را وارد کنید:",
                    reply_markup=ForceReply()
                )
            elif error_msg == "NEED_RESEND_SMS":
                bot.reply_to(
                    message,
                    "❌ این کد هم مسدود شد. لطفاً چند دقیقه صبر کنید و دوباره "
                    "از ابتدا شماره تلفن خود را وارد کنید."
                )
            else:
                bot.reply_to(
                    message,
                    f"❌ {error_msg or 'کد نادرست است. دوباره تلاش کنید.'}"
                )

    # هندلر دریافت رمز عبور 2FA
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and 'رمز عبور ابری تلگرام' in m.reply_to_message.text)
    def on_2fa_password_received(message):
        """دریافت رمز عبور 2FA و تکمیل ورود"""
        user_id = message.from_user.id
        password = message.text.strip()

        if not userbot_available():
            bot.reply_to(message, "❌ Telethon پیکربندی نشده است.")
            return

        ok, error_msg = complete_2fa_sign_in(user_id, password)

        if ok:
            user_settings.set_setting(user_id, 'secretary_enabled', True)
            user_settings.set_setting(user_id, 'secretary_mode', 'manual')
            user_settings.save()

            start_monitoring(user_id, bot, user_id)

            text = (
                "🎉 ورود موفق بود!\n\n"
                "✅ منشی شخصی شما فعال شد.\n"
                "🎯 حالت پیش‌فرض: فقط فوروارد کن (دستی)\n\n"
                "می‌توانید از منوی تنظیمات حالت را تغییر دهید:\n"
                "🔔 همیشه جواب بده\n"
                "🌙 فقط وقتی آفلاینم\n"
                "📨 فقط فوروارد کن"
            )
            markup = _get_secretary_keyboard(user_id)
            bot.reply_to(message, text, reply_markup=markup)
        else:
            bot.reply_to(
                message,
                f"❌ {error_msg or 'رمز عبور اشتباه است. دوباره تلاش کنید.'}"
            )

    # هندلر جواب دستی به پیام‌های فوروارد شده
    @bot.message_handler(func=lambda m: m.reply_to_message and m.reply_to_message.text and 'پیام جدید از' in m.reply_to_message.text)
    def on_manual_reply(message):
        """ارسال جواب دستی کاربر از اکانت خودش"""
        user_id = message.from_user.id
        reply_text = message.text.strip()

        pending_key = f"pending_reply_{message.reply_to_message.message_id}"
        pending_data = user_settings.get_setting(user_id, pending_key)

        if not pending_data:
            bot.reply_to(message, "❌ این پیام دیگر معتبر نیست.")
            return

        telethon_msg_id = pending_data.get("telethon_msg_id")
        sender_id = pending_data.get("sender_id")

        from tools.userbot_manager import _run_async
        try:
            success = _run_async(send_reply(user_id, reply_text, telethon_msg_id, sender_id))
            if success:
                bot.reply_to(message, "✅ جواب شما ارسال شد!")
                user_settings.set_setting(user_id, pending_key, None)
                user_settings.save()
            else:
                bot.reply_to(message, "❌ خطا در ارسال جواب.")
        except Exception as e:
            logging.getLogger(__name__).error(f"Error sending manual reply: {e}", exc_info=True)
            bot.reply_to(message, get_friendly_error_message(user_id, e))