from core.executor import should_request_github_target
from core.router import IntentRouter, _match_keyword


def test_ambiguous_github_request_is_detected():
    plan = IntentRouter.route("گیت هاب فلانی رو بررسی کن")
    assert plan["github"] is True


def test_ambiguous_github_request_requires_target():
    assert should_request_github_target("گیت هاب فلانی رو بررسی کن") is True
    assert should_request_github_target("گیت هاب torvalds/linux را بررسی کن") is False
    assert should_request_github_target("پروفایل octocat را نشان بده") is False


def test_gold_price_search_is_not_hijacked_by_office():
    """باگ قدیمی: «ورد» داخل «مورد» match میشد و «در مورد قیمت طلا سرچ کن»
    را به مسیر آفیس میفرستاد؛ در نتیجه جستجوی واقعی وب هرگز اجرا نمیشد."""
    plan = IntentRouter.route("در مورد قیمت امروز طلا سرچ کن")
    assert plan["search"] is True
    assert plan["office"] is False


def test_word_keyword_boundaries():
    # «ورد» نباید داخل کلماتی مثل «مورد»/«مخصوص» پیدا شود
    assert _match_keyword("در مورد سکه صحبت کن", "ورد") is False
    assert _match_keyword("این مخصوص توست", "ورد") is False
    # ولی به عنوان کلمهی مستقل (فایل ورد) باید پیدا شود
    assert _match_keyword("برام یک فایل ورد بساز", "ورد") is True
    # کلمات انگلیسی هم مرز کلمه دارند (نه password, word)
    assert _match_keyword("create a word document", "word") is True
    assert _match_keyword("my password is secret", "word") is False


def test_office_query_is_still_detected():
    plan = IntentRouter.route("یک فایل ورد بساز")
    assert plan["office"] is True
