# tests/test_errors.py
"""Tests for the smart error handling module (core/errors.py)."""
import pytest
from google.genai import errors as genai_errors
from core import errors as core_errors


def _client_error(code, status):
    return genai_errors.ClientError(code, {"error": {"status": status}})


def _server_error(code, status):
    return genai_errors.ServerError(code, {"error": {"status": status}})


class TestClassifyException:
    def test_rate_limit_429(self):
        assert core_errors.classify_exception(
            _client_error(429, "RESOURCE_EXHAUSTED")) == "rate_limit"

    def test_server_500(self):
        assert core_errors.classify_exception(
            _server_error(500, "INTERNAL")) == "server"

    def test_server_503(self):
        assert core_errors.classify_exception(
            _server_error(503, "UNAVAILABLE")) == "server"

    def test_auth_401(self):
        assert core_errors.classify_exception(
            _client_error(401, "UNAUTHENTICATED")) == "auth"

    def test_quota_400(self):
        assert core_errors.classify_exception(
            _client_error(400, "INVALID_ARGUMENT")) == "quota"

    def test_generic(self):
        assert core_errors.classify_exception(RuntimeError("boom")) == "generic"


class TestShouldRetry:
    def test_retry_transient(self):
        assert core_errors.should_retry(
            _client_error(429, "RESOURCE_EXHAUSTED")) is True
        assert core_errors.should_retry(
            _server_error(503, "UNAVAILABLE")) is True

    def test_no_retry_auth(self):
        assert core_errors.should_retry(
            _client_error(401, "UNAUTHENTICATED")) is False


class TestFriendlyMessage:
    def test_never_leaks_raw_error_429(self):
        core_errors.reset_error_cooldown()
        exc = _client_error(429, "RESOURCE_EXHAUSTED")
        msg = core_errors.get_friendly_error_message(0, exc, force=True)
        assert msg
        assert "429" not in msg
        assert "RESOURCE_EXHAUSTED" not in msg

    def test_never_leaks_raw_error_503(self):
        core_errors.reset_error_cooldown()
        msg = core_errors.get_friendly_error_message(
            0, _server_error(503, "UNAVAILABLE"), force=True)
        assert "503" not in msg
        assert "UNAVAILABLE" not in msg

    def test_language_keys_exist_for_all_languages(self):
        from core.languages import LANGUAGES
        for lang in LANGUAGES:
            for key in ("error_rate_limit", "error_server_busy", "error_auth",
                        "error_quota", "error_network", "error_generic",
                        "error_busy_short"):
                assert key in LANGUAGES[lang], f"{key} missing in {lang}"

    def test_cooldown_sends_short_message(self):
        core_errors.reset_error_cooldown()
        exc = _client_error(429, "RESOURCE_EXHAUSTED")
        first = core_errors.get_friendly_error_message(0, exc)
        second = core_errors.get_friendly_error_message(0, exc)
        assert first != second


class TestRetryApiCall:
    def test_retries_then_succeeds(self, monkeypatch):
        monkeypatch.setattr(core_errors.time, "sleep", lambda s: None)
        calls = {"n": 0}

        def flaky():
            calls["n"] += 1
            if calls["n"] < 3:
                raise _client_error(429, "RESOURCE_EXHAUSTED")
            return "ok"

        result = core_errors.retry_api_call(flaky, max_retries=2)
        assert result == "ok"
        assert calls["n"] == 3

    def test_gives_up_after_retries(self, monkeypatch):
        monkeypatch.setattr(core_errors.time, "sleep", lambda s: None)

        def always():
            raise _client_error(429, "RESOURCE_EXHAUSTED")

        with pytest.raises(genai_errors.APIError):
            core_errors.retry_api_call(always, max_retries=2)
