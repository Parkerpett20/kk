# config.py
import os
import logging
from dotenv import load_dotenv

# تنظیم logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# ساکت کردن هشدارهای Telethon درباره SSL (فقط INFO هست، مشکلی ایجاد نمیکنه)
logging.getLogger('telethon.crypto.libssl').setLevel(logging.WARNING)

load_dotenv()

# ------------------------------------------------------------------
# غیرفعال‌سازی کامل پروکسی سیستمی برای کل پروژه
# ------------------------------------------------------------------
# برخی سیستم‌عامل‌ها/ابزارهای VPN به‌صورت خودکار متغیرهای محیطی پروکسی
# (مثل ALL_PROXY با اسکیم socks://) را ست می‌کنند. کتابخانه‌ی httpx که
# پکیج google-genai از آن استفاده می‌کند این متغیرها را به صورت خودکار
# می‌خواند (trust_env=True) و در صورتی که اسکیم آن socks:// باشد (به‌جای
# socks5://) با خطای «Unknown scheme for proxy URL» متوقف می‌شود.
# چون این پروژه اصلاً قصد استفاده از پروکسی را ندارد، همین ابتدا و قبل
# از ساخته شدن هر کلاینتی (genai.Client و ...) این متغیرها را از محیط
# اجرای پایتون حذف می‌کنیم تا هیچ کتابخانه‌ای (httpx, requests, ...)
# به صورت ناخواسته از پروکسی سیستم استفاده نکند.
for _proxy_env_var in (
    "HTTP_PROXY", "http_proxy",
    "HTTPS_PROXY", "https_proxy",
    "ALL_PROXY", "all_proxy",
    "FTP_PROXY", "ftp_proxy",
):
    os.environ.pop(_proxy_env_var, None)

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
PROXY = os.getenv("PROXY")

# Optional: external search provider API keys
SERPAPI_API_KEY = os.getenv("SERPAPI_API_KEY")
# Search provider: 'exa', 'serpapi', or 'none'. Exa is preferred (Agent-Reach integration).
SEARCH_PROVIDER = os.getenv("SEARCH_PROVIDER", "exa")
# Exa AI API key (free tier available at https://exa.ai)
EXA_API_KEY = os.getenv("EXA_API_KEY", "")

if not TELEGRAM_BOT_TOKEN or not GEMINI_API_KEY:
    raise ValueError("❌ خطا: متغیر TELEGRAM_BOT_TOKEN یا GEMINI_API_KEY در فایل .env یافت نشد.")


def _validate_gemini_key(key: str) -> str:
    """بررسی زودهنگام فرمت کلید Gemini تا به جای خطای مبهم
      401 UNAUTHENTICATED گوگل، همان ابتدا مشکل را گزارش کنیم.

    کلیدهای معتبر Gemini API همیشه با پیشوند 'AIza' شروع می‌شوند
    و حدود ۳۹ کاراکتر طول دارند. اگر کلید فرمت دیگری داشته باشد
    (مثل OAuth token با پیشوند AQ.) گوگل آن را رد می‌کند."""
    if not key:
        return "خالی است"
    if not key.startswith("AIza"):
        return "باید با پیشوند AIza شروع شود"
    if len(key) < 30:
        return "طول آن کمتر از حد استاندارد API key است"
    return ""


if _gemini_key_issue := _validate_gemini_key(GEMINI_API_KEY):
    logging.warning(
        "⚠️ GEMINI_API_KEY نامعتبر به نظر می‌رسد (%s). "
        "کلید فعلی فرمت یک API Key استاندارد گوگل را ندارد و به همین دلیل "
        "همه پیام‌ها با خطای 401 UNAUTHENTICATED شکست می‌خورند.\n"
        "   👉 یک کلید جدید از https://aistudio.google.com/apikey بسازید "
        "(روی «Create API key» کلیک کنید) و مقدار GEMINI_API_KEY را در فایل .env جایگزین کنید.",
        _gemini_key_issue,
    )

# تعریف مدل‌ها بر اساس الگوهای سفارشی شما
MODELS = {
    "fast_or_search": "gemini-3.5-flash-lite",  # پاسخ‌های سریع و سرچ گوگل
    "deep_task": "gemini-3.7-flash"           # کارهای عمیق، مقاله‌نویسی، منطق و کدنویسی
}
