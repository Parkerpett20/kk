# core/executor.py
import re
import logging
from google import genai
from google.genai import types
from config import GEMINI_API_KEY, MODELS
from core.router import IntentRouter
from core.errors import retry_api_call
from core.context_builder import build_context
from memory.short_memory import short_term_memory
from tools.registry_new import get_available_tools, TOOL_CATEGORIES
from handlers.reminder import extract_reminder_info

logger = logging.getLogger(__name__)

client = genai.Client(api_key=GEMINI_API_KEY)


def should_request_github_target(user_text: str) -> bool:
    """Return True when a GitHub request lacks enough detail to act on directly."""
    if not user_text:
        return False

    text = user_text.lower().strip()
    if not text:
        return False

    explicit_markers = [
        "github", "گیت هاب", "گیتهاب", "repo", "repository", "ریپو", "پروژه",
        "profile", "پروفایل", "user", "اکانت", "org", "سازمان"
    ]
    if not any(marker in text for marker in explicit_markers):
        return False

    if re.search(r"(?:github\.com|/)[a-z0-9._-]+/[a-z0-9._-]+", text):
        return False

    if re.search(r"[a-z0-9._-]+/[a-z0-9._-]+", text):
        return False

    if re.search(r"(?:پروفایل|profile|اکانت|user)\s+[a-z0-9._-]+", text):
        return False

    github_username_match = re.search(r"(?:github|گیت هاب|گیتهاب)\s+([a-z0-9._-]+)", text)
    if github_username_match:
        return False

    if re.search(r"(?:github|گیت هاب|گیتهاب).*(?:بررسی|ببین|چک|تحلیل|پروفایل|اکانت)", text):
        return True

    if any(phrase in text for phrase in ["بررسی کن", "بررسی", "ببین", "چک کن", "چک", "تحلیل کن", "پروفایل", "اکانت"]):
        return True

    return False


def _deduplicate_response(text: str) -> str:
    if not text or len(text) < 100:
        return text
    words = text.split()
    if len(words) < 10:
        return text
    mid = len(words) // 2
    for i in range(mid, len(words) - 2):
        suffix = ' '.join(words[i:])
        prefix = ' '.join(words[:i])
        if len(suffix) < 20 or len(prefix) < 20:
            continue
        if prefix == suffix or (len(set(prefix.split()) & set(suffix.split())) / min(len(prefix.split()), len(suffix.split())) >= 0.9):
            return ' '.join(words[:i])
    return text


def _extract_office_files(tool_result: str) -> list:
    """Extract office file names from a tool result string."""
    if not tool_result:
        return []
    pattern = re.compile(r'office_workspace[/\\]([^\s]+\.(?:docx|xlsx|pptx))', re.IGNORECASE)
    return pattern.findall(str(tool_result))


def _build_tool_map():
    """Build function name -> function mapping from registry categories"""
    tool_map = {}
    for cat, names in TOOL_CATEGORIES.items():
        for name in names:
            try:
                tools = get_available_tools(category=cat)
                for t in tools:
                    if hasattr(t, '__name__') and t.__name__ == name:
                        tool_map[name] = t
                        break
            except Exception:
                pass
    # Fallback: direct imports for core tools
    if 'calculate_math' not in tool_map:
        from tools.calculator import calculate_math
        tool_map['calculate_math'] = calculate_math
    if 'get_weather' not in tool_map:
        from tools.weather import get_weather
        tool_map['get_weather'] = get_weather
    if 'generate_image_url' not in tool_map:
        from tools.image_generation import generate_image_url
        tool_map['generate_image_url'] = generate_image_url
    if 'perform_web_search' not in tool_map:
        from tools.search import perform_web_search
        tool_map['perform_web_search'] = perform_web_search
    if 'get_user_info' not in tool_map:
        from tools.github import get_repo_info, search_repositories, get_user_info, get_trending_repos
        tool_map.update({'get_repo_info': get_repo_info, 'search_repositories': search_repositories,
                         'get_user_info': get_user_info, 'get_trending_repos': get_trending_repos})
    if 'search_youtube' not in tool_map:
        from tools.youtube import search_youtube, get_youtube_video_info
        tool_map.update({'search_youtube': search_youtube, 'get_youtube_video_info': get_youtube_video_info})
    if 'invite_chat_member' not in tool_map:
        from tools.group_management import invite_chat_member, create_group_invite_link, get_group_admins
        tool_map.update({'invite_chat_member': invite_chat_member, 'create_group_invite_link': create_group_invite_link,
                         'get_group_admins': get_group_admins})
    if 'translate' not in tool_map:
        from tools.translate import translate
        tool_map['translate'] = translate
    if 'browse_url' not in tool_map:
        from tools.browser import browse_url
        tool_map['browse_url'] = browse_url
    if 'speak_text' not in tool_map:
        from tools.speech import speak_text
        tool_map['speak_text'] = speak_text
    if 'analyze_image_file' not in tool_map:
        from tools.vision import analyze_image_file, analyze_image_url
        tool_map.update({'analyze_image_file': analyze_image_file, 'analyze_image_url': analyze_image_url})
    if 'execute_python_code' not in tool_map:
        from tools.python_executor import execute_python_code
        tool_map['execute_python_code'] = execute_python_code
    if 'read_file' not in tool_map:
        from tools.filesystem import read_file, write_file, list_files
        tool_map.update({'read_file': read_file, 'write_file': write_file, 'list_files': list_files})
    if 'send_message_to_contact' not in tool_map:
        from tools.secretary_messaging import send_message_to_contact, list_contacts
        tool_map.update({'send_message_to_contact': send_message_to_contact, 'list_contacts': list_contacts})
    if 'text_to_word_document' not in tool_map:
        from tools.office import (
            create_office_document, view_office_document, get_office_content,
            query_office_document, validate_office_document, add_office_element,
            set_office_property, remove_office_element, move_office_element,
            swap_office_elements, batch_office_operations, text_to_word_document,
            text_to_powerpoint, data_to_excel, list_office_files,
            get_office_help, officecli_version
        )
        tool_map.update({
            'create_office_document': create_office_document,
            'view_office_document': view_office_document,
            'get_office_content': get_office_content,
            'query_office_document': query_office_document,
            'validate_office_document': validate_office_document,
            'add_office_element': add_office_element,
            'set_office_property': set_office_property,
            'remove_office_element': remove_office_element,
            'move_office_element': move_office_element,
            'swap_office_elements': swap_office_elements,
            'batch_office_operations': batch_office_operations,
            'text_to_word_document': text_to_word_document,
            'text_to_powerpoint': text_to_powerpoint,
            'data_to_excel': data_to_excel,
            'list_office_files': list_office_files,
            'get_office_help': get_office_help,
            'officecli_version': officecli_version,
        })
    return tool_map


TOOL_MAP = _build_tool_map()
logger.info(f"Loaded {len(TOOL_MAP)} tools from registry: {list(TOOL_MAP.keys())}")


def _get_tool_function(name):
    """Get tool function by name from TOOL_MAP"""
    return TOOL_MAP.get(name)


def _parse_text_function_calls(text: str) -> list:
    """Parse function calls from model text output"""
    if not text:
        return []
    func_names = '|'.join(TOOL_MAP.keys())
    pattern = f'({func_names})\\s*\\(([^)]*)\\)'
    matches = re.findall(pattern, text)
    calls = []
    for func_name, args_str in matches:
        args = {}
        if args_str.strip():
            kv_pattern = r"(\w+)\s*=\s*(?:'([^']*)'|\"([^\"]*)\"|([\w\.\-]+))"
            kv_matches = re.findall(kv_pattern, args_str)
            for key, val_sq, val_dq, val_raw in kv_matches:
                value = val_sq or val_dq or val_raw
                try:
                    value = int(value)
                except (ValueError, TypeError):
                    try:
                        value = float(value)
                    except (ValueError, TypeError):
                        pass
                args[key] = value
            if not args:
                pos_pattern = r"['\"]([^'\"]+)['\"]"
                pos_matches = re.findall(pos_pattern, args_str)
                if pos_matches:
                    if func_name == 'generate_image_url':
                        args['prompt'] = pos_matches[0]
                    elif func_name == 'get_weather':
                        args['city'] = pos_matches[0]
                    elif func_name == 'calculate_math':
                        args['expression'] = pos_matches[0]
                    elif func_name == 'perform_web_search':
                        args['query'] = pos_matches[0]
                    elif func_name == 'translate':
                        args['text'] = pos_matches[0]
                    elif func_name == 'send_message_to_contact':
                        # send_message_to_contact('Nn', 'سلام')
                        if len(pos_matches) >= 1:
                            args['contact_name'] = pos_matches[0]
                        if len(pos_matches) >= 2:
                            args['message'] = pos_matches[1]
                    elif func_name == 'list_contacts':
                        # list_contacts('علی') یا list_contacts()
                        args['query'] = pos_matches[0] if pos_matches else ''
                    elif func_name == 'text_to_word_document':
                        # text_to_word_document('متن', 'file.docx', 'عنوان')
                        if len(pos_matches) >= 1:
                            args['text'] = pos_matches[0]
                        if len(pos_matches) >= 2:
                            args['filename'] = pos_matches[1]
                        if len(pos_matches) >= 3:
                            args['title'] = pos_matches[2]
                    elif func_name == 'text_to_powerpoint':
                        # text_to_powerpoint('متن', 'file.pptx', 'عنوان')
                        if len(pos_matches) >= 1:
                            args['text'] = pos_matches[0]
                        if len(pos_matches) >= 2:
                            args['filename'] = pos_matches[1]
                        if len(pos_matches) >= 3:
                            args['title'] = pos_matches[2]
                    elif func_name == 'data_to_excel':
                        # data_to_excel('[[...]]', 'file.xlsx')
                        if len(pos_matches) >= 1:
                            args['data'] = pos_matches[0]
                        if len(pos_matches) >= 2:
                            args['filename'] = pos_matches[1]
                    elif func_name == 'create_office_document':
                        # create_office_document('file.docx')
                        if len(pos_matches) >= 1:
                            args['filename'] = pos_matches[0]
                    elif func_name == 'view_office_document':
                        # view_office_document('file.docx', 'text')
                        if len(pos_matches) >= 1:
                            args['filename'] = pos_matches[0]
                        if len(pos_matches) >= 2:
                            args['mode'] = pos_matches[1]
                    elif func_name == 'get_office_content':
                        # get_office_content('file.docx', '/body/p[1]')
                        if len(pos_matches) >= 1:
                            args['filename'] = pos_matches[0]
                        if len(pos_matches) >= 2:
                            args['path'] = pos_matches[1]
                    elif func_name == 'query_office_document':
                        # query_office_document('file.docx', 'paragraph[style=Heading1]')
                        if len(pos_matches) >= 1:
                            args['filename'] = pos_matches[0]
                        if len(pos_matches) >= 2:
                            args['selector'] = pos_matches[1]
                    elif func_name == 'validate_office_document':
                        # validate_office_document('file.docx')
                        if len(pos_matches) >= 1:
                            args['filename'] = pos_matches[0]
                    elif func_name == 'add_office_element':
                        # add_office_element('file.docx', '/body', 'paragraph', 'text=Hello')
                        if len(pos_matches) >= 1:
                            args['filename'] = pos_matches[0]
                        if len(pos_matches) >= 2:
                            args['path'] = pos_matches[1]
                        if len(pos_matches) >= 3:
                            args['element_type'] = pos_matches[2]
                        if len(pos_matches) >= 4:
                            args['props'] = pos_matches[3]
                    elif func_name == 'set_office_property':
                        # set_office_property('file.docx', '/body/p[1]', 'bold=true')
                        if len(pos_matches) >= 1:
                            args['filename'] = pos_matches[0]
                        if len(pos_matches) >= 2:
                            args['path'] = pos_matches[1]
                        if len(pos_matches) >= 3:
                            args['props'] = pos_matches[2]
                    elif func_name == 'remove_office_element':
                        # remove_office_element('file.docx', '/body/p[4]')
                        if len(pos_matches) >= 1:
                            args['filename'] = pos_matches[0]
                        if len(pos_matches) >= 2:
                            args['path'] = pos_matches[1]
                    elif func_name == 'list_office_files':
                        # list_office_files()
                        pass
                    elif func_name == 'get_office_help':
                        # get_office_help('docx paragraph')
                        if len(pos_matches) >= 1:
                            args['topic'] = pos_matches[0]
                    elif func_name == 'officecli_version':
                        # officecli_version()
                        pass
        calls.append((func_name, args))
    return calls


class AgentExecutor:
    @staticmethod
    def _execute_tool_call(function_name, function_args, chat_id=None, user_id=None):
        func = _get_tool_function(function_name)
        if func:
            # تزریق user_id برای ابزارهای منشی شخصی
            # ⚠️ مهم: باید از user_id واقعی کاربر (from_user.id) استفاده کنیم،
            # نه chat_id. در گروه‌ها chat_id آیدی گروه است نه کاربر.
            # سشن‌های منشی بر اساس آیدی واقعی کاربر ذخیره شده‌اند.
            if function_name in ('send_message_to_contact', 'list_contacts'):
                if 'user_id' not in function_args:
                    # اولویت با user_id واقعی است؛ اگر نبود، fallback به chat_id
                    function_args['user_id'] = user_id if user_id is not None else chat_id
            return func(**function_args)
        return f"Unknown function: {function_name}"

    @staticmethod
    def run_stream(chat_id: int, user_text: str, attachments=None, chat_type: str = None, user_id: int = None):
        plan = IntentRouter.route(user_text)
        selected_model = plan["model"]

        if plan.get("reminder"):
            reminder_message, run_time = extract_reminder_info(user_text)
            if reminder_message and run_time:
                from core.scheduler import reminder_scheduler
                reminder_id = reminder_scheduler.add_reminder(user_id=chat_id, message=reminder_message, run_time=run_time)
                from datetime import datetime
                import pytz
                now = datetime.now(pytz.timezone('Asia/Tehran'))
                time_diff = run_time - now
                if time_diff.total_seconds() < 3600:
                    time_display = f"{int(time_diff.total_seconds() / 60)} دقیقه دیگر"
                else:
                    h, m = int(time_diff.total_seconds() / 3600), int((time_diff.total_seconds() % 3600) / 60)
                    time_display = f"{h} ساعت و {m} دقیقه دیگر"
                return [f"✅ یادآوری ثبت شد!\n📝 متن: {reminder_message}\n⏰ زمان: {time_display}\n\n🆔 ID: {reminder_id}"], plan
            return ["❌ متوجه نشدم!\nلطفاً از فرمت‌های زیر استفاده کنید:\n🔹 یادآوری کن که [کار] در ساعت HH:MM\n🔹 5 دقیقه بعد یادم بنداز [کار]"], plan

        search_context = ""
        if plan.get("search"):
            from tools.search import perform_web_search
            search_context = perform_web_search(user_text)

        system_instruction = build_context(chat_id, plan["mood"], chat_type, user_id)
        if search_context:
            system_instruction += f"\n\n📌 نتایج جستجو:\n{search_context}"

        available_tools = list(get_available_tools())
        # ابزارهای منشی شخصی همیشه در دسترس مدل باشند تا بتواند به درخواست‌های
        # «به Nn بگو ...» یا «لیست مخاطبین» پاسخ دهد
        from tools.secretary_messaging import send_message_to_contact, list_contacts
        for _t in (send_message_to_contact, list_contacts):
            if _t not in available_tools:
                available_tools.append(_t)
        if plan.get("image"):
            from tools.image_generation import generate_image_url
            if generate_image_url not in available_tools:
                available_tools.append(generate_image_url)
        if plan.get("github"):
            from tools.github import get_repo_info, search_repositories, get_user_info, get_trending_repos
            for t in [get_repo_info, search_repositories, get_user_info, get_trending_repos]:
                if t not in available_tools:
                    available_tools.append(t)

        if plan.get("github") and should_request_github_target(user_text):
            fallback_hint = (
                "برای بررسی دقیق یک حساب یا مخزن GitHub، نام کاربری یا نام مخزن را مشخص کنید. "
                "مثلاً: «گیت‌هاب torvalds/linux را بررسی کن» یا «پروفایل github.com/octocat را نشان بده»."
            )
            return [fallback_hint], plan
        if plan.get("youtube"):
            from tools.youtube import search_youtube, get_youtube_video_info
            for t in [search_youtube, get_youtube_video_info]:
                if t not in available_tools:
                    available_tools.append(t)
        if plan.get("group_management") or (chat_type in ['group', 'supergroup']):
            from tools.group_management import invite_chat_member, create_group_invite_link, get_group_admins
            for t in [invite_chat_member, create_group_invite_link, get_group_admins]:
                if t not in available_tools:
                    available_tools.append(t)
        if plan.get("office"):
            from tools.office import (
                create_office_document, view_office_document, get_office_content,
                query_office_document, validate_office_document, add_office_element,
                set_office_property, remove_office_element, move_office_element,
                swap_office_elements, batch_office_operations, text_to_word_document,
                text_to_powerpoint, data_to_excel, list_office_files,
                get_office_help, officecli_version
            )
            for t in [create_office_document, view_office_document, get_office_content,
                      query_office_document, validate_office_document, add_office_element,
                      set_office_property, remove_office_element, move_office_element,
                      swap_office_elements, batch_office_operations, text_to_word_document,
                      text_to_powerpoint, data_to_excel, list_office_files,
                      get_office_help, officecli_version]:
                if t not in available_tools:
                    available_tools.append(t)

        config = types.GenerateContentConfig(
            system_instruction=system_instruction,
            tools=available_tools if available_tools else None,
            temperature=0.6,
            automatic_function_calling=types.AutomaticFunctionCallingConfig(disable=True)
        )

        history = short_term_memory.get_history(chat_id)
        contents = list(history)
        parts = []
        if attachments:
            parts.extend(attachments)
        if user_text:
            parts.append(types.Part(text=user_text))
        contents.append(types.Content(role="user", parts=parts))

        response = retry_api_call(client.models.generate_content, model=selected_model, contents=contents, config=config)

        has_function_call = False
        office_files = []
        if response.candidates and response.candidates[0].content:
            candidate = response.candidates[0]
            for part in candidate.content.parts:
                if hasattr(part, 'function_call') and part.function_call:
                    has_function_call = True
                    fc = part.function_call
                    logger.info(f"Executing tool: {fc.name} with args: {fc.args}")
                    tool_result = AgentExecutor._execute_tool_call(fc.name, dict(fc.args), chat_id=chat_id, user_id=user_id)
                    logger.info(f"Tool result: {str(tool_result)[:200]}")
                    # Extract office file paths from tool result
                    office_files.extend(_extract_office_files(tool_result))
                    contents.append(candidate.content)
                    contents.append(types.Content(role="user", parts=[types.Part.from_function_response(name=fc.name, response={"result": tool_result})]))
            if has_function_call:
                response = retry_api_call(client.models.generate_content, model=selected_model, contents=contents, config=config)

        if not has_function_call and response.candidates and response.candidates[0].content:
            raw_text = ""
            for part in response.candidates[0].content.parts:
                if hasattr(part, 'text') and part.text:
                    raw_text += part.text
            text_calls = _parse_text_function_calls(raw_text)
            if text_calls:
                func_name, func_args = text_calls[0]
                logger.info(f"Executing text-based tool: {func_name} with args: {func_args}")
                tool_result = AgentExecutor._execute_tool_call(func_name, func_args, chat_id=chat_id, user_id=user_id)
                logger.info(f"Tool result: {str(tool_result)[:200]}")
                # Extract office file paths from tool result
                office_files.extend(_extract_office_files(tool_result))
                contents.append(types.Content(role="model", parts=[types.Part(text=raw_text)]))
                contents.append(types.Content(role="user", parts=[types.Part.from_function_response(name=func_name, response={"result": str(tool_result)})]))
                response = retry_api_call(client.models.generate_content, model=selected_model, contents=contents, config=config)

        final_text = ""
        if response.candidates:
            for part in response.candidates[0].content.parts:
                if hasattr(part, 'thinking') or type(part).__name__ in ("Thinking", "ThinkingBlock"):
                    continue
                if hasattr(part, 'text') and part.text:
                    final_text += part.text

        final_text = _deduplicate_response(final_text)
        logger.info(f"Final response length: {len(final_text)}")
        
        # Add office file markers to the stream so streaming handler can send them
        result = [final_text]
        for f in office_files:
            result.append(f"__OFFICE_FILE__:{f}")
            logger.info(f"Office file to send: {f}")
        
        return result, plan
