# core/streaming.py
import re
import os
import time
import logging
import telebot
from memory.short_memory import short_term_memory

logger = logging.getLogger(__name__)

# Pattern to detect office file creation in tool results
OFFICE_FILE_PATTERN = re.compile(r'office_workspace[/\\]([^\s]+\.(?:docx|xlsx|pptx))', re.IGNORECASE)

def handle_stream_delivery(bot: telebot.TeleBot, chat_id: int, message_id: int, stream, user_text: str):
    """مدیریت پاسخ و ارسال به تلگرام"""
    full_text = ""
    
    try:
        # اگر stream یک لیست باشد (پاسخ معمولی از executor)
        if isinstance(stream, list):
            for item in stream:
                if isinstance(item, str):
                    # فیلتر کردن مارکرهای فایل آفیس از متن نمایشی
                    if item.startswith("__OFFICE_FILE__:"):
                        continue
                    full_text += item
                elif hasattr(item, 'text') and item.text:
                    full_text += item.text
        else:
            # استریم معمولی
            last_update = time.time()
            for chunk in stream:
                if hasattr(chunk, 'text') and chunk.text:
                    full_text += chunk.text
                
                now = time.time()
                if now - last_update > 2.0 and full_text:
                    try:
                        bot.edit_message_text(text=full_text + " ✍️...", chat_id=chat_id, message_id=message_id)
                    except Exception:
                        pass
                    last_update = now
    except Exception as e:
        logger.error(f"Error processing response: {e}")

    # نمایش نهائی
    if full_text:
        try:
            bot.edit_message_text(text=full_text, chat_id=chat_id, message_id=message_id)
        except Exception:
            pass
    else:
        try:
            bot.edit_message_text(text="پاسخی دریافت نشد.", chat_id=chat_id, message_id=message_id)
        except Exception:
            pass

    # ارسال عکس اگر لینک تصویر وجود داشته باشد
    image_urls = re.findall(r'https://image\.pollinations\.ai/p/[^\s\)\"]+', full_text)
    logger.debug(f"Found image URLs: {image_urls}")
    
    if image_urls:
        for url in image_urls:
            try:
                clean_url = url.rstrip(').,;')
                logger.info(f"Sending image: {clean_url}")
                bot.send_photo(chat_id, clean_url)
            except Exception as e:
                logger.error(f"Failed to send photo: {e}")
                try:
                    bot.send_message(chat_id, f"🖼️ لینک عکس:\n{clean_url}")
                except Exception:
                    pass

    # ارسال فایل‌های آفیس که توسط ابزار ساخته شده‌اند
    # 1) از مارکرهای __OFFICE_FILE__ در stream
    office_files = []
    if isinstance(stream, list):
        for item in stream:
            if isinstance(item, str) and item.startswith("__OFFICE_FILE__:"):
                office_files.append(item.replace("__OFFICE_FILE__:", "").strip())
    
    # 2) از الگوی office_workspace/ در متن پاسخ
    if not office_files:
        office_files = OFFICE_FILE_PATTERN.findall(full_text)
    
    logger.debug(f"Found office files: {office_files}")
    
    if office_files:
        for filename in office_files:
            file_path = os.path.join("office_workspace", filename)
            if os.path.exists(file_path):
                try:
                    ext = os.path.splitext(filename)[1].lower()
                    if ext == ".docx":
                        caption = f"📄 فایل ورد: {filename}"
                    elif ext == ".xlsx":
                        caption = f"📊 فایل اکسل: {filename}"
                    elif ext == ".pptx":
                        caption = f"📽️ فایل پاورپوینت: {filename}"
                    else:
                        caption = f"📎 {filename}"
                    
                    logger.info(f"Sending office file: {file_path}")
                    with open(file_path, 'rb') as f:
                        bot.send_document(chat_id, f, caption=caption)
                except Exception as e:
                    logger.error(f"Failed to send office file {filename}: {e}")
                    try:
                        bot.send_message(chat_id, f"📎 فایل ساخته شد: {filename}")
                    except Exception:
                        pass
            else:
                logger.warning(f"Office file not found on disk: {file_path}")

    # ثبت پاسخ در حافظه نشست
    if user_text and full_text:
        short_term_memory.add(chat_id, "user", user_text)
        short_term_memory.add(chat_id, "model", full_text)
        
        # ذخیره پاسخ ربات در تاریخچه گروه
        try:
            from handlers.group import group_manager
            from datetime import datetime
            # فقط برای گروه‌ها
            if str(chat_id).startswith("-"):
                group_manager.save_message(
                    chat_id=chat_id,
                    user_id=0,  # شناسه ربات
                    username="کارن",
                    text=full_text[:500],
                    msg_type="bot",
                    timestamp=datetime.now().isoformat()
                )
        except Exception as e:
            logger.debug(f"Failed to save bot message to group history: {e}")