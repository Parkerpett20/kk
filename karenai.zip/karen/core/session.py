# core/session.py
import time

class UserSession:
    def __init__(self, chat_id: int):
        self.chat_id = chat_id
        self.created_at = time.time()
        self.last_active = time.time()
        self.active_plan = []
        self.current_step_index = 0
        self.metadata = {}
        self.total_tokens_used = 0

    def update_timestamp(self):
        self.last_active = time.time()

    def set_plan(self, plan_steps: list):
        self.active_plan = plan_steps
        self.current_step_index = 0

    def get_current_step(self) -> str:
        if 0 <= self.current_step_index < len(self.active_plan):
            return self.active_plan[self.current_step_index]
        return ""

    def advance_step(self):
        self.current_step_index += 1


class SessionManager:
    def __init__(self):
        self._sessions = {}

    def get_session(self, chat_id: int) -> UserSession:
        if chat_id not in self._sessions:
            self._sessions[chat_id] = UserSession(chat_id)
        self._sessions[chat_id].update_timestamp()
        return self._sessions[chat_id]

    def destroy_session(self, chat_id: int):
        if chat_id in self._sessions:
            del self._sessions[chat_id]

session_manager = SessionManager()