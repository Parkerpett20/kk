# core/summarizer.py
from google import genai
from config import GEMINI_API_KEY, MODELS

client = genai.Client(api_key=GEMINI_API_KEY)

class HistorySummarizer:
    """کاهش حجم تاریخچه چت‌های شلوغ به یک سند فشرده و کارآمد"""
    @staticmethod
    def create_summary(history_contents: list) -> str:
        if not history_contents or len(history_contents) < 10:
            return ""

        # ساخت متن یکپارچه برای پردازش توسط مدل
        raw_conversation = []
        for msg in history_contents:
            role = "User" if msg.role == "user" else "Assistant (Karen)"
            text_content = "".join([part.text for part in msg.parts if part.text])
            raw_conversation.append(f"{role}: {text_content}")

        conversation_snapshot = "\n".join(raw_conversation)

        prompt = (
            f"Summarize the following conversation details. Maintain all critical user decisions, "
            f"facts, names, or code details mentioned. Keep the output in a very compact Persian paragraph.\n\n"
            f"Conversation:\n{conversation_snapshot}\n\n"
            f"Persian Summary:"
        )
        try:
            response = client.models.generate_content(
                model=MODELS["fast_or_search"],
                contents=prompt
            )
            return response.text.strip()
        except Exception as e:
            print(f"⚠️ Summarizer failed: {e}")
            return ""