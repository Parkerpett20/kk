from __future__ import annotations

import asyncio
import inspect
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

EventHandler = Callable[..., Any]


@dataclass(slots=True)
class Event:

    name: str

    data: dict[str, Any] = field(default_factory=dict)

    timestamp: datetime = field(default_factory=datetime.utcnow)


class EventBus:

    def __init__(self):

        self._subscribers: dict[str, list[EventHandler]] = defaultdict(list)

        self._history: list[Event] = []

        self._lock = asyncio.Lock()

    async def subscribe(self, event_name: str, handler: EventHandler):

        async with self._lock:

            if handler not in self._subscribers[event_name]:

                self._subscribers[event_name].append(handler)

                logger.debug(f"Subscribed -> {event_name}")

    async def unsubscribe(self, event_name: str, handler: EventHandler):

        async with self._lock:

            if handler in self._subscribers[event_name]:

                self._subscribers[event_name].remove(handler)

                logger.debug(f"Unsubscribed -> {event_name}")

    async def publish(self, event_name: str, **kwargs):

        event = Event(

            name=event_name,

            data=kwargs

        )

        self._history.append(event)

        handlers = self._subscribers.get(event_name, [])

        if not handlers:

            logger.debug(f"No handlers for {event_name}")

            return

        tasks = []

        for handler in handlers:

            try:

                if inspect.iscoroutinefunction(handler):

                    tasks.append(asyncio.create_task(handler(event)))

                else:

                    handler(event)

            except Exception:

                logger.exception(

                    f"Handler error ({handler.__name__})"

                )

        if tasks:

            await asyncio.gather(*tasks, return_exceptions=True)

    def listeners(self, event_name: str):

        return len(self._subscribers.get(event_name, []))

    def clear(self):

        self._subscribers.clear()

        self._history.clear()

    @property
    def history(self):

        return self._history.copy()


event_bus = EventBus()