# core/planner.py
import json
from google import genai
from config import GEMINI_API_KEY, MODELS

client = genai.Client(api_key=GEMINI_API_KEY)

class SystemPlanner:
    """تجزیه درخواست‌های سنگین کاربر به گام‌های اجرایی واضح"""
    @staticmethod
    def generate_task_plan(user_query: str) -> list:
        prompt = (
            f"You are a master planner. Analyze this request and break it down into a clear, "
            f"step-by-step list of sub-tasks needed to complete the goal. Keep steps concise and in English.\n"
            f"User Request: {user_query}\n\n"
            f"Return ONLY a raw JSON array of strings. Do not add markdown formatting or explanations.\n"
            f"Example output:\n"
            f'["Identify the target locations", "Gather timezone details", "Format the response"]'
        )
        try:
            response = client.models.generate_content(
                model=MODELS["fast_or_search"],
                contents=prompt,
            )
            text = response.text.strip()
            # پیدا کردن ابتدا و انتهای لیست برای استخراج ایمن داده جی‌سون
            if "[" in text and "]" in text:
                start_idx = text.find("[")
                end_idx = text.rfind("]") + 1
                return json.loads(text[start_idx:end_idx])
        except Exception as e:
            print(f"⚠️ Planner creation failed: {e}")
            
        # خروجی پشتیبان در صورت وقوع استثنا
        return ["Process query directly"]