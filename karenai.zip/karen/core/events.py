USER_MESSAGE = "user.message"

ASSISTANT_MESSAGE = "assistant.message"

MEMORY_SAVED = "memory.saved"

MEMORY_RETRIEVED = "memory.retrieved"

PLUGIN_LOADED = "plugin.loaded"

PLUGIN_EXECUTED = "plugin.executed"

TOOL_CALLED = "tool.called"

TOOL_FINISHED = "tool.finished"

TASK_CREATED = "task.created"

TASK_COMPLETED = "task.completed"

REFLECTION_STARTED = "reflection.started"

REFLECTION_FINISHED = "reflection.finished"

ERROR_OCCURRED = "error.occurred"

SHUTDOWN = "system.shutdown"