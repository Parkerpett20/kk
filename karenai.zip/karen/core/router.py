# core/router.py
import re
from config import MODELS

# محدوده کاراکترهای فارسی/عربی برای تشخیص «مرز کلمه»
_ARABIC_RANGES = r'\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF'


def _match_keyword(text: str, keyword: str) -> bool:
    """آیا `keyword` در متن به‌صورت یک کلمه‌ی کامل وجود دارد؟

    مشکل substring-matching قدیمی: کلمه‌ی «ورد» در متن «در مورد» match می‌شد و
    درخواست‌های «در مورد قیمت طلا سرچ کن» را اشتباهاً به مسیر آفیس می‌فرستاد
    و جستجوی واقعی وب (Exa) را خاموش می‌کرد.
    """
    if not text or not keyword:
        return False
    if re.search(r'[A-Za-z0-9]', keyword):
        # کلمات کلیدی انگلیسی فقط به‌صورت کلمه و بین کاراکترهای ASCII
        return re.search(
            rf'(?<![A-Za-z0-9_]){re.escape(keyword)}(?![A-Za-z0-9_])',
            text, re.IGNORECASE,
        ) is not None
    # کلمات کلیدی فارسی/عربی فقط وقتی کاملاً آزاد هستند match می‌شوند
    return re.search(
        rf'(?<![{_ARABIC_RANGES}]){re.escape(keyword)}(?![{_ARABIC_RANGES}])',
        text,
    ) is not None


class IntentRouter:
    """دسته‌بندی هوشمند پیام و اختصاص مدل مناسب بر اساس درخواست کاربر"""
    @staticmethod
    def route(text: str) -> dict:
        text_lower = text.lower() if text else ""
        
        # پلن پیش‌فرض: پاسخ سریع بدون ابزار جانبی با مدل gemma-4-26b-a4b-it
        plan = {
            "model": MODELS["fast_or_search"],
            "thinking": "MINIMAL",
            "search": False,
            "math": False,
            "image": False,
            "github": False,
            "youtube": False,
            "reminder": False,
            "office": False,
            "mood": "casual"
        }

        # کلمات کلیدی مربوط به کارهای عمیق، مقاله‌نویسی و استدلال‌های تخصصی
        deep_keywords = [
            "مقاله", "کتاب", "پایان نامه", "انشا", "متن طولانی", "نگارش", "بنویس",
            "تحلیل", "عمیق", "کد", "برنامه نویسی", "الگوریتم", "ریاضی", "حل کن", "ارور", "باگ"
        ]
        
        # کلمات کلیدی مربوط به نیاز به جستجو در وب
        search_keywords = [
            "اخبار", "امروز", "دیروز", "خبر", "قیمت", "دلار", "طلا", "گوگل", "سرچ", "هواشناسی", "آب و هوا",
            "بتمن", "batman", "ارخام نایت", "bruce wayne", "کریستوفر نولان"
        ]

        # کلمات کلیدی مربوط به تولید تصویر
        image_keywords = [
            "عکس", "تصویر", "بکش", "بکشید", "تولید کن", "بساز", "طراحی", "نقاشی",
            "image", "picture", "draw", "generate", "create", "design"
        ]

        # کلمات کلیدی مربوط به GitHub
        github_keywords = [
            "github", "گیت هاب", "گیتهاب", "repositor", "repo", "ریپو",
            "fork", "star", "pull request", "issue", "پروژه گیت", "کد منبع"
        ]

        # الگوهای درخواست‌های مبهم برای GitHub
        github_intent_patterns = [
            "بررسی کن", "بررسی", "ببین", "چک کن", "تحلیل کن", "مشخصات", "پروفایل",
            "اکانت", "user", "profile", "repo", "repository"
        ]

        # کلمات کلیدی مربوط به YouTube و جستجو ویدیو
        youtube_keywords = [
            "youtube", "یوتیوب", "ویدیو", "فیلم", "آموزش", "tutorial", "video",
            "موزیک", "آهنگ", "سرچ ویدیو", "سرچ فیلم", "ویدیو سرچ",
            "documentary", "فیلم مستند"
        ]

        # کلمات کلیدی مربوط به یادآوری
        reminder_keywords = [
            "یادآوری", "یادم بنداز", "یادم بده", "یادآوری کن",
            " reminds ", "remind me", "schedule reminder"
        ]

        # کلمات کلیدی مربوط به مدیریت گروه
        group_keywords = [
            "عضو", "اعضا", "اضافه کن", "دعوت کن", "invite", "add member",
            "لینک دعوت", "invite link", "ادمین", "admin", "مدیر",
            "لیست اعضا", "members", "لیست ادمین", "admins"
        ]

        # کلمات کلیدی مربوط به منشی شخصی (ارسال پیام به مخاطب)
        secretary_keywords = [
            "بگو", "پیام بده", "پیام بفرست", "ارسال کن", "بهش بگو",
            "بهش پیام", "بهش خبر کن", "خبرش کن", "بهش خبر بده",
            "send message", "tell him", "tell her", "contact",
            "مخاطب", "لیست مخاطب", "contacts"
        ]

        # کلمات کلیدی مربوط به اسناد آفیس (Word, Excel, PowerPoint)
        office_keywords = [
            "ورد", "word", "docx", "سند ورد", "فایل ورد",
            "اکسل", "excel", "xlsx", "صفحه گسترده", "spreadsheet",
            "پاورپوینت", "powerpoint", "pptx", "اسلاید", "اسلایدسازی",
            "ارائه", "presentation", "ساخت سند", "ساخت فایل",
            "تبدیل به ورد", "تبدیل به اکسل", "تبدیل به پاورپوینت",
            "office", "آفیس", "officecli", "مستند", "document",
            "گزارش", "report", "رزومه", "resume", "cv",
            "نامه", "letter", "متن به ورد", "text to word",
            "متن به اکسل", "text to excel", "متن به پاورپوینت", "text to ppt",
            "دیتا به اکسل", "data to excel", "جدول", "table"
        ]

        # اولویت‌بندی تصمیم‌گیری برای انتخاب مدل
        # یادآوری بالاترین اولویت را دارد - قبل از LLM بررسی شود
        if any(_match_keyword(text_lower, kw) for kw in reminder_keywords):
            plan["model"] = MODELS["fast_or_search"]
            plan["reminder"] = True
            plan["mood"] = "casual"
            return plan

        if any(_match_keyword(text_lower, kw) for kw in youtube_keywords):
            # جستجوی YouTube -> مدل سریع با ابزار YouTube
            plan["model"] = MODELS["fast_or_search"]
            plan["youtube"] = True
            plan["mood"] = "casual"
            
        elif any(_match_keyword(text_lower, kw) for kw in github_keywords) or (
            _match_keyword(text_lower, "github") and any(_match_keyword(text_lower, kw) for kw in ["بررسی", "ببین", "چک", "تحلیل", "پروفایل", "اکانت"])
        ):
            plan["model"] = MODELS["fast_or_search"]
            plan["github"] = True
            plan["mood"] = "coder"

        elif any(_match_keyword(text_lower, kw) for kw in office_keywords):
            # اسناد آفیس - ساخت/ویرایش فایل‌های Word, Excel, PowerPoint
            plan["model"] = MODELS["fast_or_search"]
            plan["office"] = True
            plan["mood"] = "researcher"

        elif any(_match_keyword(text_lower, kw) for kw in image_keywords):
            # تولید تصویر -> مدل gemma-4-31b-it با ابزار تولید تصویر
            plan["model"] = MODELS["deep_task"]
            plan["image"] = True
            plan["mood"] = "creative"
            
        elif any(_match_keyword(text_lower, kw) for kw in deep_keywords):
            # کارهای عمیق و مقالات سنگین -> مدل gemma-4-31b-it
            plan["model"] = MODELS["deep_task"]
            plan["thinking"] = "HIGH"
            plan["mood"] = "coder" if "کد" in text_lower else "researcher"
            
        elif any(_match_keyword(text_lower, kw) for kw in search_keywords):
            # سرچ گوگل و پاسخ سریع -> مدل gemma-4-26b-a4b-it به همراه فعال‌سازی ابزار سرچ
            plan["model"] = MODELS["fast_or_search"]
            plan["search"] = True
            plan["mood"] = "researcher"
        
        elif any(_match_keyword(text_lower, kw) for kw in group_keywords):
            # مدیریت گروه -> مدل سریع با ابزارهای گروه
            plan["model"] = MODELS["fast_or_search"]
            plan["group_management"] = True
            plan["mood"] = "casual"

        elif any(_match_keyword(text_lower, kw) for kw in secretary_keywords):
            # منشی شخصی - ارسال پیام به مخاطب -> مدل سریع با ابزارهای منشی
            plan["model"] = MODELS["fast_or_search"]
            plan["secretary"] = True
            plan["mood"] = "casual"

        return plan
