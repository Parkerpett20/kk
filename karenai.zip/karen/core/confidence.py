# core/confidence.py

class ConfidenceScorer:
    """محاسبه نمره اطمینان به پاسخ تولید شده بر اساس تحلیل متنی"""
    @staticmethod
    def calculate_score(text: str) -> float:
        if not text:
            return 0.0

        # نشانگرهای عدم قطعیت متداول
        uncertainty_flags = [
            "شاید", "احتمالاً", "فکر می‌کنم", "دقیقاً مطمئن نیستم", "منبع موثقی ندارم",
            "not sure", "maybe", "probably", "i think", "i believe", "unverified"
        ]

        score = 100.0
        text_lower = text.lower()

        for flag in uncertainty_flags:
            if flag in text_lower:
                score -= 15.0

        return max(0.0, score)