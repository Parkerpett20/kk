# core/scheduler.py
"""
سیستم زمان‌بندی و یادآوری هوشمند
"""

import logging
import json
import os
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from typing import Callable, Dict, List, Optional
import pytz

logger = logging.getLogger(__name__)

class Reminder:
    """کلاس یادآوری"""
    def __init__(self, user_id: int, message: str, run_time: datetime, 
                 reminder_id: str = None, enabled: bool = True):
        self.user_id = user_id
        self.message = message
        self.run_time = run_time
        self.reminder_id = reminder_id or str(user_id) + "_" + str(int(run_time.timestamp()))
        self.enabled = enabled
        self.created_at = datetime.now()
        
    def to_dict(self):
        return {
            'user_id': self.user_id,
            'message': self.message,
            'run_time': self.run_time.isoformat(),
            'reminder_id': self.reminder_id,
            'enabled': self.enabled,
            'created_at': self.created_at.isoformat()
        }
    
    @staticmethod
    def from_dict(data: dict):
        reminder = Reminder(
            user_id=data['user_id'],
            message=data['message'],
            run_time=datetime.fromisoformat(data['run_time']),
            reminder_id=data.get('reminder_id'),
            enabled=data.get('enabled', True)
        )
        return reminder


class ReminderScheduler:
    """مدیر یادآوری‌ها و زمان‌بندی"""
    
    def __init__(self, data_file: str = "data/reminders.json"):
        self.data_file = data_file
        self.scheduler = BackgroundScheduler(
            timezone=pytz.timezone('Asia/Tehran')
        )
        self.reminders: Dict[str, Reminder] = {}
        self.callback: Optional[Callable] = None
        self._ensure_data_file()
        self._load_reminders()
        self._schedule_loaded_reminders()
        
    def _ensure_data_file(self):
        """اطمینان از وجود فایل داده‌ها"""
        os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
        if not os.path.exists(self.data_file):
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump({}, f)
    
    def _load_reminders(self):
        """بارگذاری یادآوری‌ها از فایل"""
        try:
            with open(self.data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for reminder_id, reminder_data in data.items():
                    reminder = Reminder.from_dict(reminder_data)
                    self.reminders[reminder_id] = reminder
            logger.info(f"✅ {len(self.reminders)} یادآوری بارگذاری شد")
        except Exception as e:
            logger.error(f"❌ خطا در بارگذاری یادآوری‌ها: {e}")

    def _schedule_loaded_reminders(self):
        """برنامه‌ریزی یادآوری‌های بارگذاری‌شده در scheduler"""
        now = datetime.now(pytz.timezone('Asia/Tehran'))
        for reminder in self.reminders.values():
            if reminder.run_time > now:
                self._schedule_reminder(
                    reminder.reminder_id,
                    reminder.run_time,
                    reminder.user_id,
                    reminder.message
                )
            else:
                logger.warning(
                    f"⚠️ یادآوری گذشته نادیده گرفته شد: {reminder.reminder_id}"
                )
    
    def _save_reminders(self):
        """ذخیره‌سازی یادآوری‌ها در فایل"""
        try:
            data = {rid: r.to_dict() for rid, r in self.reminders.items()}
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره‌سازی یادآوری‌ها: {e}")
    
    def set_callback(self, callback: Callable):
        """تنظیم تابع callback برای اجرای یادآوری"""
        self.callback = callback
    
    def add_reminder(self, user_id: int, message: str, run_time: datetime, 
                     notify_before_minutes: int = 0) -> str:
        """اضافه کردن یادآوری جدید"""
        reminder = Reminder(user_id, message, run_time)
        self.reminders[reminder.reminder_id] = reminder
        self._save_reminders()
        
        # زمان‌بندی یادآوری
        self._schedule_reminder(reminder.reminder_id, run_time, user_id, message)
        
        # اگر notify_before_minutes > 0، یادآوری قبل را نیز برنامه‌ریزی کن
        if notify_before_minutes > 0:
            notify_time = run_time - timedelta(minutes=notify_before_minutes)
            if notify_time > datetime.now(pytz.timezone('Asia/Tehran')):
                pre_message = f"⏰ [{notify_before_minutes} دقیقه تا {message}]"
                pre_reminder_id = f"{reminder.reminder_id}_pre"
                self._schedule_reminder(pre_reminder_id, notify_time, user_id, pre_message)
        
        logger.info(f"✅ یادآوری اضافه شد: {reminder.reminder_id}")
        return reminder.reminder_id
    
    def _schedule_reminder(self, reminder_id: str, run_time: datetime, 
                          user_id: int, message: str):
        """برنامه‌ریزی یادآوری در scheduler"""
        try:
            self.scheduler.add_job(
                func=self._trigger_reminder,
                trigger="date",
                run_date=run_time,
                args=[user_id, message],
                id=reminder_id,
                replace_existing=True,
                misfire_grace_time=60
            )
            logger.info(f"⏰ یادآوری برنامه‌ریزی شد: {run_time}")
        except Exception as e:
            logger.error(f"❌ خطا در برنامه‌ریزی: {e}")
    
    def _trigger_reminder(self, user_id: int, message: str):
        """تریگر یادآوری"""
        if self.callback:
            try:
                self.callback(user_id, message)
                logger.info(f"📬 یادآوری ارسال شد برای کاربر {user_id}")
            except Exception as e:
                logger.error(f"❌ خطا در ارسال یادآوری: {e}")
    
    def list_reminders(self, user_id: int = None) -> List[Reminder]:
        """لیست یادآوری‌ها"""
        reminders = list(self.reminders.values())
        if user_id:
            reminders = [r for r in reminders if r.user_id == user_id]
        return sorted(reminders, key=lambda x: x.run_time)
    
    def delete_reminder(self, reminder_id: str) -> bool:
        """حذف یادآوری"""
        if reminder_id in self.reminders:
            del self.reminders[reminder_id]
            self._save_reminders()
            if self.scheduler.get_job(reminder_id):
                self.scheduler.remove_job(reminder_id)
            logger.info(f"🗑️ یادآوری حذف شد: {reminder_id}")
            return True
        return False
    
    def start(self):
        """شروع scheduler"""
        if not self.scheduler.running:
            self.scheduler.start()
            logger.info("🚀 Scheduler شروع شد")
    
    def stop(self):
        """توقف scheduler"""
        if self.scheduler.running:
            self.scheduler.shutdown()
            logger.info("⏹️ Scheduler متوقف شد")
    
    def get_pending_reminders(self, user_id: int) -> List[Reminder]:
        """یادآوری‌های آینده کاربر"""
        now = datetime.now(pytz.timezone('Asia/Tehran'))
        return [r for r in self.list_reminders(user_id) 
                if r.run_time > now and r.enabled]


# اینستنس سراسری
reminder_scheduler = ReminderScheduler()
