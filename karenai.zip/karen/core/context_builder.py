# core/context_builder.py
import datetime
from prompts.system import get_base_identity
from prompts.personalities import get_personality_instruction
from memory.long_memory import long_term_memory
from memory.telegram_profile import telegram_profile_manager
from memory.user_settings import user_settings
from handlers.group import group_manager

def build_context(chat_id: int, mood: str, chat_type: str = None, user_id: int = None) -> str:
    """ادغام اطلاعات هویت پایه، زمان جاری، مود و حقایق بلندمدت کاربر برای تزریق به سیستم پرامپت"""
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    persona = get_personality_instruction(mood)
    user_facts = long_term_memory.get_user_facts(chat_id)
    
    prompt = f"{get_base_identity(user_id)}\n"
    prompt += f"System Time: {now}\n"
    prompt += f"Behavior: {persona}\n"
    
    if user_facts:
        prompt += f"\nFacts about this user:\n{user_facts}\n"
    
    # تزریق پروفایل کاربر از تنظیمات (نام، تاریخ تولد، درباره من)
    if user_id:
        profile_name = user_settings.get_setting(user_id, 'profile_name')
        profile_birthday = user_settings.get_setting(user_id, 'profile_birthday')
        profile_bio = user_settings.get_setting(user_id, 'profile_bio')
        
        if profile_name or profile_birthday or profile_bio:
            prompt += f"\n👤 User Profile (from setup):\n"
            if profile_name:
                prompt += f"- Name: {profile_name}\n"
            if profile_birthday and profile_birthday != 'تنظیم نشده':
                prompt += f"- Birthday: {profile_birthday}\n"
            if profile_bio and profile_bio != 'تنظیم نشده':
                prompt += f"- About: {profile_bio}\n"
            if profile_name:
                prompt += f"IMPORTANT: Always address the user by their name '{profile_name}' naturally in conversation. If they changed their name, use the new name.\n"
    
    # تزریق پروفایل تلگرام کاربر (بی‌سروصدا)
    if user_id:
        profile_summary = telegram_profile_manager.get_profile_summary(user_id)
        if profile_summary:
            prompt += f"\n{profile_summary}\n"

    # تزریق وضعیت منشی شخصی (برای اینکه هوش مصنوعی بداند آیا می‌تواند پیام ارسال کند)
    # توجه: فقط بررسی می‌کنیم کلاینت در حافظه هست یا نه (dict lookup سریع)
    # تا از کندی پاسخ‌دهی جلوگیری شود (is_authorized ممکن است reconnect کند)
    if user_id:
        try:
            from tools.secretary_service import is_secretary_enabled, get_secretary_mode
            from tools.userbot_manager import _clients
            secretary_enabled = is_secretary_enabled(user_id)
            client_in_memory = user_id in _clients
            secretary_mode = get_secretary_mode(user_id)

            if secretary_enabled and client_in_memory:
                prompt += f"\n🔔 SECRETARY STATUS: Active (mode: {secretary_mode}). You CAN send messages to the user's contacts using send_message_to_contact. The user's Telegram account is connected and authorized.\n"
            elif secretary_enabled and not client_in_memory:
                prompt += f"\n⚠️ SECRETARY STATUS: Enabled but session not loaded in memory. The tool will try to reconnect automatically. If it fails, tell the user to re-login via /settings -> Secretary.\n"
            else:
                prompt += f"\n🔕 SECRETARY STATUS: Not active. If the user asks you to send a message to someone, tell them to activate the secretary feature in /settings first.\n"
        except Exception:
            pass
    
    # اضافه کردن اطلاعات گروه اگر در گروه باشیم
    if chat_type in ['group', 'supergroup']:
        prompt += "\n💡 IMPORTANT: You are in a group chat. Use the recent chat history above to understand the context of conversations. Reference previous messages when relevant to provide better answers.\n"
        prompt += "🔧 You are an ADMIN in this group with full capabilities to:\n"
        prompt += "- Access chat history and member information\n"
        prompt += "- Invite new members using invite_chat_member tool\n"
        prompt += "- Create invite links using create_group_invite_link tool\n"
        prompt += "- View administrators using get_group_admins tool\n"
        prompt += "NEVER say you don't have permissions - you ARE an admin with these capabilities.\n"
        try:
            # دریافت اطلاعات گروه
            group_info = group_manager.get_info(chat_id)
            if group_info:
                prompt += f"\n📌 Group Information:\n"
                prompt += f"- Group Name: {group_info.get('title', 'Unknown')}\n"
                prompt += f"- Member Count: {group_info.get('member_count', 'Unknown')}\n"
            
            # دریافت لیست اعضا
            members = group_manager.get_members(chat_id)
            if members:
                prompt += f"\n👥 Group Members (recent activity):\n"
                for member in members[:10]:  # محدود به 10 نفر اول
                    name = member.get('name', 'Unknown')
                    status = member.get('status', '')
                    prompt += f"- {name} ({status})\n"
            
            # دریافت تاریخچه اخیر (۳۰ پیام آخر)
            messages = group_manager.get_messages(chat_id, limit=30)
            if messages:
                prompt += f"\n📜 Recent Chat History (last {len(messages)} messages):\n"
                for msg in messages:
                    username = msg.get('username', 'Unknown')
                    text = msg.get('text', '')[:200]
                    msg_type = msg.get('type', 'text')
                    type_icon = {"text": "💬", "photo": "📷", "voice": "🎤", "document": "📄", "video": "🎬"}.get(msg_type, "💬")
                    prompt += f"{type_icon} {username}: {text}\n"
        except Exception as e:
            pass
    
    return prompt