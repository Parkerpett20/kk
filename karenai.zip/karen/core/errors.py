# core/errors.py
"""
مدیریت هوشمند خطاهای سرویس‌های خارجی (مثل Gemini).

وقتی خطایی مثل 429 (Rate Limit) یا 500/503 (Server Error) از سرویس‌های بیرونی
پیش می‌آید، به‌جای ارسال متن خام خطا به کاربر در تلگرام، یک پیام آماده و صمیمی
متناسب با نوع خطا برمی‌گردانیم تا تجربه‌ی کاربر حفظ شود. برای خطاهای موقت
هم بازتلاش خودکار انجام می‌دهیم تا از رسیدن خطا به کاربر کاسته شود.
"""
import re
import time
import logging
from google.genai import errors as genai_errors
from core.languages import get_text

logger = logging.getLogger(__name__)

# کدهای HTTP که موقت هستند و با یک بازتلاش کوتاه احتمالاً برطرف می‌شوند
TRANSIENT_CODES = {408, 429, 500, 502, 503, 504}

# نگاشت دسته‌بندی خطا به کلید پیام محلی
CATEGORY_KEYS = {
    "rate_limit": "error_rate_limit",
    "server": "error_server_busy",
    "auth": "error_auth",
    "quota": "error_quota",
    "network": "error_network",
    "generic": "error_generic",
}

# کوئل‌داون ساده برای جلوگیری از بمباران پیام‌های تکراری هنگام خطاهای پیاپی
# در بازه‌ی کوئل‌داون، به‌جای پیام کامل، یک پیام کوتاه «هنوز شلوغم» می‌فرستیم.
# کلید: (user_id, category) -> زمان آخرین ارسال
_last_sent = {}


def _get_code(exc):
    """استخراج کد HTTP از استثنا (در صورت وجود)."""
    code = getattr(exc, "code", None)
    if isinstance(code, int):
        return code

    response = getattr(exc, "response", None)
    if response is not None and hasattr(response, "status_code"):
        try:
            return int(response.status_code)
        except (TypeError, ValueError):
            pass

    # جست‌وجوی کد 4xx/5xx داخل متن خطا به‌عنوان آخرین راه
    match = re.search(r"\b([45]\d{2})\b", str(exc))
    if match:
        return int(match.group(1))
    return None


def _get_status(exc):
    """استخراج وضعیت سرویس (مثل RESOURCE_EXHAUSTED) از استثنا."""
    status = getattr(exc, "status", None)
    if status:
        return str(status).upper()
    return str(exc).upper()


def classify_exception(exc):
    """
    دسته‌بندی یک استثنا به یکی از:
    rate_limit, server, auth, quota, network, generic
    """
    code = _get_code(exc)
    if code is not None:
        if code == 429:
            return "rate_limit"
        if 500 <= code <= 599:
            return "server"
        if code in (401, 403):
            return "auth"
        if code == 400:
            return "quota"
        return "generic"

    status = _get_status(exc)
    if "RATE_LIMIT" in status or "RESOURCE_EXHAUSTED" in status or "QUOTA" in status:
        return "rate_limit"
    if "UNAVAILABLE" in status or "INTERNAL" in status or "SERVER_ERROR" in status:
        return "server"
    if "UNAUTHENTICATED" in status or "PERMISSION_DENIED" in status or "FORBIDDEN" in status:
        return "auth"

    exc_name = type(exc).__name__
    if any(keyword in exc_name for keyword in ("Timeout", "Connection", "Network")):
        return "network"

    return "generic"


def should_retry(exc):
    """آیا این خطا موقت است و شایسته‌ی بازتلاش است؟"""
    return _get_code(exc) in TRANSIENT_CODES


def reset_error_cooldown():
    """پاک‌کردن حافظه‌ی کوئل‌داون (معمولاً برای تست‌ها)."""
    _last_sent.clear()


def get_friendly_error_message(user_id, exc, cooldown_seconds=45, force=False):
    """
    برمی‌گرداند یک پیام آماده و صمیمی متناسب با نوع خطا؛ هرگز متن خام خطا را
    به کاربر نشان نمی‌دهد.

    اگر خطای مشابهی برای همین کاربر در بازه‌ی کوئل‌داون به‌تازگی ارسال شده
    باشد، به‌جای پیام کامل یک پیام کوتاه «هنوز شلوغم» برمی‌گرداند تا از تکرار
    بیش‌ازحد جلوگیری شود. با force=True همیشه پیام کامل داده می‌شود.
    """
    category = classify_exception(exc)
    key = CATEGORY_KEYS.get(category, "error_generic")

    now = time.time()
    last = _last_sent.get((user_id, key))
    suppressed = (not force) and last is not None and (now - last) < cooldown_seconds
    _last_sent[(user_id, key)] = now

    if suppressed:
        logger.info(
            "Repeated error '%s' for user %s (last sent %.0fs ago); "
            "sending short message.",
            key, user_id, now - last,
        )
        return get_text(user_id, "error_busy_short")

    message = get_text(user_id, key)
    if not message or message == key:
        # اگر کلید در زبان کاربر تعریف نشده بود، به پیام عمومی برگرد
        message = get_text(user_id, "error_generic")
    return message


def retry_api_call(func, *args, max_retries=2, **kwargs):
    """
    فراخوانی `func(*args, **kwargs)` با بازتلاش خودکار برای خطاهای موقت
    (429/500/503/...). اگر پس از بازتلاش‌ها همچنان خطا بدهد، استثنا را دوباره
    بالا می‌اندازد تا لایه‌ی بالاتر پیام صمیمی ارسال کند.
    """
    attempt = 0
    while True:
        try:
            return func(*args, **kwargs)
        except genai_errors.APIError as exc:
            if should_retry(exc) and attempt < max_retries:
                attempt += 1
                delay = 0.5 * attempt  # 0.5s، 1s
                logger.warning(
                    "Transient API error %s on attempt %d; retrying in %.1fs...",
                    exc.code, attempt, delay,
                )
                time.sleep(delay)
                continue
            raise
