# core/reflection.py
import json
from google import genai
from config import GEMINI_API_KEY, MODELS

client = genai.Client(api_key=GEMINI_API_KEY)

class ReflectionEngine:
    """ارزیابی کیفی پاسخ‌های تولید شده قبل از ارسال نهایی به کاربر"""
    @staticmethod
    def audit_response(user_query: str, proposed_answer: str) -> dict:
        prompt = (
            f"Review the proposed response against the user query for accuracy and completeness.\n\n"
            f"User Query: {user_query}\n"
            f"Proposed Answer: {proposed_answer}\n\n"
            f"Format your analysis purely as JSON with two keys:\n"
            f"- 'approved' (true or false)\n"
            f"- 'feedback' (reasons for rejection or suggestions for correction, empty if approved)\n"
            f"Do not write anything else but the raw JSON object."
        )
        try:
            response = client.models.generate_content(
                model=MODELS["fast_or_search"],
                contents=prompt
            )
            text = response.text.strip()
            if "{" in text and "}" in text:
                start_idx = text.find("{")
                end_idx = text.rfind("}") + 1
                return json.loads(text[start_idx:end_idx])
        except Exception as e:
            print(f"⚠️ Reflection engine failed: {e}")
            
        return {"approved": True, "feedback": ""}